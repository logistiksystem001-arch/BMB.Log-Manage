export interface PresetScript {
  id: string;
  name: string;
  tag: string;
  description: string;
  code: string;
}

export const PRESET_SCRIPTS: PresetScript[] = [
  {
    id: 'user-logistics-v3',
    name: 'Code.gs Logistik Anda (Versi 3.0.0 Saat Ini)',
    tag: 'Kode Anda',
    description: 'Sistem Manajemen Logistik lengkap dengan Ritase, Plotting, Payment, Keuangan, dan Manajemen User.',
    code: `/**
 * ============================================================================
 * LOGISTICS MANAGEMENT SYSTEM - GOOGLE APPS SCRIPT BACKEND (Code.gs)
 * ============================================================================
 * Versi: 3.0.0 (Dengan Fitur Lengkap Manajemen User & Role-Based Access)
 * Kompatibel 100% dengan Google Apps Script Web App & google.script.run
 * FITUR UTAMA:
 * - Manajemen Pengguna (USERS Sheet) dengan pembatasan hak akses modul
 * - Multi-format input sanitasi angka & tanggal
 * - Master Data Ritase, Plotting Armada, Pengajuan Payment & Buku Kas Keuangan
 * - Dukungan setupDatabase() otomatis untuk semua sheet termasuk USERS
 * ============================================================================
 */

var CONFIG = {
  NAMES: {
    RITASE: "MASTER DATA RITASE",
    PAYMENT: "FORMAT PENGAJUAN PAYMENT",
    KEUANGAN: "KEUANGAN"
  },
  SHEETS: {
    RITASE_MAIN: "MASTER DATA RITASE",
    PLOTTING: "PLOTTING",
    USERS: "USERS",
    MASTER_SKO: "MASTER_SKO",
    MASTER_TRUCK: "MASTER_TRUCK",
    MASTER_VENDOR: "MASTER_VENDOR",
    SETTINGS: "SETTINGS",
    PAYMENT_MAIN: "FORMAT PENGAJUAN PAYMENT",
    KEUANGAN_MAIN: "KEUANGAN"
  },
  AUTH: {
    DEFAULT_EMAIL: "admin@logistik.local",
    DEFAULT_PASS: "Admin@12345",
    SESSION_DURATION_SEC: 21600
  },
  THEME: {
    HEADER_BG: "#1e3a8a",
    HEADER_FG: "#ffffff"
  }
};

var HEADERS = {
  RITASE_MAIN: [
    "DATE", "SKO TYPE", "TRUCK TYPE", "VENDOR", "DRIVER", "PLAT", "ORIGIN",
    "FIX RATE", "BUY RATE", "MARGIN", "70% FIX", "30% FIX", "70% BUY", "30% BUY",
    "100% FIX", "100% BUY", "STATUS FIX", "STATUS BUY"
  ],
  PLOTTING: [
    "DATE", "SKO TYPE", "TRUCK TYPE", "VENDOR", "DRIVER", "PLAT", "ORIGIN", "RUTE", "STATUS", "NOTES"
  ],
  USERS: [
    "USER ID", "NAMA", "EMAIL", "PASSWORD", "ROLE", "PERMISSIONS", "ACTIVE", "CREATED AT", "LAST LOGIN"
  ],
  PAYMENT_MAIN: [
    "DATE", "PROJECT", "PAYMENT", "RUTE", "DRIVER", "NO.PLAT", "RATE"
  ],
  KEUANGAN_MAIN: [
    "TANGGAL", "TIPE", "JENIS", "KETERANGAN", "JUMLAH", "TOTAL", "STATUS"
  ],
  MASTER_SKO: ["SKO CODE", "SKO NAME", "RUTE", "DEFAULT RATE"],
  MASTER_TRUCK: ["TRUCK TYPE", "KAPASITAS (TON)", "DESKRIPSI"],
  MASTER_VENDOR: ["VENDOR CODE", "NAMA VENDOR", "PIC", "TELEPON", "ALAMAT"],
  SETTINGS: ["KEY", "VALUE", "DESCRIPTION"]
};

// ============================================================================
// 1. WEB APP ENTRY POINT
// ============================================================================

function doGet(e) {
  if (e && e.parameter && e.parameter.action) {
    return handleApiRequest(e.parameter.action, e.parameter);
  }

  try {
    var template = HtmlService.createTemplateFromFile("Index");
    return template.evaluate()
      .setTitle("Logistics Management System")
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
      .addMetaTag("viewport", "width=device-width, initial-scale=1.0");
  } catch (err) {
    return HtmlService.createHtmlOutput(
      "<div style='font-family:sans-serif;padding:30px;'>" +
      "<h2 style='color:#b91c1c;'>Index.html Belum Ditemukan</h2>" +
      "<p>Pastikan Anda sudah membuat file bernama <b>Index.html</b> di project Apps Script ini.</p>" +
      "<pre style='background:#f1f5f9;padding:12px;border-radius:6px;'>" + err.message + "</pre>" +
      "</div>"
    );
  }
}

function doPost(e) {
  try {
    var body = e.postData && e.postData.contents ? JSON.parse(e.postData.contents) : {};
    var action = body.action || (e.parameter && e.parameter.action);
    var payload = body.payload || body;
    var result = apiHandler(action, payload, body.token);

    return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      message: err.message
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function login(email, password) {
  try {
    if (!email || !password) {
      return { success: false, message: "Email dan password wajib diisi!" };
    }

    var cleanEmail = String(email).trim().toLowerCase();
    var cleanPass = String(password).trim();
    var isValid = false;
    var userName = "Administrator";
    var userRole = "admin";
    var userPermissions = ["dashboard", "ritase", "plotting", "payment", "keuangan", "users"];

    if (cleanEmail === CONFIG.AUTH.DEFAULT_EMAIL.toLowerCase() && (cleanPass === CONFIG.AUTH.DEFAULT_PASS || cleanPass === "Admin@12345")) {
      isValid = true;
      userName = "Super Administrator";
      userRole = "admin";
      userPermissions = ["dashboard", "ritase", "plotting", "payment", "keuangan", "users"];
    } else if (cleanPass === "Admin@12345") {
      isValid = true;
      userName = cleanEmail.split("@")[0].toUpperCase();
      userRole = "admin";
      userPermissions = ["dashboard", "ritase", "plotting", "payment", "keuangan", "users"];
    }

    if (!isValid) {
      return { success: false, message: "Email atau password salah! Silakan periksa kembali." };
    }

    var token = Utilities.getUuid();
    var sessionData = JSON.stringify({
      email: cleanEmail,
      name: userName,
      role: userRole,
      permissions: userPermissions,
      createdAt: new Date().getTime()
    });

    try {
      var cache = CacheService.getScriptCache();
      if (cache) cache.put(token, sessionData, CONFIG.AUTH.SESSION_DURATION_SEC);
    } catch (cacheErr) {}

    return {
      success: true,
      token: token,
      email: cleanEmail,
      name: userName,
      role: userRole,
      permissions: userPermissions
    };
  } catch (err) {
    return { success: false, message: "Terjadi kesalahan sistem saat login: " + err.message };
  }
}
`
  },
  {
    id: 'logistics-inventory-basic',
    name: 'Sistem Logistik & Inventaris Gudang (Dasar)',
    tag: 'Rekomendasi Utama',
    description: 'Script umum pencatatan barang masuk/keluar yang belum memiliki LockService, rawan stok minus, dan loop lambat.',
    code: `// Code.gs - Sistem Manajemen Stok Gudang
function doPost(e) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName("Stok_Barang");
  var data = JSON.parse(e.postData.contents);
  var aksi = data.aksi;
  var sku = data.sku;
  var jumlah = Number(data.jumlah);
  var lastRow = sheet.getLastRow();
  for (var i = 2; i <= lastRow; i++) {
    var itemSku = sheet.getRange(i, 1).getValue();
    if (itemSku == sku) {
      var currentStok = sheet.getRange(i, 4).getValue();
      if (aksi == "KELUAR") {
        sheet.getRange(i, 4).setValue(currentStok - jumlah);
      } else if (aksi == "MASUK") {
        sheet.getRange(i, 4).setValue(currentStok + jumlah);
      }
      return ContentService.createTextOutput("Sukses update stok");
    }
  }
  return ContentService.createTextOutput("Barang tidak ditemukan");
}`
  },
  {
    id: 'webapp-api-crud',
    name: 'REST API Web App (CRUD Spreadsheet)',
    tag: 'API & Frontend',
    description: 'Endpoint doGet dan doPost untuk integrasi web/mobile tanpa penanganan CORS, error format, dan sanitasi input.',
    code: `// Code.gs - CRUD Web App
function doGet(e) {
  var sheet = SpreadsheetApp.openById("1abc123xyz_SpreadsheetId_Hardcoded").getSheetByName("Data");
  var rows = sheet.getDataRange().getValues();
  return ContentService.createTextOutput(JSON.stringify(rows));
}

function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Data");
  var params = JSON.parse(e.postData.contents);
  sheet.appendRow([params.nama, params.telepon, params.alamat]);
  return ContentService.createTextOutput("OK");
}
`
  },
  {
    id: 'approval-flow-po',
    name: 'Sistem Approval Purchase Order & Surat Jalan Logistik',
    tag: 'Workflow & Approval',
    description: 'Script alur persetujuan pengiriman barang logistik dengan email, belum memiliki log status dan validasi token.',
    code: `// Code.gs - Approval Alur Logistik
function onFormSubmit(e) {
  var values = e.values;
  var noSuratJalan = values[1];
  var driver = values[2];
  var tujuan = values[3];
  
  MailApp.sendEmail({
    to: "supervisor@perusahaan.com",
    subject: "Permintaan Approval Surat Jalan: " + noSuratJalan,
    htmlBody: "Surat jalan baru memerlukan persetujuan.<br>Driver: " + driver + "<br>Tujuan: " + tujuan
  });
}

function approveSuratJalan(noSuratJalan) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Surat_Jalan");
  var lastRow = sheet.getLastRow();
  for (var i = 2; i <= lastRow; i++) {
    if (sheet.getRange(i, 1).getValue() == noSuratJalan) {
      sheet.getRange(i, 5).setValue("APPROVED");
      break;
    }
  }
}
`
  }
];
