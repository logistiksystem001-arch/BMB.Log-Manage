import { AnalysisReport, GasMetrics, MissingFeature, SecurityVulnerability } from '../types';

export function runStaticGasAnalysis(code: string): AnalysisReport {
  const lines = code.split('\n');
  const totalLines = lines.length;

  // Function counting
  const functionMatches = code.match(/function\s+([a-zA-Z0-9_$]+)/g) || [];
  const totalFunctions = functionMatches.length;

  // Feature detection flags
  const hasLockService = /LockService\.(getScriptLock|getUserLock|getDocumentLock)/.test(code);
  const hasTryCatch = /try\s*\{[\s\S]*?\}\s*catch/.test(code);
  const hasPropertiesService = /PropertiesService\.(getScriptProperties|getUserProperties)/.test(code);
  const hasCacheService = /CacheService\.(getScriptCache|getUserCache)/.test(code);
  const hasSpreadsheetApp = /SpreadsheetApp\./.test(code);
  const isWebApp = /function\s+(doGet|doPost)/.test(code);
  const hasJsonReturn = /ContentService\.(createTextOutput|MimeType\.JSON)/.test(code);
  
  // Anti-pattern: getValue/setValue inside loops
  let loopsWithSingleCellCalls = 0;
  const loopRegex = /(for\s*\(|while\s*\(|\.forEach\s*\()[\s\S]*?\{[\s\S]*?\}/g;
  const loopMatches = code.match(loopRegex) || [];
  for (const loopBlock of loopMatches) {
    if (/(getValue|setValue)\(/.test(loopBlock) && !/(getValues|setValues)\(/.test(loopBlock)) {
      loopsWithSingleCellCalls++;
    }
  }

  // Security: Hardcoded tokens/secrets
  const hardcodedTokensDetected = /(bot[0-9]{8,10}:[a-zA-Z0-9_-]{35}|ghp_[a-zA-Z0-9]{36}|AIzaSy[a-zA-Z0-9_-]{33}|Bearer\s+[a-zA-Z0-9_\-\.]{20,})/i.test(code);
  const hardcodedSpreadsheetId = /openById\(['"][a-zA-Z0-9_-]{25,}['"]\)/.test(code);

  // Business logic flags
  const hasNegativeStockGuard = /(stok|stock|qty|jumlah|kuantitas)\s*(<|<=|===?)\s*0|(stok|stock|qty|jumlah)\s*-\s*(qty|order|jumlah)\s*<\s*0/i.test(code);
  const hasInputValidation = /(if\s*\(![a-zA-Z0-9_$.]+|throw\s+new\s+Error|parameter\.[a-zA-Z0-9_]+)/.test(code);
  const hasAuditLog = /(timestamp|waktu|created_at|updated_at|log|riwayat|histori|new Date\(\))/i.test(code);
  const hasBatchOperations = /getValues\(|setValues\(/.test(code);
  const hasRateLimitOrTimeoutGuard = /(Utilities\.sleep|Date\.now\(\)\s*-\s*startTime|executionTime|pagination|limit|offset)/i.test(code);

  // Calculate Health Score
  let score = 100;
  if (!hasLockService && hasSpreadsheetApp) score -= 20;
  if (!hasTryCatch) score -= 15;
  if (loopsWithSingleCellCalls > 0) score -= 18;
  if (!hasBatchOperations && hasSpreadsheetApp) score -= 10;
  if (hardcodedSpreadsheetId || hardcodedTokensDetected) score -= 12;
  if (!hasInputValidation && isWebApp) score -= 10;
  if (!hasAuditLog && hasSpreadsheetApp) score -= 8;
  if (!hasNegativeStockGuard) score -= 7;
  score = Math.max(15, Math.min(100, score));

  const metrics: GasMetrics = {
    totalLines,
    totalFunctions,
    hasLockService,
    hasTryCatch,
    hasBatchOperations,
    hasPropertiesService,
    hasCacheService,
    hasInputValidation,
    hasAuditLog,
    hasNegativeStockGuard,
    hasRateLimitOrTimeoutGuard,
    loopsWithSingleCellCalls,
    hardcodedTokensDetected: hardcodedTokensDetected || hardcodedSpreadsheetId,
    healthScore: score,
  };

  const missingFeatures: MissingFeature[] = [];

  // 1. LockService
  if (!hasLockService && hasSpreadsheetApp) {
    missingFeatures.push({
      id: 'lock-service',
      category: 'Keandalan & Transaksi',
      title: 'Mekanisme Concurrency (LockService)',
      severity: 'CRITICAL',
      whyImportant: 'Google Apps Script berjalan secara multi-thread. Jika 2 user atau 2 request API masuk dalam detik yang sama, keduanya akan membaca baris terakhir yang sama dan saling menimpa (Race Condition).',
      impactIfMissing: 'Data transaksi ganda, stok selisih, nomor urut invoice tumpang tindih, atau baris data tertimpa tanpa jejak.',
      solutionSnippet: `const lock = LockService.getScriptLock();
try {
  // Tunggu maksimal 15-30 detik jika ada proses lain yang sedang menulis
  lock.waitLock(30000);
  
  // Eksekusi penulisan spreadsheet di sini
  // ...
  SpreadsheetApp.flush(); // Pastikan perubahan langsung disimpan
} catch (e) {
  return createJsonResponse({ success: false, message: 'Server sibuk, coba beberapa saat lagi: ' + e.message });
} finally {
  lock.releaseLock(); // Selalu lepas lock di block finally
}`,
      detectedStatus: 'MISSING',
    });
  } else if (hasLockService) {
    missingFeatures.push({
      id: 'lock-service',
      category: 'Keandalan & Transaksi',
      title: 'Mekanisme Concurrency (LockService)',
      severity: 'INFO',
      whyImportant: 'LockService telah terdeteksi, membantu mencegah tabrakan data antar-user.',
      impactIfMissing: 'Data aman dari race condition.',
      solutionSnippet: '// Sudah diimplementasikan di kode Anda.',
      detectedStatus: 'IMPLEMENTED',
    });
  }

  // 2. Try-Catch & Standard Error Response
  if (!hasTryCatch) {
    missingFeatures.push({
      id: 'error-handling',
      category: 'Keandalan & Transaksi',
      title: 'Global Try-Catch & Standarisasi Return JSON',
      severity: 'HIGH',
      whyImportant: 'Tanpa try-catch, jika terjadi error (sheet tidak ditemukan, kuota habis, format tanggal salah), script akan langsung crash dan menampilkan error HTML Google 500 yang tidak bisa dibaca oleh frontend/aplikasi klien.',
      impactIfMissing: 'Aplikasi klien (React/Android/Web) crash tanpa pesan error yang manusiawi; kegagalan diam-diam tanpa log.',
      solutionSnippet: `function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    // Logika proses...
    return createJsonResponse({ success: true, message: 'Berhasil diproses', data: result });
  } catch (err) {
    console.error('CRITICAL ERROR doPost:', err.stack);
    return createJsonResponse({ success: false, message: err.message || 'Terjadi kesalahan sistem' });
  }
}

function createJsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}`,
      detectedStatus: 'MISSING',
    });
  }

  // 3. Batch Read/Write vs Cell-by-cell loops
  if (loopsWithSingleCellCalls > 0 || (!hasBatchOperations && hasSpreadsheetApp)) {
    missingFeatures.push({
      id: 'batch-operations',
      category: 'Performa & Kuota',
      title: 'Operasi Batch (getValues & setValues massal)',
      severity: loopsWithSingleCellCalls > 0 ? 'CRITICAL' : 'HIGH',
      whyImportant: 'Setiap pemanggilan getRange().getValue() atau setValue() memakan waktu 80-200ms per panggilan API ke server Google. Membaca 100 baris satu per satu butuh 15-20 detik dan sering terkena batas kuota "Exceeded maximum execution time" (6 menit).',
      impactIfMissing: 'Script lemot, timeout 6 menit saat data bertambah banyak, dan kuota Google Sheets API harian cepat habis.',
      solutionSnippet: `// JANGAN: sheet.getRange(i, 1).getValue() di dalam loop for!
// GUNAKAN BATCH:
const allValues = sheet.getDataRange().getValues(); // 1 kali call API untuk ribuan baris!
const headers = allValues[0];
const rows = allValues.slice(1);

// Modifikasi data di JavaScript memori (sangat cepat):
const rowsToAppend = [];
rowsToAppend.push([new Date(), 'SKU-001', 'Barang Masuk', 50]);

// Simpan sekaligus 1 kali call:
sheet.getRange(sheet.getLastRow() + 1, 1, rowsToAppend.length, rowsToAppend[0].length)
  .setValues(rowsToAppend);`,
      detectedStatus: 'MISSING',
    });
  }

  // 4. Logistics: Proteksi Stok Minus & Validasi SKU
  if (!hasNegativeStockGuard) {
    missingFeatures.push({
      id: 'negative-stock-guard',
      category: 'Fitur Bisnis/Logistik',
      title: 'Validasi Stok Minus & Atomic Stock Deduction',
      severity: 'HIGH',
      whyImportant: 'Dalam sistem gudang atau inventory, pengurangan stok barang keluar harus divalidasi agar stok tidak menjadi minus (< 0) jika ada pesanan mendadak atau persediaan fisik kosong.',
      impactIfMissing: 'Gudang mengalami over-selling (menjual barang yang tidak ada stoknya), data inventaris tidak sinkron dengan fisik.',
      solutionSnippet: `function reduceStock(sku, qtyToDeduct) {
  const sheet = getSheet('Master_Barang');
  const data = sheet.getDataRange().getValues();
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === sku) { // Kolom 0 = SKU
      const currentStock = Number(data[i][3]) || 0; // Kolom 3 = Sisa Stok
      if (currentStock < qtyToDeduct) {
        throw new Error('Stok barang [' + sku + '] tidak mencukupi! Sisa: ' + currentStock + ', diminta: ' + qtyToDeduct);
      }
      
      const newStock = currentStock - qtyToDeduct;
      sheet.getRange(i + 1, 4).setValue(newStock); // Update stok
      return { sku, previousStock: currentStock, newStock };
    }
  }
  throw new Error('Barang dengan SKU ' + sku + ' tidak ditemukan!');
}`,
      detectedStatus: 'MISSING',
    });
  }

  // 5. Audit Trail & Auto Timestamps
  if (!hasAuditLog) {
    missingFeatures.push({
      id: 'audit-trail',
      category: 'Fitur Bisnis/Logistik',
      title: 'Audit Trail & Tracking Perubahan Data',
      severity: 'MEDIUM',
      whyImportant: 'Setiap transaksi logistik (masuk/keluar/penyesuaian stok) wajib mencatat waktu (Timestamp ISO/WIB), ID Transaksi unik, dan nama/email petugas untuk keperluan audit dan investigasi selisih barang.',
      impactIfMissing: 'Jika terjadi barang hilang atau selisih hitungan saat stock opname, tidak bisa ditelusuri siapa dan kapan transaksi tersebut dibuat.',
      solutionSnippet: `function logTransaction(txType, sku, qty, notes, operator) {
  const logSheet = getSheet('Log_Transaksi');
  const txId = 'TX-' + Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyyMMdd-HHmmss') + '-' + Math.floor(Math.random() * 1000);
  const timestamp = Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyy-MM-dd HH:mm:ss');
  
  logSheet.appendRow([
    txId,
    timestamp,
    operator || Session.getActiveUser().getEmail() || 'System',
    txType, // 'MASUK' | 'KELUAR' | 'PENYESUAIAN'
    sku,
    qty,
    notes || '-'
  ]);
  return txId;
}`,
      detectedStatus: 'MISSING',
    });
  }

  // 6. PropertiesService & Rahasia / ID Spreadsheet
  if (hardcodedSpreadsheetId || hardcodedTokensDetected || !hasPropertiesService) {
    missingFeatures.push({
      id: 'properties-service',
      category: 'Keamanan & Autentikasi',
      title: 'Pemisahan Konfigurasi (PropertiesService)',
      severity: 'HIGH',
      whyImportant: 'Menaruh ID Spreadsheet, Token Bot Telegram, atau URL Webhook secara hardcoded di dalam script rawan bocor saat kode dibagikan ke orang lain dan menyulitkan saat berganti file produksi/pengujian.',
      impactIfMissing: 'Kredensial dan ID Spreadsheet bocor; sulit switch antara spreadsheet testing dan spreadsheet live.',
      solutionSnippet: `// Simpan di Project Settings -> Script Properties (Bukan hardcode):
const props = PropertiesService.getScriptProperties();
const SPREADSHEET_ID = props.getProperty('SPREADSHEET_ID');
const TELEGRAM_TOKEN = props.getProperty('TELEGRAM_BOT_TOKEN');
const ADMIN_EMAIL = props.getProperty('ADMIN_EMAIL');

function getSpreadsheet() {
  if (SPREADSHEET_ID) {
    return SpreadsheetApp.openById(SPREADSHEET_ID);
  }
  return SpreadsheetApp.getActiveSpreadsheet(); // Fallback jika container-bound
}`,
      detectedStatus: 'MISSING',
    });
  }

  // 7. Caching dengan CacheService
  if (!hasCacheService) {
    missingFeatures.push({
      id: 'cache-service',
      category: 'Performa & Kuota',
      title: 'In-Memory Caching (CacheService)',
      severity: 'MEDIUM',
      whyImportant: 'Data master barang / daftar gudang jarang berubah setiap detik. Menyimpannya di CacheService selama 10-60 menit mengurangi waktu loading API dari 1.5 detik menjadi kurang dari 100 milidetik.',
      impactIfMissing: 'API terasa lambat untuk data lookup berulang, dan menghabiskan jatah kuota Spreadsheet read.',
      solutionSnippet: `function getCachedMasterBarang() {
  const cache = CacheService.getScriptCache();
  const cachedData = cache.get('MASTER_BARANG');
  
  if (cachedData) {
    return JSON.parse(cachedData);
  }
  
  // Ambil dari sheet jika belum ada di cache
  const sheet = getSheet('Master_Barang');
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const items = values.slice(1).map(row => ({
    sku: row[0],
    nama: row[1],
    kategori: row[2],
    stok: row[3],
    satuan: row[4]
  }));
  
  // Simpan di cache selama 30 menit (1800 detik)
  cache.put('MASTER_BARANG', JSON.stringify(items), 1800);
  return items;
}`,
      detectedStatus: 'MISSING',
    });
  }

  // 8. Integrasi Notifikasi (Telegram/WhatsApp/Email)
  missingFeatures.push({
    id: 'notification-alert',
    category: 'Integrasi & Notifikasi',
    title: 'Notifikasi Otomatis (Email / Telegram / Webhook)',
    severity: 'MEDIUM',
    whyImportant: 'Jika stok menipis (di bawah batas minimum) atau terjadi error fatal pada proses transaksi, tim logistik perlu segera menerima notifikasi tanpa harus memantau spreadsheet terus-menerus.',
    impactIfMissing: 'Stok habis tidak diketahui pengadaan barang; pesanan tertunda tanpa ada alert.',
    solutionSnippet: `function sendLowStockAlert(sku, namaBarang, sisaStok, minStok) {
  const subject = \`[ALERT STOK KRITIS] \${namaBarang} (\${sku})\`;
  const body = \`Perhatian Tim Logistik,\\n\\nBarang: \${namaBarang}\\nSKU: \${sku}\\nSisa Stok: \${sisaStok}\\nBatas Minimum: \${minStok}\\n\\nSegera lakukan Purchase Order (PO) pengadaan barang.\`;
  
  // Menggunakan GmailApp bawaan Google:
  MailApp.sendEmail({
    to: 'logistik.system001@gmail.com',
    subject: subject,
    body: body
  });
}`,
    detectedStatus: 'MISSING',
  });

  // Security vulnerabilities
  const vulnerabilities: SecurityVulnerability[] = [];

  if (hardcodedSpreadsheetId || hardcodedTokensDetected) {
    vulnerabilities.push({
      id: 'vuln-hardcoded-keys',
      title: 'Kredensial atau ID Spreadsheet Hardcoded',
      severity: 'HIGH',
      description: 'Ditemukan ID Spreadsheet atau Token langsung ditulis di baris kode, berisiko tinggi terekspos saat script di-share.',
      remedy: 'Pindahkan ke PropertiesService.getScriptProperties().',
    });
  }

  if (!hasLockService && hasSpreadsheetApp) {
    vulnerabilities.push({
      id: 'vuln-race-condition',
      title: 'Kerentanan Race Condition (Data Korup saat Simultan)',
      severity: 'CRITICAL',
      description: 'Ketika dua transaksi atau dua petugas menyimpan data dalam milidetik yang berdekatan, baris spreadsheet akan bertabrakan atau saling overwrite.',
      remedy: 'Gunakan LockService.getScriptLock() dengan waitLock(30000) dan finally { lock.releaseLock() }.',
    });
  }

  if (isWebApp && !hasInputValidation) {
    vulnerabilities.push({
      id: 'vuln-no-input-validation',
      title: 'Tidak Ada Validasi Payload Request',
      severity: 'MEDIUM',
      description: 'Parameter doGet/doPost diproses langsung tanpa verifikasi tipe data, field kosong, atau batasan nilai.',
      remedy: 'Buat fungsi validatePayload(data, requiredFields) sebelum mengeksekusi operasi database.',
    });
  }

  const performanceAdvice: string[] = [
    'Batasi pemanggilan SpreadsheetApp API sesedikit mungkin: gunakan getValues() dan setValues() satu kali untuk array besar.',
    'Batas waktu eksekusi Google Apps Script adalah 6 menit (360 detik) per trigger. Untuk impor/proses ribuan baris, gunakan mekanisme Batch Chunking atau Time-based Trigger.',
    'Gunakan SpreadsheetApp.flush() hanya pada titik akhir transaksi kritis untuk memastikan I/O selesai sebelum melepaskan lock.',
    'Manfaatkan CacheService untuk query read-only yang sering diakses seperti master produk, daftar gudang, dan konfigurasi sistem.'
  ];

  const logisticsAdvice: string[] = [
    'Terapkan Unique Transaction ID dengan format standar (contoh: IN-YYYYMMDD-XXXXX untuk barang masuk, OUT-YYYYMMDD-XXXXX untuk barang keluar).',
    'Sertakan verifikasi Satuan (UoM: Pcs, Box, Pallet, Kg) agar tidak terjadi konversi satuan yang keliru saat pencatatan.',
    'Tambahkan Sheet "Audit_Log" otomatis yang mencatat siapa pengubah data (User Email), waktu, perubahan stok lama ke baru.',
    'Sediakan Fitur Soft Delete / Status Flag ("ACTIVE", "ARCHIVED", "CANCELLED") daripada menghapus baris spreadsheet secara permanen.'
  ];

  let summary = `Kode Google Apps Script Anda memiliki ${totalLines} baris dengan ${totalFunctions} fungsi terdeteksi. `;
  if (score >= 80) {
    summary += 'Struktur script sudah cukup baik, namun terdapat beberapa penyempurnaan fitur dan proteksi transaksi yang disarankan.';
  } else if (score >= 50) {
    summary += 'Terdapat fitur krusial yang masih kurang (seperti Concurrency Lock, Batching, atau Error Handling standar) yang berpotensi menimbulkan data korup atau timeout kuota.';
  } else {
    summary += 'Script membutuhkan refactoring penting untuk sistem logistik/bisnis handal, terutama penanganan LockService, operasi batch, dan validasi data transaksi.';
  }

  return {
    summary,
    healthScore: score,
    metrics,
    missingFeatures,
    vulnerabilities,
    performanceAdvice,
    logisticsAdvice,
  };
}
