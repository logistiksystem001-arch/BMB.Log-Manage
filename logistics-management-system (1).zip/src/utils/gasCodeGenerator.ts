export function generateProductionGasCode(originalCode: string, options: {
  includeLockService?: boolean;
  includeNegativeStockGuard?: boolean;
  includeAuditTrail?: boolean;
  includeCacheService?: boolean;
  includeLowStockAlert?: boolean;
  includeBatchOptimization?: boolean;
} = {}): string {
  const opts = {
    includeLockService: true,
    includeNegativeStockGuard: true,
    includeAuditTrail: true,
    includeCacheService: true,
    includeLowStockAlert: true,
    includeBatchOptimization: true,
    ...options,
  };

  return `/**
 * =========================================================================
 * GOOGLE APPS SCRIPT (Code.gs) - PRODUCTION READY LOGISTICS & INVENTORY
 * Ditingkatkan otomatis dengan standar keamanan, performa & audit trail
 * =========================================================================
 */

// 1. KONFIGURASI APLIKASI
const CONFIG = {
  TZ: 'Asia/Jakarta',
  LOCK_TIMEOUT_MS: 30000, // 30 detik batas tunggu antrean
  CACHE_EXPIRATION_SEC: 1800, // 30 menit cache master barang
  LOW_STOCK_THRESHOLD: 10, // Batas minimal notifikasi restock
  SHEET_NAMES: {
    MASTER_BARANG: 'Stok_Barang',
    TRANSAKSI_LOG: 'Log_Transaksi',
    PENGATURAN: 'Config'
  }
};

/**
 * Endpoint POST Web App (Menerima input transaksi barang dari Web/Mobile/Scanner)
 */
function doPost(e) {
  ${opts.includeLockService ? `// [FITUR 1] Cegah Race Condition & Kerusakan Data Simultan
  const lock = LockService.getScriptLock();
  try {
    const hasLock = lock.waitLock(CONFIG.LOCK_TIMEOUT_MS);
    if (!hasLock) {
      return jsonResponse(false, 'Server sedang melayani antrean transaksi lain, silakan ulangi sesaat lagi.', null, 429);
    }` : `try {`}

    // Parsing payload
    if (!e || !e.postData || !e.postData.contents) {
      return jsonResponse(false, 'Payload kosong atau format request tidak valid', null, 400);
    }
    
    const payload = JSON.parse(e.postData.contents);
    const { action, aksi, sku, jumlah, qty, operator, catatan, namaBarang, kategori, harga } = payload;
    
    const cmd = (action || aksi || '').toUpperCase();
    const targetSku = String(sku || '').trim();
    const quantity = Number(jumlah || qty || 0);

    // Validasi input dasar
    if (!targetSku && cmd !== 'GET_ALL') {
      return jsonResponse(false, 'SKU barang wajib diisi', null, 400);
    }

    let result = null;

    switch (cmd) {
      case 'MASUK':
      case 'IN':
        result = processStockTransaction('MASUK', targetSku, quantity, operator, catatan);
        break;

      case 'KELUAR':
      case 'OUT':
        result = processStockTransaction('KELUAR', targetSku, quantity, operator, catatan);
        break;

      case 'TAMBAH_BARU':
      case 'CREATE':
        result = addNewProduct(targetSku, namaBarang, kategori, quantity, harga);
        break;

      default:
        return jsonResponse(false, 'Aksi tidak dikenali: ' + cmd, null, 400);
    }

    // Pastikan semua perubahan tersimpan ke Google Sheets sebelum lock dilepas
    SpreadsheetApp.flush();
    return jsonResponse(true, 'Transaksi berhasil diproses', result);

  } catch (error) {
    console.error('CRITICAL ERROR doPost:', error.stack || error.message);
    return jsonResponse(false, 'Gagal memproses transaksi: ' + error.message, null, 500);
  } finally {
    ${opts.includeLockService ? `// Selalu lepaskan lock dalam blok finally
    lock.releaseLock();` : ''}
  }
}

/**
 * Endpoint GET Web App (Membaca data inventaris & pencarian barang)
 */
function doGet(e) {
  try {
    const params = e ? e.parameter : {};
    const sku = params.sku;
    
    if (sku) {
      const item = getProductBySku(sku);
      if (!item) return jsonResponse(false, 'Barang tidak ditemukan', null, 404);
      return jsonResponse(true, 'Data barang ditemukan', item);
    }

    // Ambil semua daftar barang (dengan in-memory caching untuk kecepatan)
    const items = getAllProductsCached();
    return jsonResponse(true, 'Berhasil memuat daftar inventaris', items);
  } catch (err) {
    console.error('Error doGet:', err.message);
    return jsonResponse(false, err.message, null, 500);
  }
}

/**
 * [FITUR 2 & 3] Pemrosesan Stok Transaksional dengan Proteksi Stok Minus & Batch Read
 */
function processStockTransaction(type, sku, qty, operator, notes) {
  if (qty <= 0) {
    throw new Error('Jumlah barang harus lebih besar dari 0!');
  }

  const ss = getSpreadsheet();
  const sheet = getOrCreateSheet(ss, CONFIG.SHEET_NAMES.MASTER_BARANG, ['SKU', 'Nama Barang', 'Kategori', 'Stok', 'Satuan', 'Terakhir Update']);
  
  // [OPTIMASI BATCH] Ambil seluruh data dalam 1 API call untuk performa tinggi
  const data = sheet.getDataRange().getValues();
  if (data.length <= 1) {
    throw new Error('Master barang masih kosong!');
  }

  let foundRowIndex = -1;
  let currentStock = 0;
  let productName = '';

  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).toUpperCase() === sku.toUpperCase()) {
      foundRowIndex = i + 1; // 1-based index untuk getRange
      productName = data[i][1];
      currentStock = Number(data[i][3]) || 0;
      break;
    }
  }

  if (foundRowIndex === -1) {
    throw new Error('Barang dengan SKU [' + sku + '] tidak terdaftar di sistem!');
  }

  ${opts.includeNegativeStockGuard ? `// [FITUR 4] Proteksi Stok Minus
  if (type === 'KELUAR' && currentStock < qty) {
    throw new Error('Stok barang [' + sku + ' - ' + productName + '] TIDAK CUKUP! Tersedia: ' + currentStock + ', Diminta: ' + qty);
  }` : ''}

  const newStock = type === 'MASUK' ? (currentStock + qty) : (currentStock - qty);
  const nowFormatted = Utilities.formatDate(new Date(), CONFIG.TZ, 'yyyy-MM-dd HH:mm:ss');

  // Update stok & waktu update di baris terkait
  sheet.getRange(foundRowIndex, 4).setValue(newStock);
  sheet.getRange(foundRowIndex, 6).setValue(nowFormatted);

  ${opts.includeAuditTrail ? `// [FITUR 5] Catat Riwayat Transaksi (Audit Trail)
  const txId = recordAuditLog(type, sku, productName, qty, currentStock, newStock, operator, notes);` : `const txId = 'TX-' + Date.now();`}

  ${opts.includeLowStockAlert ? `// [FITUR 6] Pengecekan Batas Stok Kritis
  if (newStock <= CONFIG.LOW_STOCK_THRESHOLD) {
    triggerLowStockNotification(sku, productName, newStock);
  }` : ''}

  ${opts.includeCacheService ? `// Bersihkan cache produk agar pemanggilan selanjutnya mendapatkan stok terbaru
  invalidateCache();` : ''}

  return {
    transactionId: txId,
    sku: sku,
    namaBarang: productName,
    tipe: type,
    jumlah: qty,
    stokSebelumnya: currentStock,
    stokSekarang: newStock,
    waktu: nowFormatted
  };
}

/**
 * Menambahkan Produk Baru ke Master Barang
 */
function addNewProduct(sku, nama, kategori, stokAwal, harga) {
  const ss = getSpreadsheet();
  const sheet = getOrCreateSheet(ss, CONFIG.SHEET_NAMES.MASTER_BARANG, ['SKU', 'Nama Barang', 'Kategori', 'Stok', 'Satuan', 'Terakhir Update']);
  
  // Validasi apakah SKU sudah ada
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).toUpperCase() === sku.toUpperCase()) {
      throw new Error('SKU [' + sku + '] sudah digunakan untuk: ' + data[i][1]);
    }
  }

  const nowFormatted = Utilities.formatDate(new Date(), CONFIG.TZ, 'yyyy-MM-dd HH:mm:ss');
  sheet.appendRow([sku, nama || 'Tanpa Nama', kategori || 'Umum', stokAwal || 0, 'Pcs', nowFormatted]);
  
  ${opts.includeAuditTrail ? `recordAuditLog('PRODUK_BARU', sku, nama, stokAwal || 0, 0, stokAwal || 0, 'System', 'Inisialisasi Master Data');` : ''}
  ${opts.includeCacheService ? `invalidateCache();` : ''}

  return { sku, nama, stokAwal: stokAwal || 0 };
}

${opts.includeAuditTrail ? `/**
 * [AUDIT TRAIL] Mencatat seluruh riwayat mutasi stok ke sheet log
 */
function recordAuditLog(type, sku, namaBarang, qty, stokLama, stokBaru, operator, catatan) {
  const ss = getSpreadsheet();
  const logSheet = getOrCreateSheet(ss, CONFIG.SHEET_NAMES.TRANSAKSI_LOG, [
    'ID Transaksi', 'Timestamp', 'Operator', 'Tipe Mutasi', 'SKU', 'Nama Barang', 'Qty', 'Stok Awal', 'Stok Akhir', 'Catatan'
  ]);

  const timestamp = Utilities.formatDate(new Date(), CONFIG.TZ, 'yyyy-MM-dd HH:mm:ss');
  const txId = 'TX-' + Utilities.formatDate(new Date(), CONFIG.TZ, 'yyyyMMdd-HHmmss') + '-' + Math.floor(Math.random() * 1000);
  
  logSheet.appendRow([
    txId,
    timestamp,
    operator || Session.getActiveUser().getEmail() || 'Operator Gudang',
    type,
    sku,
    namaBarang,
    qty,
    stokLama,
    stokBaru,
    catatan || '-'
  ]);

  return txId;
}` : ''}

${opts.includeLowStockAlert ? `/**
 * [ALERT NOTIFIKASI] Notifikasi Otomatis saat Stok di Bawah Batas Minimum
 */
function triggerLowStockNotification(sku, namaBarang, sisaStok) {
  try {
    const adminEmail = PropertiesService.getScriptProperties().getProperty('ADMIN_EMAIL') || Session.getActiveUser().getEmail();
    if (!adminEmail) return;

    MailApp.sendEmail({
      to: adminEmail,
      subject: '[PERINGATAN LOGISTIK] Stok Menipis: ' + namaBarang + ' (' + sku + ')',
      htmlBody: '<h3>Perhatian Tim Logistik & Gudang</h3>' +
                '<p>Barang berikut telah mencapai batas stok minimum:</p>' +
                '<ul>' +
                '<li><b>SKU:</b> ' + sku + '</li>' +
                '<li><b>Nama Barang:</b> ' + namaBarang + '</li>' +
                '<li><b>Sisa Stok:</b> <span style="color:red; font-size:16px;">' + sisaStok + '</span></li>' +
                '<li><b>Batas Minimum:</b> ' + CONFIG.LOW_STOCK_THRESHOLD + '</li>' +
                '</ul>' +
                '<p>Segera lakukan pemesanan ulang (Purchase Order / Restock).</p>'
    });
  } catch (err) {
    console.warn('Gagal mengirim email alert stok: ' + err.message);
  }
}` : ''}

${opts.includeCacheService ? `/**
 * [CACHE SERVICE] Ambil seluruh inventaris dengan memori cache 30 menit
 */
function getAllProductsCached() {
  const cache = CacheService.getScriptCache();
  const cached = cache.get('INVENTORY_PRODUCTS');
  if (cached) {
    return JSON.parse(cached);
  }

  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(CONFIG.SHEET_NAMES.MASTER_BARANG);
  if (!sheet) return [];

  const values = sheet.getDataRange().getValues();
  if (values.length <= 1) return [];

  const items = [];
  for (let i = 1; i < values.length; i++) {
    items.push({
      sku: values[i][0],
      nama: values[i][1],
      kategori: values[i][2],
      stok: Number(values[i][3]) || 0,
      satuan: values[i][4],
      terakhirUpdate: values[i][5]
    });
  }

  cache.put('INVENTORY_PRODUCTS', JSON.stringify(items), CONFIG.CACHE_EXPIRATION_SEC);
  return items;
}

function invalidateCache() {
  try {
    CacheService.getScriptCache().remove('INVENTORY_PRODUCTS');
  } catch (e) {}
}` : ''}

/**
 * HELPER: Dapatkan Spreadsheet Aman (Mendukung Container-bound & Standalone via PropertiesService)
 */
function getSpreadsheet() {
  const customId = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  if (customId) {
    return SpreadsheetApp.openById(customId);
  }
  return SpreadsheetApp.getActiveSpreadsheet();
}

/**
 * HELPER: Ambil atau Buat Sheet Otomatis beserta Header jika belum ada
 */
function getOrCreateSheet(ss, sheetName, defaultHeaders) {
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
    if (defaultHeaders && defaultHeaders.length > 0) {
      sheet.appendRow(defaultHeaders);
      sheet.getRange(1, 1, 1, defaultHeaders.length).setFontWeight('bold').setBackground('#E2E8F0');
      sheet.setFrozenRows(1);
    }
  }
  return sheet;
}

/**
 * HELPER: Format Standar JSON Response untuk Web App / API Client
 */
function jsonResponse(success, message, data, statusCode) {
  const output = {
    success: success,
    status: statusCode || (success ? 200 : 400),
    message: message || '',
    data: data || null,
    timestamp: new Date().toISOString()
  };

  return ContentService.createTextOutput(JSON.stringify(output))
    .setMimeType(ContentService.MimeType.JSON);
}
`;
}
