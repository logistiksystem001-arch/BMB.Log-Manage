import React from 'react';
import { FileCode, Sparkles, ShieldCheck, RefreshCw, Upload, Terminal } from 'lucide-react';

interface HeaderProps {
  onLoadPreset: (presetId: string) => void;
  onFileUpload: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onReset: () => void;
  isAnalyzing: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onLoadPreset,
  onFileUpload,
  onReset,
  isAnalyzing,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-teal-500/20">
            <FileCode className="w-5 h-5 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-lg tracking-tight text-slate-100">
                GAS Code.gs Analyzer
              </span>
              <span className="text-[10px] uppercase font-semibold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Logistik & Enterprise
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Audit Fitur, Deteksi Celah, Concurrency & Optimasi Kuota Google Apps Script
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Preset selector */}
          <div className="relative">
            <select
              onChange={(e) => {
                if (e.target.value) onLoadPreset(e.target.value);
              }}
              defaultValue=""
              className="bg-slate-800 border border-slate-700 text-xs text-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-500 cursor-pointer hover:bg-slate-750 transition"
            >
              <option value="" disabled>
                📂 Muat Contoh Code.gs...
              </option>
              <option value="logistics-inventory-basic">📦 Logistik & Stok Gudang (Dasar)</option>
              <option value="webapp-api-crud">🌐 REST API CRUD Spreadsheet</option>
              <option value="approval-flow-po">📝 Approval Surat Jalan & PO</option>
            </select>
          </div>

          {/* File Upload Button */}
          <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200 transition">
            <Upload className="w-3.5 h-3.5 text-teal-400" />
            <span className="hidden md:inline">Upload .gs / .js</span>
            <input
              type="file"
              accept=".gs,.js,.txt"
              className="hidden"
              onChange={onFileUpload}
            />
          </label>

          {/* Reset button */}
          <button
            onClick={onReset}
            title="Reset kode"
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
