import React from 'react';
import { Play, Sparkles, Copy, Check, FileText, AlertCircle, Wand2 } from 'lucide-react';

interface CodeInputSectionProps {
  code: string;
  onChangeCode: (newCode: string) => void;
  systemContext: string;
  onChangeSystemContext: (ctx: string) => void;
  onAnalyze: () => void;
  onTriggerAiAnalysis: () => void;
  isAiLoading: boolean;
  copied: boolean;
  onCopyCode: () => void;
}

export const CodeInputSection: React.FC<CodeInputSectionProps> = ({
  code,
  onChangeCode,
  systemContext,
  onChangeSystemContext,
  onAnalyze,
  onTriggerAiAnalysis,
  isAiLoading,
  copied,
  onCopyCode,
}) => {
  const lineCount = code ? code.split('\n').length : 0;
  const charCount = code.length;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col h-full">
      {/* Editor Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
          <h2 className="text-sm font-semibold text-slate-200">
            Editor Sumber: <span className="text-teal-400 font-mono">Code.gs</span>
          </h2>
          <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
            {lineCount} baris · {charCount.toLocaleString()} karakter
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* System Context Selector */}
          <select
            value={systemContext}
            onChange={(e) => onChangeSystemContext(e.target.value)}
            className="text-xs bg-slate-800 text-slate-300 border border-slate-700 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-teal-500"
          >
            <option value="Sistem Logistik & Inventaris Gudang">📦 Konteks: Logistik & Stok Gudang</option>
            <option value="Web App API (doGet/doPost)">🌐 Konteks: Web App API REST</option>
            <option value="Surat Jalan & Pengiriman">🚚 Konteks: Ekspedisi / Surat Jalan</option>
            <option value="Sistem Pembelian / Purchase Order (PO)">📑 Konteks: Procurement & PO</option>
            <option value="Umum / Google Sheets Automation">⚙️ Konteks: Otomasi Spreadsheet Umum</option>
          </select>

          {code && (
            <button
              onClick={onCopyCode}
              className="p-1.5 text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-md transition flex items-center gap-1"
              title="Salin kode input"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>
      </div>

      {/* Code Area */}
      <div className="relative flex-1 mt-3 min-h-[320px] max-h-[500px] flex flex-col">
        <textarea
          value={code}
          onChange={(e) => onChangeCode(e.target.value)}
          placeholder="Tempelkan (paste) kode Code.gs Anda di sini untuk dianalisa fiturnya...&#10;&#10;Contoh fungsi:&#10;function doPost(e) { ... }&#10;function processOrder() { ... }"
          className="w-full flex-1 p-3.5 font-mono text-xs sm:text-sm bg-slate-950 text-slate-200 rounded-xl border border-slate-800/80 focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500/50 resize-none leading-relaxed selection:bg-teal-500/30 overflow-y-auto"
          spellCheck={false}
        />
        {!code.trim() && (
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
            <div className="text-center p-6 bg-slate-900/90 rounded-xl border border-dashed border-slate-700/80 max-w-sm">
              <FileText className="w-8 h-8 text-slate-500 mx-auto mb-2" />
              <p className="text-sm font-medium text-slate-300">Belum ada kode yang dimasukkan</p>
              <p className="text-xs text-slate-500 mt-1">
                Silakan tempel (paste) script <code className="text-teal-400">Code.gs</code> Anda atau pilih salah satu contoh di menu atas.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Action Footer */}
      <div className="mt-4 pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <AlertCircle className="w-3.5 h-3.5 text-teal-400 flex-shrink-0" />
          <span>Audit mencakup Concurrency, Race Condition, Kuota Google, dan Fitur Gudang.</span>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={onAnalyze}
            disabled={!code.trim()}
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-medium border border-slate-700 disabled:opacity-40 disabled:pointer-events-none transition shadow-sm cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 text-teal-400" />
            <span>Audit Statis Instan</span>
          </button>

          <button
            onClick={onTriggerAiAnalysis}
            disabled={!code.trim() || isAiLoading}
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 text-slate-950 text-xs sm:text-sm font-bold shadow-lg shadow-teal-500/20 disabled:opacity-50 disabled:pointer-events-none transition cursor-pointer"
          >
            {isAiLoading ? (
              <>
                <Wand2 className="w-3.5 h-3.5 animate-spin" />
                <span>Menganalisis dengan AI...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Analisa Fitur Mendalam (AI)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
