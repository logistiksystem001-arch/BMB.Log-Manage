import React from 'react';
import { AnalysisReport } from '../types';
import {
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Zap,
  Clock,
  Layers,
  Database,
  KeyRound,
  FileCheck2,
} from 'lucide-react';

interface AnalysisOverviewProps {
  report: AnalysisReport;
}

export const AnalysisOverview: React.FC<AnalysisOverviewProps> = ({ report }) => {
  const { healthScore, metrics, summary } = report;

  // Determine score color
  let scoreBadgeColor = 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10';
  let scoreText = 'Sangat Baik & Matang';
  if (healthScore < 50) {
    scoreBadgeColor = 'text-rose-400 border-rose-500/30 bg-rose-500/10';
    scoreText = 'Kritis - Banyak Fitur Kurang';
  } else if (healthScore < 80) {
    scoreBadgeColor = 'text-amber-400 border-amber-500/30 bg-amber-500/10';
    scoreText = 'Cukup - Butuh Peningkatan';
  }

  const metricCards = [
    {
      label: 'LockService (Concurrency)',
      active: metrics.hasLockService,
      critical: true,
      descIfOff: 'RAWAN data tabrakan/overwrite saat transaksi bersamaan',
      descIfOn: 'Aman dari race condition',
      icon: Layers,
    },
    {
      label: 'Proteksi Stok Minus',
      active: metrics.hasNegativeStockGuard,
      critical: true,
      descIfOff: 'Stok barang bisa jebol menjadi negatif',
      descIfOn: 'Validasi stok minimum aktif',
      icon: Database,
    },
    {
      label: 'Operasi Batch (getValues/setValues)',
      active: metrics.hasBatchOperations && metrics.loopsWithSingleCellCalls === 0,
      critical: true,
      descIfOff: metrics.loopsWithSingleCellCalls > 0
        ? `Ditemukan loop get/setValue (${metrics.loopsWithSingleCellCalls} loop rawan kuota)`
        : 'Belum menggunakan batching array',
      descIfOn: 'Optimal, hemat kuota Google Spreadsheet',
      icon: Zap,
    },
    {
      label: 'Global Try-Catch & Return JSON',
      active: metrics.hasTryCatch,
      critical: false,
      descIfOff: 'Jika error, Web App menampilkan 500 HTML mentah',
      descIfOn: 'Error ditangkap dengan respon JSON terstruktur',
      icon: ShieldAlert,
    },
    {
      label: 'Audit Trail & Timestamp Otomatis',
      active: metrics.hasAuditLog,
      critical: false,
      descIfOff: 'Mutasi stok tidak mencatat histori waktu & operator',
      descIfOn: 'Riwayat mutasi tercatat untuk investigasi',
      icon: FileCheck2,
    },
    {
      label: 'Pemisahan Kredensial (PropertiesService)',
      active: !metrics.hardcodedTokensDetected,
      critical: false,
      descIfOff: 'ID Spreadsheet / Kunci rahasia tertulis langsung di kode',
      descIfOn: 'Konfigurasi aman dan modular',
      icon: KeyRound,
    },
  ];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5">
      {/* Top Banner: Score & Summary */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-4 rounded-xl bg-slate-950/70 border border-slate-800">
        <div className="flex items-center gap-4">
          {/* Circular Score */}
          <div className="relative flex items-center justify-center w-20 h-20 rounded-2xl bg-slate-900 border-2 border-slate-700/80 shadow-inner flex-shrink-0">
            <div className="text-center">
              <span className="text-2xl font-black text-slate-100">{healthScore}</span>
              <span className="text-[10px] text-slate-400 block -mt-1">/ 100</span>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100">Skor Kesiapan Fitur</h3>
              <span className={`text-xs px-2.5 py-0.5 rounded-full font-semibold border ${scoreBadgeColor}`}>
                {scoreText}
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
              {summary}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap md:flex-col gap-2 text-xs text-slate-400 self-stretch md:self-auto justify-end border-t md:border-t-0 md:border-l border-slate-800 pt-3 md:pt-0 md:pl-5">
          <div className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-teal-400" />
            <span>Maks Eksekusi: <strong className="text-slate-200">6 Menit / Trigger</strong></span>
          </div>
          <div className="flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Kuota Baca/Tulis: <strong className="text-slate-200">300 calls/menit</strong></span>
          </div>
        </div>
      </div>

      {/* Grid Status Pilar Fitur */}
      <div>
        <h4 className="text-xs uppercase font-bold text-slate-400 tracking-wider mb-3">
          Checklist 6 Pilar Keandalan Google Apps Script
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {metricCards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <div
                key={idx}
                className={`p-3.5 rounded-xl border transition flex flex-col justify-between ${
                  card.active
                    ? 'bg-slate-950/40 border-emerald-900/30 hover:border-emerald-700/50'
                    : 'bg-slate-950/80 border-rose-900/40 hover:border-rose-700/60'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div
                      className={`p-1.5 rounded-lg ${
                        card.active ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-semibold text-slate-200">{card.label}</span>
                  </div>

                  {card.active ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                  )}
                </div>

                <p
                  className={`text-[11px] mt-2.5 font-medium leading-normal ${
                    card.active ? 'text-slate-400' : 'text-rose-300'
                  }`}
                >
                  {card.active ? card.descIfOn : card.descIfOff}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
