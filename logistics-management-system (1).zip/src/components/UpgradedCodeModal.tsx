import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  Download,
  Settings2,
  ExternalLink,
  BookOpen,
  Sparkles,
} from 'lucide-react';
import { generateProductionGasCode } from '../utils/gasCodeGenerator';

interface UpgradedCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  originalCode: string;
  aiEnhancedCode?: string;
}

export const UpgradedCodeModal: React.FC<UpgradedCodeModalProps> = ({
  isOpen,
  onClose,
  originalCode,
  aiEnhancedCode,
}) => {
  const [activeTab, setActiveTab] = useState<'production' | 'ai' | 'steps'>('production');
  const [copied, setCopied] = useState(false);

  // Feature customization flags
  const [includeLockService, setIncludeLockService] = useState(true);
  const [includeNegativeStockGuard, setIncludeNegativeStockGuard] = useState(true);
  const [includeAuditTrail, setIncludeAuditTrail] = useState(true);
  const [includeCacheService, setIncludeCacheService] = useState(true);
  const [includeLowStockAlert, setIncludeLowStockAlert] = useState(true);

  if (!isOpen) return null;

  const generatedCode = generateProductionGasCode(originalCode, {
    includeLockService,
    includeNegativeStockGuard,
    includeAuditTrail,
    includeCacheService,
    includeLowStockAlert,
  });

  const codeToShow = activeTab === 'ai' && aiEnhancedCode ? aiEnhancedCode : generatedCode;

  const handleCopy = () => {
    navigator.clipboard.writeText(codeToShow);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([codeToShow], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Code.gs';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-5xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-teal-500/10 text-teal-400 border border-teal-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">
                Kode Google Apps Script Versi Upgrade (Production-Ready)
              </h3>
              <p className="text-xs text-slate-400">
                Dilengkapi dengan proteksi transaksi, batching O(1), audit trail, dan API handler aman.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub-nav Tabs & Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-5 py-3 border-b border-slate-800 bg-slate-900">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('production')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                activeTab === 'production'
                  ? 'bg-teal-500 text-slate-950 shadow'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
              }`}
            >
              📦 Kode Upgrade Standar Logistik
            </button>

            {aiEnhancedCode && (
              <button
                onClick={() => setActiveTab('ai')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                  activeTab === 'ai'
                    ? 'bg-emerald-500 text-slate-950 shadow'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
                }`}
              >
                ✨ Hasil Refactor Gemini AI
              </button>
            )}

            <button
              onClick={() => setActiveTab('steps')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                activeTab === 'steps'
                  ? 'bg-teal-500 text-slate-950 shadow'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
              }`}
            >
              📖 Panduan Pasang di Spreadsheet
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownload}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-teal-400" />
              <span>Download Code.gs</span>
            </button>

            <button
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-bold transition shadow-md shadow-teal-500/20 cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Tersalin ke Clipboard!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Salin Seluruh Kode</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Feature Switches Toolbar (when production tab) */}
        {activeTab === 'production' && (
          <div className="px-4 sm:px-5 py-2.5 bg-slate-950/70 border-b border-slate-800 flex flex-wrap items-center gap-3 text-xs">
            <span className="text-slate-400 font-semibold flex items-center gap-1">
              <Settings2 className="w-3.5 h-3.5 text-teal-400" />
              Sesuaikan Fitur Tambahan:
            </span>

            <label className="flex items-center gap-1.5 cursor-pointer text-slate-300 hover:text-white">
              <input
                type="checkbox"
                checked={includeLockService}
                onChange={(e) => setIncludeLockService(e.target.checked)}
                className="rounded accent-teal-500"
              />
              <span>LockService (Anti-Tabrakan)</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer text-slate-300 hover:text-white">
              <input
                type="checkbox"
                checked={includeNegativeStockGuard}
                onChange={(e) => setIncludeNegativeStockGuard(e.target.checked)}
                className="rounded accent-teal-500"
              />
              <span>Proteksi Stok Minus</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer text-slate-300 hover:text-white">
              <input
                type="checkbox"
                checked={includeAuditTrail}
                onChange={(e) => setIncludeAuditTrail(e.target.checked)}
                className="rounded accent-teal-500"
              />
              <span>Sheet Log Transaksi Otomatis</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer text-slate-300 hover:text-white">
              <input
                type="checkbox"
                checked={includeCacheService}
                onChange={(e) => setIncludeCacheService(e.target.checked)}
                className="rounded accent-teal-500"
              />
              <span>CacheService (Performa Cepat)</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer text-slate-300 hover:text-white">
              <input
                type="checkbox"
                checked={includeLowStockAlert}
                onChange={(e) => setIncludeLowStockAlert(e.target.checked)}
                className="rounded accent-teal-500"
              />
              <span>Email Alert Stok Kritis</span>
            </label>
          </div>
        )}

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {activeTab === 'steps' ? (
            <div className="space-y-4 max-w-3xl mx-auto py-2">
              <h4 className="text-sm font-bold text-teal-400 uppercase tracking-wider">
                Langkah Mudah Memasang di Google Spreadsheet:
              </h4>

              <div className="space-y-3 text-xs sm:text-sm text-slate-300">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-400 font-bold flex items-center justify-center flex-shrink-0">
                    1
                  </div>
                  <div>
                    <strong className="text-slate-100 block mb-0.5">Buka Google Sheets Anda</strong>
                    Buka Spreadsheet tempat Anda menyimpan data stok atau transaksi logistik.
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-400 font-bold flex items-center justify-center flex-shrink-0">
                    2
                  </div>
                  <div>
                    <strong className="text-slate-100 block mb-0.5">Buka Menu Apps Script</strong>
                    Klik menu <strong>Extensions (Ekstensi)</strong> &gt; <strong>Apps Script</strong> di bilah menu Google Sheets.
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-400 font-bold flex items-center justify-center flex-shrink-0">
                    3
                  </div>
                  <div>
                    <strong className="text-slate-100 block mb-0.5">Ganti Isi Code.gs</strong>
                    Hapus kode bawaan yang lama di file <code>Code.gs</code>, lalu paste kode yang telah disalin dari aplikasi ini. Klik tombol icon Disket (Save).
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-400 font-bold flex items-center justify-center flex-shrink-0">
                    4
                  </div>
                  <div>
                    <strong className="text-slate-100 block mb-0.5">Deploy sebagai Web App (Jika menggunakan API/Web)</strong>
                    Klik tombol biru <strong>Deploy (Terapkan)</strong> &gt; <strong>New deployment</strong> &gt; Pilih tipe <strong>Web app</strong>.
                    <br />
                    Atur <em>Execute as: Me</em> dan <em>Who has access: Anyone (Siapa saja)</em> jika ingin diakses dari frontend web/scanner.
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="relative">
              <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs sm:text-[13px] text-teal-300/90 leading-relaxed overflow-x-auto selection:bg-teal-500/30">
                <code>{codeToShow}</code>
              </pre>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 sm:p-4 border-t border-slate-800 bg-slate-950/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
