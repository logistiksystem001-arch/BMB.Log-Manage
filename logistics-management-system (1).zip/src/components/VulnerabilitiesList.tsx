import React from 'react';
import { SecurityVulnerability } from '../types';
import { ShieldAlert, AlertOctagon, Lightbulb } from 'lucide-react';

interface VulnerabilitiesListProps {
  vulnerabilities: SecurityVulnerability[];
  performanceAdvice: string[];
  logisticsAdvice: string[];
}

export const VulnerabilitiesList: React.FC<VulnerabilitiesListProps> = ({
  vulnerabilities,
  performanceAdvice,
  logisticsAdvice,
}) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      {/* Keamanan & Kerentanan */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3.5">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
          <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100">
              Audit Keamanan & Integritas Data ({vulnerabilities.length})
            </h3>
            <p className="text-xs text-slate-400">Pencegahan kebocoran kunci & crash transaksi</p>
          </div>
        </div>

        {vulnerabilities.length === 0 ? (
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-emerald-400 flex items-center gap-2">
            <span>✓ Tidak ditemukan celah keamanan kritis pada kode ini.</span>
          </div>
        ) : (
          <div className="space-y-2.5">
            {vulnerabilities.map((v) => (
              <div
                key={v.id}
                className="p-3 rounded-xl bg-slate-950/80 border border-amber-900/40 text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-amber-300 flex items-center gap-1.5">
                    <AlertOctagon className="w-3.5 h-3.5 text-amber-400" />
                    {v.title}
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-500/20 text-amber-300">
                    {v.severity}
                  </span>
                </div>
                <p className="text-slate-400">{v.description}</p>
                <div className="pt-1 border-t border-slate-800/80 text-[11px] text-teal-400">
                  <strong>Rekomendasi:</strong> {v.remedy}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Rekomendasi Khusus Logistik & Efisiensi Google Apps Script */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3.5">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
          <div className="p-1.5 rounded-lg bg-teal-500/10 text-teal-400">
            <Lightbulb className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100">
              Best Practice Khusus Sistem Logistik & Kuota
            </h3>
            <p className="text-xs text-slate-400">Tips arsitektur Google Spreadsheet tingkat lanjut</p>
          </div>
        </div>

        <div className="space-y-3">
          <div>
            <h4 className="text-[11px] uppercase font-bold text-teal-400 tracking-wider mb-1.5">
              🚚 Fitur Operasional Gudang
            </h4>
            <ul className="space-y-1 text-xs text-slate-300">
              {logisticsAdvice.map((adv, i) => (
                <li key={i} className="flex items-start gap-2 bg-slate-950/60 p-2 rounded-lg border border-slate-850">
                  <span className="text-teal-400 font-bold">•</span>
                  <span>{adv}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[11px] uppercase font-bold text-amber-400 tracking-wider mb-1.5">
              ⚡ Optimasi Kuota Google
            </h4>
            <ul className="space-y-1 text-xs text-slate-300">
              {performanceAdvice.map((adv, i) => (
                <li key={i} className="flex items-start gap-2 bg-slate-950/60 p-2 rounded-lg border border-slate-850">
                  <span className="text-amber-400 font-bold">•</span>
                  <span>{adv}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
