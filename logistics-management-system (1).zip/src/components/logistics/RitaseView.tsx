import React, { useState } from 'react';
import {
  Plus,
  Search,
  Printer,
  CreditCard,
  Edit2,
  Trash2,
  CheckCircle,
} from 'lucide-react';
import { RitaseItem, MasterOptions } from '../../types/logistics';

interface RitaseViewProps {
  ritaseList: RitaseItem[];
  masterOptions: MasterOptions;
  onSaveRitase: (data: Partial<RitaseItem>) => void;
  onDeleteRitase: (id: string) => void;
  onUpdateStatus: (id: string, field: 'fix' | 'buy', newStatus: any) => void;
  onPrintSpk: (item: RitaseItem) => void;
  onGeneratePayment70: (item: RitaseItem) => void;
}

export const RitaseView: React.FC<RitaseViewProps> = ({
  ritaseList,
  masterOptions,
  onSaveRitase,
  onDeleteRitase,
  onUpdateStatus,
  onPrintSpk,
  onGeneratePayment70,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVendor, setSelectedVendor] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<RitaseItem | null>(null);

  // Form State
  const [formData, setFormData] = useState<{
    date: string;
    skoType: string;
    truckType: string;
    vendor: string;
    driver: string;
    plat: string;
    origin: string;
    fixRate: number;
    buyRate: number;
    statusFix: 'DRAFT' | 'PENGAJUAN' | 'APPROVED';
    statusBuy: 'DRAFT' | 'PROSES' | 'APPROVE';
  }>({
    date: new Date().toISOString().split('T')[0],
    skoType: masterOptions.skoTypes[0] || 'SKO-REG (REGULER LOGISTIK)',
    truckType: masterOptions.truckTypes[0] || 'CDD (Double)',
    vendor: masterOptions.vendors[0] || 'PT FAST LOGISTIK NUSANTARA',
    driver: '',
    plat: '',
    origin: 'Jakarta - Surabaya',
    fixRate: 4800000,
    buyRate: 4100000,
    statusFix: 'DRAFT',
    statusBuy: 'DRAFT',
  });

  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormData({
      date: new Date().toISOString().split('T')[0],
      skoType: masterOptions.skoTypes[0] || 'SKO-REG (REGULER LOGISTIK)',
      truckType: masterOptions.truckTypes[0] || 'CDD (Double)',
      vendor: masterOptions.vendors[0] || 'PT FAST LOGISTIK NUSANTARA',
      driver: '',
      plat: '',
      origin: 'Jakarta - Surabaya',
      fixRate: 4800000,
      buyRate: 4100000,
      statusFix: 'DRAFT',
      statusBuy: 'DRAFT',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: RitaseItem) => {
    setEditingItem(item);
    setFormData({
      date: item.date,
      skoType: item.skoType,
      truckType: item.truckType,
      vendor: item.vendor,
      driver: item.driver,
      plat: item.plat,
      origin: item.origin,
      fixRate: item.fixRate,
      buyRate: item.buyRate,
      statusFix: item.statusFix || 'DRAFT',
      statusBuy: item.statusBuy || 'DRAFT',
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.driver || !formData.plat) {
      alert('Nama supir dan nomor plat armada wajib diisi!');
      return;
    }

    const margin = formData.fixRate - formData.buyRate;
    const fix70 = Math.round(formData.fixRate * 0.7);
    const fix30 = Math.round(formData.fixRate * 0.3);
    const buy70 = Math.round(formData.buyRate * 0.7);
    const buy30 = Math.round(formData.buyRate * 0.3);

    onSaveRitase({
      ...(editingItem ? { id: editingItem.id, rowIndex: editingItem.rowIndex } : {}),
      date: formData.date,
      skoType: formData.skoType,
      truckType: formData.truckType,
      vendor: formData.vendor,
      driver: formData.driver,
      plat: formData.plat,
      origin: formData.origin,
      fixRate: Number(formData.fixRate),
      buyRate: Number(formData.buyRate),
      margin,
      fix70,
      fix30,
      buy70,
      buy30,
      fix100: Number(formData.fixRate),
      buy100: Number(formData.buyRate),
      statusFix: formData.statusFix,
      statusBuy: formData.statusBuy,
    });

    setIsModalOpen(false);
  };

  const filtered = ritaseList.filter((item) => {
    const matchesSearch =
      item.driver.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.plat.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.origin.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesVendor = selectedVendor ? item.vendor === selectedVendor : true;
    return matchesSearch && matchesVendor;
  });

  const formatRupiah = (val: number) => {
    return 'Rp ' + Number(val || 0).toLocaleString('id-ID');
  };

  return (
    <div className="space-y-5">
      {/* Action Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex flex-1 items-center gap-2">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari supir, plat nomor, rute, atau ID Ritase..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
            />
          </div>

          {/* Vendor Filter */}
          <select
            value={selectedVendor}
            onChange={(e) => setSelectedVendor(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-300 text-slate-700 rounded-xl px-3 py-2 focus:outline-none focus:border-blue-600 hidden sm:block"
          >
            <option value="">Semua Vendor</option>
            {masterOptions.vendors.map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold shadow-xs transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Input Ritase Baru</span>
        </button>
      </div>

      {/* Main Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900">4. MASTER DATA RITASE</h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-mono font-bold">
              {filtered.length} Transaksi
            </span>
          </div>
          <span className="text-xs text-slate-500 hidden sm:block">
            Status Pembayaran Terkoneksi Otomatis dengan Modul Payment & Kas
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/70 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
              <tr>
                <th className="p-3">ID / TGL</th>
                <th className="p-3">ARMADA & VENDOR</th>
                <th className="p-3">DRIVER & PLAT</th>
                <th className="p-3">RUTE / ORIGIN</th>
                <th className="p-3 text-right">TAGIHAN KLIEN (FIX)</th>
                <th className="p-3 text-right">BIAYA VENDOR (BUY)</th>
                <th className="p-3 text-right text-emerald-700">MARGIN PROFIT</th>
                <th className="p-3 text-center">STATUS KLIEN</th>
                <th className="p-3 text-center">STATUS VENDOR</th>
                <th className="p-3 text-center">AKSI</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={10} className="p-8 text-center text-slate-400 text-xs">
                    Tidak ada data ritase yang cocok dengan pencarian.
                  </td>
                </tr>
              ) : (
                filtered.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50 transition">
                    <td className="p-3">
                      <div className="font-mono font-bold text-blue-700">{r.id}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{r.date}</div>
                    </td>
                    <td className="p-3">
                      <div className="font-semibold text-slate-900">{r.truckType}</div>
                      <div className="text-[10px] text-slate-500 truncate max-w-[150px]">
                        {r.vendor}
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="font-bold text-slate-900">{r.driver}</div>
                      <div className="text-[10px] font-mono text-slate-600 font-semibold">{r.plat}</div>
                    </td>
                    <td className="p-3 text-slate-700 max-w-[140px] truncate">{r.origin}</td>
                    <td className="p-3 text-right font-mono font-semibold text-blue-700">
                      {formatRupiah(r.fixRate)}
                      {r.refNoFix && (
                        <div className="text-[9px] text-emerald-700 font-normal">Ref: {r.refNoFix}</div>
                      )}
                    </td>
                    <td className="p-3 text-right font-mono text-slate-800">
                      {formatRupiah(r.buyRate)}
                      {r.refNoBuy && (
                        <div className="text-[9px] text-blue-700 font-normal">Ref: {r.refNoBuy}</div>
                      )}
                    </td>
                    <td className="p-3 text-right font-mono font-bold text-emerald-700">
                      +{formatRupiah(r.margin)}
                    </td>
                    <td className="p-3 text-center">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase border ${
                          r.statusFix === 'APPROVED'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                            : r.statusFix === 'PENGAJUAN'
                            ? 'bg-amber-50 text-amber-700 border-amber-300'
                            : 'bg-slate-100 text-slate-700 border-slate-300'
                        }`}
                      >
                        {r.statusFix}
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase border ${
                          r.statusBuy === 'APPROVE'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                            : r.statusBuy === 'PROSES'
                            ? 'bg-blue-50 text-blue-700 border-blue-300'
                            : 'bg-slate-100 text-slate-700 border-slate-300'
                        }`}
                      >
                        {r.statusBuy}
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => onPrintSpk(r)}
                          title="Cetak SPK / Surat Jalan PDF"
                          className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => onGeneratePayment70(r)}
                          title="Generate Pengajuan Payment 70% Uang Jalan"
                          className="p-1.5 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded-lg transition"
                        >
                          <CreditCard className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => handleOpenEdit(r)}
                          title="Edit Ritase"
                          className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => {
                            if (confirm(`Hapus data ritase ${r.driver} (${r.plat})?`)) {
                              onDeleteRitase(r.id);
                            }
                          }}
                          title="Hapus Ritase"
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit Ritase */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl text-slate-800">
            <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-base font-bold text-slate-900">
                {editingItem ? 'Edit Data Ritase' : 'Input Data Ritase Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-sm font-semibold"
              >
                Tutup
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tanggal</label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tipe SKO</label>
                  <select
                    value={formData.skoType}
                    onChange={(e) => setFormData({ ...formData, skoType: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  >
                    {masterOptions.skoTypes.map((sko) => (
                      <option key={sko} value={sko}>
                        {sko}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tipe Truk Armada</label>
                  <select
                    value={formData.truckType}
                    onChange={(e) => setFormData({ ...formData, truckType: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  >
                    {masterOptions.truckTypes.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Vendor Transportasi</label>
                  <select
                    value={formData.vendor}
                    onChange={(e) => setFormData({ ...formData, vendor: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  >
                    {masterOptions.vendors.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nama Driver</label>
                  <input
                    type="text"
                    value={formData.driver}
                    onChange={(e) => setFormData({ ...formData, driver: e.target.value })}
                    placeholder="Contoh: Budi Santoso"
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nomor Plat Polisi</label>
                  <input
                    type="text"
                    value={formData.plat}
                    onChange={(e) => setFormData({ ...formData, plat: e.target.value })}
                    placeholder="Contoh: B 9283 JKL"
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1">Rute Pengiriman / Origin</label>
                  <input
                    type="text"
                    value={formData.origin}
                    onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                    placeholder="Contoh: Jakarta - Surabaya"
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Tagihan Klien (Fix Rate Rp)
                  </label>
                  <input
                    type="number"
                    value={formData.fixRate}
                    onChange={(e) => setFormData({ ...formData, fixRate: Number(e.target.value) })}
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Biaya Vendor (Buy Rate Rp)
                  </label>
                  <input
                    type="number"
                    value={formData.buyRate}
                    onChange={(e) => setFormData({ ...formData, buyRate: Number(e.target.value) })}
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600 font-mono"
                  />
                </div>
              </div>

              {/* Real-time Calculation Preview */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-3 gap-2 text-center text-xs">
                <div>
                  <span className="text-slate-500 block text-[11px]">Gross Margin:</span>
                  <span className="font-bold text-emerald-700 font-mono">
                    {formatRupiah(formData.fixRate - formData.buyRate)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">70% Uang Jalan Vendor:</span>
                  <span className="font-bold text-blue-700 font-mono">
                    {formatRupiah(Math.round(formData.buyRate * 0.7))}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">30% Pelunasan Vendor:</span>
                  <span className="font-bold text-slate-800 font-mono">
                    {formatRupiah(Math.round(formData.buyRate * 0.3))}
                  </span>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs cursor-pointer"
                >
                  Simpan Transaksi Ritase
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
