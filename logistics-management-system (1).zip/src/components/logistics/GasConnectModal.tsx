import React, { useState } from 'react';
import { X, Link2, CheckCircle2, AlertCircle, HelpCircle, ExternalLink, Copy, Check } from 'lucide-react';

interface GasConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
  gasUrl: string;
  onSaveGasUrl: (url: string) => void;
}

export const GasConnectModal: React.FC<GasConnectModalProps> = ({
  isOpen,
  onClose,
  gasUrl,
  onSaveGasUrl,
}) => {
  const [urlInput, setUrlInput] = useState(gasUrl);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  if (!isOpen) return null;

  const handleTestConnection = async () => {
    if (!urlInput.trim()) {
      setTestResult({ success: false, message: 'Masukkan URL Web App terlebih dahulu.' });
      return;
    }

    setTesting(true);
    setTestResult(null);

    try {
      const target = `${urlInput.trim()}?action=getMasterOptions`;
      await fetch(target, { mode: 'no-cors' });
      setTestResult({
        success: true,
        message: 'Endpoint Web App Google Apps Script merespons dengan baik! Anda siap melakukan sinkronisasi.',
      });
      onSaveGasUrl(urlInput.trim());
    } catch (err: any) {
      setTestResult({
        success: false,
        message: 'Gagal terhubung: Pastikan Web App di-deploy dengan opsi Who has access: "Anyone (Siapa saja)".',
      });
    } finally {
      setTesting(false);
    }
  };

  const handleSave = () => {
    onSaveGasUrl(urlInput.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden text-slate-800 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-100 text-blue-700">
              <Link2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Koneksi Google Apps Script & Panduan Deploy
              </h3>
              <p className="text-xs text-slate-500">
                Hubungkan Web App langsung ke Google Spreadsheet Anda
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs sm:text-sm overflow-y-auto">
          <div>
            <label className="block text-slate-700 font-bold mb-1 text-xs">
              URL Web App Deployment (berakhiran /exec):
            </label>
            <input
              type="url"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="https://script.google.com/macros/s/AKfycb.../exec"
              className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-mono focus:outline-none focus:border-blue-600 focus:bg-white"
            />
          </div>

          {testResult && (
            <div
              className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
                testResult.success
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-rose-50 border-rose-300 text-rose-800'
              }`}
            >
              {testResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
              )}
              <span>{testResult.message}</span>
            </div>
          )}

          {/* Tutorial Step-by-Step */}
          <div className="p-4 rounded-xl bg-blue-50/60 border border-blue-200 text-xs text-slate-700 space-y-2">
            <div className="font-bold text-blue-900 flex items-center gap-1.5 text-xs">
              <HelpCircle className="w-4 h-4 text-blue-600" />
              <span>Langkah-Langkah Memasukkan Kode ke Apps Script & Deploy:</span>
            </div>
            <ol className="list-decimal list-inside space-y-1.5 text-slate-600 pl-1 leading-relaxed">
              <li>
                Buka Google Spreadsheet baru atau yang sudah ada di <strong>Google Drive</strong>.
              </li>
              <li>
                Klik menu <strong>Extensions (Ekstensi)</strong> &gt; <strong>Apps Script</strong>.
              </li>
              <li>
                Buka tombol <strong>Backend Code.gs</strong> di navigasi atas web ini, klik <strong>Salin Seluruh Kode</strong>, lalu paste ke dalam file <code>Code.gs</code> di editor Google Apps Script. Klik icon Disket (Save).
              </li>
              <li>
                Jalankan fungsi <code>setupDatabase</code> sekali dari editor Apps Script (pilih fungsi <code>setupDatabase</code> di toolbar atas lalu klik <strong>Run</strong>), dan izinkan otorisasi akses (*Review Permissions* &gt; *Allow*). Semua sheet akan otomatis dibuat!
              </li>
              <li>
                Untuk men-deploy: Klik tombol biru <strong>Deploy (Terapkan)</strong> di pojok kanan atas &gt; pilih <strong>New deployment (Penerapan baru)</strong>.
              </li>
              <li>
                Klik ikon Roda Gigi di kiri atas jendela pop-up, pilih <strong>Web app</strong>.
              </li>
              <li>
                Atur konfigurasi wajib:
                <ul className="list-disc list-inside pl-4 text-slate-700 font-semibold space-y-0.5 my-1">
                  <li>Execute as: <strong>Me (email Anda)</strong></li>
                  <li>Who has access: <strong>Anyone (Siapa saja)</strong></li>
                </ul>
              </li>
              <li>
                Klik <strong>Deploy</strong>, salin <strong>Web app URL</strong> yang berakhiran <code>/exec</code>, lalu tempelkan ke kolom input di atas!
              </li>
            </ol>
          </div>

          <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
            <button
              onClick={handleTestConnection}
              disabled={testing || !urlInput.trim()}
              className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-300 transition cursor-pointer disabled:opacity-40"
            >
              {testing ? 'Menguji...' : 'Uji Koneksi'}
            </button>

            <div className="flex gap-2">
              <button
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleSave}
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition shadow-xs cursor-pointer"
              >
                Simpan URL
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
