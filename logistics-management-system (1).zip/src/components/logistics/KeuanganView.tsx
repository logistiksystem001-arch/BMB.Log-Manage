import React, { useState } from 'react';
import {
  Plus,
  Search,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
  CheckCircle,
  Trash2,
  Edit2,
  FileText,
} from 'lucide-react';
import { KeuanganItem, MasterOptions } from '../../types/logistics';

interface KeuanganViewProps {
  keuanganList: KeuanganItem[];
  masterOptions: MasterOptions;
  onSaveKeuangan: (data: Partial<KeuanganItem>) => void;
  onDeleteKeuangan: (id: string) => void;
}

export const KeuanganView: React.FC<KeuanganViewProps> = ({
  keuanganList,
  masterOptions,
  onSaveKeuangan,
  onDeleteKeuangan,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [tipeFilter, setTipeFilter] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<KeuanganItem | null>(null);

  const [formData, setFormData] = useState<{
    tanggal: string;
    tipe: 'PEMASUKAN' | 'PENGELUARAN';
    jenis: string;
    keterangan: string;
    jumlah: number;
    status: 'LUNAS' | 'HUTANG' | 'PIUTANG';
    refNo: string;
  }>({
    tanggal: new Date().toISOString().split('T')[0],
    tipe: 'PEMASUKAN',
    jenis: 'Pelunasan Tagihan Klien (Fix Rate)',
    keterangan: '',
    jumlah: 1000000,
    status: 'LUNAS',
    refNo: '',
  });

  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormData({
      tanggal: new Date().toISOString().split('T')[0],
      tipe: 'PEMASUKAN',
      jenis: 'Pelunasan Tagihan Klien (Fix Rate)',
      keterangan: '',
      jumlah: 1000000,
      status: 'LUNAS',
      refNo: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: KeuanganItem) => {
    setEditingItem(item);
    setFormData({
      tanggal: item.tanggal,
      tipe: item.tipe,
      jenis: item.jenis,
      keterangan: item.keterangan,
      jumlah: item.jumlah,
      status: item.status,
      refNo: item.refNo || '',
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.keterangan) {
      alert('Keterangan transaksi kas wajib diisi!');
      return;
    }

    onSaveKeuangan({
      ...(editingItem ? { id: editingItem.id, rowIndex: editingItem.rowIndex } : {}),
      ...formData,
      jumlah: Number(formData.jumlah),
    });
    setIsModalOpen(false);
  };

  const filtered = keuanganList.filter((item) => {
    const matchesSearch =
      item.jenis.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.keterangan.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.refNo && item.refNo.toLowerCase().includes(searchTerm.toLowerCase())) ||
      item.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTipe = tipeFilter ? item.tipe === tipeFilter : true;
    return matchesSearch && matchesTipe;
  });

  const formatRupiah = (val: number) => {
    return 'Rp ' + Number(val || 0).toLocaleString('id-ID');
  };

  const totalPemasukan = keuanganList
    .filter((k) => k.tipe === 'PEMASUKAN')
    .reduce((acc, curr) => acc + (curr.jumlah || 0), 0);

  const totalPengeluaran = keuanganList
    .filter((k) => k.tipe === 'PENGELUARAN')
    .reduce((acc, curr) => acc + (curr.jumlah || 0), 0);

  const saldoKasAkhir = keuanganList.length > 0 ? keuanganList[keuanganList.length - 1].total : 0;

  return (
    <div className="space-y-5">
      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Total Pemasukan Kas (Fix Rate Klien)</span>
            <div className="p-2 rounded-xl bg-emerald-100 text-emerald-700">
              <ArrowDownRight className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-emerald-600 mt-2 font-mono">
            {formatRupiah(totalPemasukan)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Pembayaran Tagihan Masuk</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Total Pengeluaran Kas (Vendor/Uang Jalan)</span>
            <div className="p-2 rounded-xl bg-rose-100 text-rose-700">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-rose-600 mt-2 font-mono">
            {formatRupiah(totalPengeluaran)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Biaya Vendor & Uang Jalan Supir</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Saldo Kas Berjalan (Likuiditas)</span>
            <div className="p-2 rounded-xl bg-blue-100 text-blue-700">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-blue-700 mt-2 font-mono">
            {formatRupiah(saldoKasAkhir)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Otomatis dihitung ulang</div>
        </div>
      </div>

      {/* Action Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex flex-1 items-center gap-2">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari jenis transaksi, rincian asal, atau nomor referensi..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
            />
          </div>

          <select
            value={tipeFilter}
            onChange={(e) => setTipeFilter(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-300 text-slate-700 rounded-xl px-3 py-2 focus:outline-none focus:border-blue-600"
          >
            <option value="">Semua Arus Kas</option>
            <option value="PEMASUKAN">PEMASUKAN (Masuk)</option>
            <option value="PENGELUARAN">PENGELUARAN (Keluar)</option>
          </select>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold shadow-xs transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Catat Transaksi Manual</span>
        </button>
      </div>

      {/* Main Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900">3. BUKU KAS KEUANGAN OPERASIONAL</h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-mono font-bold">
              {filtered.length} Transaksi
            </span>
          </div>
          <span className="text-xs text-slate-500 hidden sm:block">
            Arus Kas Masuk & Keluar yang Dihasilkan Otomatis dari Approval Payment
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/70 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
              <tr>
                <th className="p-3">ID / TANGGAL</th>
                <th className="p-3 text-center">ARUS KAS</th>
                <th className="p-3">ASAL TRANSAKSI & RINCIAN KETERANGAN</th>
                <th className="p-3">NO. REF TRANSFER</th>
                <th className="p-3 text-right">MUTASI JUMLAH</th>
                <th className="p-3 text-right">SALDO BERJALAN</th>
                <th className="p-3 text-center">STATUS</th>
                <th className="p-3 text-center">AKSI</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400 text-xs">
                    Tidak ada transaksi keuangan yang tercatat.
                  </td>
                </tr>
              ) : (
                filtered.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50 transition">
                    <td className="p-3">
                      <div className="font-mono font-bold text-blue-700">{item.id}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{item.tanggal}</div>
                    </td>
                    <td className="p-3 text-center">
                      <span
                        className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase border ${
                          item.tipe === 'PEMASUKAN'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                            : 'bg-rose-50 text-rose-700 border-rose-300'
                        }`}
                      >
                        {item.tipe}
                      </span>
                    </td>
                    <td className="p-3">
                      <div className="font-semibold text-slate-900">{item.jenis}</div>
                      <div className="text-[11px] text-slate-600 font-medium">{item.keterangan}</div>
                    </td>
                    <td className="p-3">
                      {item.refNo ? (
                        <span className="font-mono font-bold text-blue-800 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 text-[10px]">
                          {item.refNo}
                        </span>
                      ) : (
                        <span className="text-slate-400 italic text-[11px]">-</span>
                      )}
                    </td>
                    <td
                      className={`p-3 text-right font-mono font-bold ${
                        item.tipe === 'PEMASUKAN' ? 'text-emerald-700' : 'text-rose-700'
                      }`}
                    >
                      {item.tipe === 'PEMASUKAN' ? '+' : '-'}
                      {formatRupiah(item.jumlah)}
                    </td>
                    <td className="p-3 text-right font-mono font-semibold text-slate-900">
                      {formatRupiah(item.total)}
                    </td>
                    <td className="p-3 text-center">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase bg-slate-100 text-slate-700 border border-slate-300">
                        {item.status}
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => handleOpenEdit(item)}
                          className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition"
                          title="Edit Transaksi Kas"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Hapus transaksi ${item.keterangan}? Saldo akan dihitung ulang otomatis.`)) {
                              onDeleteKeuangan(item.id);
                            }
                          }}
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition"
                          title="Hapus Transaksi"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit Keuangan */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl text-slate-800">
            <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-base font-bold text-slate-900">
                {editingItem ? 'Edit Transaksi Kas' : 'Catat Transaksi Buku Kas Manual'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-sm font-semibold"
              >
                Tutup
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tanggal</label>
                  <input
                    type="date"
                    value={formData.tanggal}
                    onChange={(e) => setFormData({ ...formData, tanggal: e.target.value })}
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tipe Arus Kas</label>
                  <select
                    value={formData.tipe}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        tipe: e.target.value as 'PEMASUKAN' | 'PENGELUARAN',
                      })
                    }
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  >
                    <option value="PEMASUKAN">PEMASUKAN (Kas Masuk)</option>
                    <option value="PENGELUARAN">PENGELUARAN (Kas Keluar)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Jenis Transaksi</label>
                  <input
                    type="text"
                    value={formData.jenis}
                    onChange={(e) => setFormData({ ...formData, jenis: e.target.value })}
                    placeholder="Contoh: Pelunasan Tagihan Klien"
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nomor Referensi Transfer</label>
                  <input
                    type="text"
                    value={formData.refNo}
                    onChange={(e) => setFormData({ ...formData, refNo: e.target.value })}
                    placeholder="Contoh: TRF-BCA-9812"
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1">
                    Rincian Keterangan & Asal Dana
                  </label>
                  <input
                    type="text"
                    value={formData.keterangan}
                    onChange={(e) => setFormData({ ...formData, keterangan: e.target.value })}
                    placeholder="Contoh: Pembayaran invoice ritase PT Unilever (Driver Budi - B 9283 JKL)"
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1">
                    Jumlah Nominal (Rp)
                  </label>
                  <input
                    type="number"
                    value={formData.jumlah}
                    onChange={(e) => setFormData({ ...formData, jumlah: Number(e.target.value) })}
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs cursor-pointer"
                >
                  Simpan Transaksi Kas
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
