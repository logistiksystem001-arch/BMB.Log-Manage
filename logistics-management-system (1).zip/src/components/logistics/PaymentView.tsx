import React, { useState } from 'react';
import {
  Plus,
  Search,
  Printer,
  CheckCircle,
  Clock,
  Trash2,
  Edit2,
  FileCheck,
  CheckSquare,
  Square,
  ShieldCheck,
  Download,
} from 'lucide-react';
import { PaymentItem, MasterOptions } from '../../types/logistics';

interface PaymentViewProps {
  paymentList: PaymentItem[];
  masterOptions: MasterOptions;
  onSavePayment: (data: Partial<PaymentItem>) => void;
  onDeletePayment: (id: string) => void;
  onTriggerApproveFixRate: (item: PaymentItem) => void;
  onTriggerApproveBuyRate: (item: PaymentItem) => void;
  onUpdateStatusManual: (id: string, type: 'fix' | 'buy', status: string) => void;
  onPrintVoucher: (item: PaymentItem) => void;
  onOpenRekapPdf: (selected: PaymentItem[]) => void;
}

export const PaymentView: React.FC<PaymentViewProps> = ({
  paymentList,
  masterOptions,
  onSavePayment,
  onDeletePayment,
  onTriggerApproveFixRate,
  onTriggerApproveBuyRate,
  onUpdateStatusManual,
  onPrintVoucher,
  onOpenRekapPdf,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<PaymentItem | null>(null);

  const [formData, setFormData] = useState<{
    date: string;
    project: string;
    paymentType: '30%' | '70%' | '100%';
    rute: string;
    driver: string;
    noPlat: string;
    fixRate: number;
    buyRate: number;
    statusFixRate: 'DRAFT' | 'PENGAJUAN' | 'APPROVED';
    statusBuyRate: 'DRAFT' | 'PROSES' | 'APPROVE';
    notes: string;
  }>({
    date: new Date().toISOString().split('T')[0],
    project: masterOptions.projects[0] || 'PROJECT FMCG JAKARTA',
    paymentType: '70%',
    rute: 'Jakarta - Surabaya',
    driver: '',
    noPlat: '',
    fixRate: 4800000,
    buyRate: 4100000,
    statusFixRate: 'DRAFT',
    statusBuyRate: 'DRAFT',
    notes: '',
  });

  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormData({
      date: new Date().toISOString().split('T')[0],
      project: masterOptions.projects[0] || 'PROJECT FMCG JAKARTA',
      paymentType: '70%',
      rute: 'Jakarta - Surabaya',
      driver: '',
      noPlat: '',
      fixRate: 4800000,
      buyRate: 4100000,
      statusFixRate: 'DRAFT',
      statusBuyRate: 'DRAFT',
      notes: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: PaymentItem) => {
    setEditingItem(item);
    setFormData({
      date: item.date,
      project: item.project,
      paymentType: item.paymentType || '70%',
      rute: item.rute,
      driver: item.driver,
      noPlat: item.noPlat,
      fixRate: item.fixRate || 4800000,
      buyRate: item.buyRate || 4100000,
      statusFixRate: item.statusFixRate || 'DRAFT',
      statusBuyRate: item.statusBuyRate || 'DRAFT',
      notes: item.notes || '',
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.driver || !formData.noPlat) {
      alert('Nama driver dan nomor plat wajib diisi!');
      return;
    }

    onSavePayment({
      ...(editingItem ? { id: editingItem.id, rowIndex: editingItem.rowIndex } : {}),
      ...formData,
      fixRate: Number(formData.fixRate),
      buyRate: Number(formData.buyRate),
      margin: Number(formData.fixRate) - Number(formData.buyRate),
    });
    setIsModalOpen(false);
  };

  // Toggle single item selection
  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Toggle all items selection
  const handleToggleSelectAll = () => {
    if (selectedIds.length === filtered.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filtered.map((item) => item.id));
    }
  };

  const filtered = paymentList.filter((item) => {
    const matchesSearch =
      item.driver.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.noPlat.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.project.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.id.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const formatRupiah = (val: number) => {
    return 'Rp ' + Number(val || 0).toLocaleString('id-ID');
  };

  const selectedItemsData = paymentList.filter((p) => selectedIds.includes(p.id));

  return (
    <div className="space-y-5">
      {/* Top Filter & Bulk PDF Action Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex flex-1 items-center gap-2">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari driver, no plat, proyek, atau nomor referensi..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
            />
          </div>

          {/* Rekap PDF Button (when items are selected) */}
          {selectedIds.length > 0 && (
            <button
              onClick={() => onOpenRekapPdf(selectedItemsData)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition cursor-pointer whitespace-nowrap animate-in fade-in"
            >
              <Download className="w-4 h-4" />
              <span>Download PDF Rekap ({selectedIds.length} Dipilih)</span>
            </button>
          )}
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold shadow-xs transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Input Pengajuan Payment Baru</span>
        </button>
      </div>

      {/* Main Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 bg-slate-50">
          <div className="flex items-center gap-2.5">
            <button
              onClick={handleToggleSelectAll}
              className="text-slate-600 hover:text-blue-600 flex items-center gap-1.5 text-xs font-semibold"
            >
              {selectedIds.length > 0 && selectedIds.length === filtered.length ? (
                <CheckSquare className="w-4 h-4 text-blue-600" />
              ) : (
                <Square className="w-4 h-4 text-slate-400" />
              )}
              <span>Tandai Semua</span>
            </button>
            <h3 className="text-sm font-bold text-slate-900 pl-2 border-l border-slate-300">
              2. PENGAJUAN PAYMENT (TERIMA KLIEN & BAYAR VENDOR)
            </h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-mono font-bold">
              {filtered.length} Transaksi
            </span>
          </div>

          <div className="text-xs text-slate-500">
            Tandai baris untuk cetak rekap PDF · Approve otomatis masuk ke Buku Kas
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/70 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
              <tr>
                <th className="p-3 w-8 text-center">PILIH</th>
                <th className="p-3">ID / TGL</th>
                <th className="p-3">DRIVER & PLAT</th>
                <th className="p-3">RUTE / PROYEK</th>
                <th className="p-3 text-right">TAGIHAN KLIEN (FIX)</th>
                <th className="p-3 text-center">STATUS TERIMA (KLIEN)</th>
                <th className="p-3 text-right">BAYAR VENDOR (BUY)</th>
                <th className="p-3 text-center">STATUS BAYAR (VENDOR)</th>
                <th className="p-3 text-center">AKSI CEPAT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-400 text-xs">
                    Tidak ada data pengajuan payment yang ditemukan.
                  </td>
                </tr>
              ) : (
                filtered.map((item) => {
                  const isChecked = selectedIds.includes(item.id);
                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-slate-50 transition ${
                        isChecked ? 'bg-blue-50/50' : ''
                      }`}
                    >
                      {/* Checkbox Tandai */}
                      <td className="p-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleToggleSelect(item.id)}
                          className="cursor-pointer text-slate-400 hover:text-blue-600"
                        >
                          {isChecked ? (
                            <CheckSquare className="w-4 h-4 text-blue-600" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      </td>

                      <td className="p-3">
                        <div className="font-mono font-bold text-blue-700">{item.id}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{item.date}</div>
                      </td>

                      <td className="p-3">
                        <div className="font-bold text-slate-900">{item.driver}</div>
                        <div className="text-[10px] font-mono text-slate-600 font-semibold">{item.noPlat}</div>
                      </td>

                      <td className="p-3">
                        <div className="text-slate-800">{item.rute}</div>
                        <div className="text-[10px] text-slate-500">{item.project}</div>
                      </td>

                      {/* Tagihan Klien (Fix Rate) */}
                      <td className="p-3 text-right font-mono font-bold text-blue-700">
                        {formatRupiah(item.fixRate)}
                        {item.refNoFixRate && (
                          <div className="text-[9px] text-emerald-700 font-normal">
                            Ref: {item.refNoFixRate}
                          </div>
                        )}
                      </td>

                      {/* Status Klien (DRAFT, PENGAJUAN, APPROVED) */}
                      <td className="p-3 text-center">
                        {item.statusFixRate === 'APPROVED' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-300">
                            <CheckCircle className="w-3 h-3 text-emerald-600" />
                            <span>APPROVED</span>
                          </span>
                        ) : (
                          <div className="flex items-center justify-center gap-1">
                            <select
                              value={item.statusFixRate || 'DRAFT'}
                              onChange={(e) => {
                                const val = e.target.value;
                                if (val === 'APPROVED') {
                                  onTriggerApproveFixRate(item);
                                } else {
                                  onUpdateStatusManual(item.id, 'fix', val);
                                }
                              }}
                              className={`text-[10px] font-bold rounded-lg px-2 py-1 border focus:outline-none cursor-pointer uppercase ${
                                item.statusFixRate === 'PENGAJUAN'
                                  ? 'bg-amber-50 text-amber-700 border-amber-300'
                                  : 'bg-slate-100 text-slate-700 border-slate-300'
                              }`}
                            >
                              <option value="DRAFT">DRAFT</option>
                              <option value="PENGAJUAN">PENGAJUAN</option>
                              <option value="APPROVED">APPROVE (+ Kas Masuk)</option>
                            </select>
                          </div>
                        )}
                      </td>

                      {/* Biaya Vendor (Buy Rate) */}
                      <td className="p-3 text-right font-mono font-bold text-slate-900">
                        {formatRupiah(item.buyRate)}
                        {item.refNoBuyRate && (
                          <div className="text-[9px] text-blue-700 font-normal">
                            Ref: {item.refNoBuyRate}
                          </div>
                        )}
                      </td>

                      {/* Status Vendor (DRAFT, PROSES, APPROVE) */}
                      <td className="p-3 text-center">
                        {item.statusBuyRate === 'APPROVE' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-300">
                            <CheckCircle className="w-3 h-3 text-emerald-600" />
                            <span>APPROVE</span>
                          </span>
                        ) : (
                          <div className="flex items-center justify-center gap-1">
                            <select
                              value={item.statusBuyRate || 'DRAFT'}
                              onChange={(e) => {
                                const val = e.target.value;
                                if (val === 'APPROVE') {
                                  onTriggerApproveBuyRate(item);
                                } else {
                                  onUpdateStatusManual(item.id, 'buy', val);
                                }
                              }}
                              className={`text-[10px] font-bold rounded-lg px-2 py-1 border focus:outline-none cursor-pointer uppercase ${
                                item.statusBuyRate === 'PROSES'
                                  ? 'bg-blue-50 text-blue-700 border-blue-300'
                                  : 'bg-slate-100 text-slate-700 border-slate-300'
                              }`}
                            >
                              <option value="DRAFT">DRAFT</option>
                              <option value="PROSES">PROSES</option>
                              <option value="APPROVE">APPROVE (+ Kas Keluar)</option>
                            </select>
                          </div>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="p-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {/* Cetak Voucher */}
                          <button
                            onClick={() => onPrintVoucher(item)}
                            className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition"
                            title="Cetak Voucher Kasbon Uang Jalan"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>

                          {/* Edit */}
                          <button
                            onClick={() => handleOpenEdit(item)}
                            className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition"
                            title="Edit Data Payment"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete */}
                          <button
                            onClick={() => {
                              if (confirm(`Hapus pengajuan payment ${item.driver} (${formatRupiah(item.fixRate)})?`)) {
                                onDeletePayment(item.id);
                              }
                            }}
                            className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition"
                            title="Hapus Data"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit Payment */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl text-slate-800">
            <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-base font-bold text-slate-900">
                {editingItem ? 'Edit Data Pengajuan Payment' : 'Input Pengajuan Payment Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-sm font-semibold"
              >
                Tutup
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tanggal</label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Termin Pembayaran</label>
                  <select
                    value={formData.paymentType}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        paymentType: e.target.value as '30%' | '70%' | '100%',
                      })
                    }
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  >
                    <option value="70%">70% (Uang Jalan Supir)</option>
                    <option value="30%">30% (Pelunasan Vendor)</option>
                    <option value="100%">100% (Full Payment)</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1">Nama Proyek / Klien</label>
                  <input
                    type="text"
                    value={formData.project}
                    onChange={(e) => setFormData({ ...formData, project: e.target.value })}
                    placeholder="Contoh: PROJECT FMCG JAKARTA"
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nama Driver</label>
                  <input
                    type="text"
                    value={formData.driver}
                    onChange={(e) => setFormData({ ...formData, driver: e.target.value })}
                    placeholder="Contoh: Budi Santoso"
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nomor Plat Armada</label>
                  <input
                    type="text"
                    value={formData.noPlat}
                    onChange={(e) => setFormData({ ...formData, noPlat: e.target.value })}
                    placeholder="Contoh: B 9283 JKL"
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1">Rute</label>
                  <input
                    type="text"
                    value={formData.rute}
                    onChange={(e) => setFormData({ ...formData, rute: e.target.value })}
                    placeholder="Contoh: Jakarta - Surabaya"
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Tagihan Klien (Fix Rate Rp)
                  </label>
                  <input
                    type="number"
                    value={formData.fixRate}
                    onChange={(e) => setFormData({ ...formData, fixRate: Number(e.target.value) })}
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Biaya Vendor (Buy Rate Rp)
                  </label>
                  <input
                    type="number"
                    value={formData.buyRate}
                    onChange={(e) => setFormData({ ...formData, buyRate: Number(e.target.value) })}
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs cursor-pointer"
                >
                  Simpan Pengajuan Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
