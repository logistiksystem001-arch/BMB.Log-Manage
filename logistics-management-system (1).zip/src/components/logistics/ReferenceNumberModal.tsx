import React, { useState } from 'react';
import { X, CheckCircle, ShieldCheck, AlertCircle, FileText } from 'lucide-react';

interface ReferenceNumberModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle: string;
  partyName: string;
  amount: number;
  rateType: 'FIX_RATE' | 'BUY_RATE';
  onConfirm: (refNo: string, notes: string) => void;
}

export const ReferenceNumberModal: React.FC<ReferenceNumberModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  partyName,
  amount,
  rateType,
  onConfirm,
}) => {
  const [refNo, setRefNo] = useState('');
  const [notes, setNotes] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!refNo.trim()) {
      setErrorMsg('Wajib menginput Nomor Referensi Transfer / Bukti Bank sebelum approve!');
      return;
    }
    onConfirm(refNo.trim(), notes.trim());
    setRefNo('');
    setNotes('');
    setErrorMsg('');
    onClose();
  };

  const formatRupiah = (val: number) => {
    return 'Rp ' + Number(val || 0).toLocaleString('id-ID');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-200 overflow-hidden text-slate-800">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-100 text-blue-700">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900">{title}</h3>
              <p className="text-xs text-slate-500">{subtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs sm:text-sm">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Amount Badge */}
          <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-between">
            <div>
              <span className="text-xs text-blue-800 block font-medium">
                {rateType === 'FIX_RATE' ? 'Penerimaan Tagihan Klien:' : 'Pembayaran ke Vendor / Driver:'}
              </span>
              <span className="font-bold text-slate-800 text-xs">{partyName}</span>
            </div>
            <span className="text-base font-black text-blue-700 font-mono">
              {formatRupiah(amount)}
            </span>
          </div>

          <div>
            <label className="block text-slate-700 font-bold mb-1 text-xs">
              Nomor Referensi Transfer / Bukti Bank <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={refNo}
              onChange={(e) => {
                setRefNo(e.target.value);
                if (e.target.value) setErrorMsg('');
              }}
              placeholder="Contoh: TRF-BCA-992102 atau REF-MANDIRI-4410"
              required
              autoFocus
              className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Nomor referensi ini akan dicatat ke audit trail dan buku kas keuangan otomatis.
            </p>
          </div>

          <div>
            <label className="block text-slate-700 font-medium mb-1 text-xs">
              Catatan Rekening / Keterangan (Opsional):
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Contoh: Transfer via KlikBCA Bisnis ke Rekening Driver Budi"
              className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
            />
          </div>

          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
            >
              <CheckCircle className="w-4 h-4" />
              <span>Verifikasi & Setujui (Approve)</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
