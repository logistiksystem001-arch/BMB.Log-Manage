import React from 'react';
import { X, Printer, Truck, FileText } from 'lucide-react';
import { RitaseItem } from '../../types/logistics';

interface SpkModalProps {
  item: RitaseItem | null;
  onClose: () => void;
}

export const SpkModal: React.FC<SpkModalProps> = ({ item, onClose }) => {
  if (!item) return null;

  const handlePrint = () => {
    window.print();
  };

  const formatRupiah = (val: number) => {
    return 'Rp ' + Number(val || 0).toLocaleString('id-ID');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-white text-slate-900 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Top Controls Bar (hidden during print) */}
        <div className="print:hidden p-4 bg-slate-900 text-white flex items-center justify-between rounded-t-2xl">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-400" />
            <span className="font-bold text-sm">Pratinjau Surat Perintah Kerja (SPK)</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak / Simpan PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="p-8 space-y-6 text-sm" id="printable-spk">
          {/* Header */}
          <div className="border-b-2 border-slate-900 pb-4 flex items-start justify-between">
            <div>
              <h1 className="text-xl font-black tracking-tight text-slate-950 uppercase">
                PT LOGISTICS PRIMA
              </h1>
              <p className="text-xs text-slate-600">
                Divisi Transportasi & Manajemen Armada Logistik Terpadu
              </p>
              <p className="text-xs text-slate-500">
                Jl. Pergudangan Logistik Terpadu No. 88 · Telp: (021) 8899-7700
              </p>
            </div>

            <div className="text-right">
              <div className="inline-block px-3 py-1 bg-slate-100 border border-slate-300 font-mono font-bold text-sm">
                SURAT PERINTAH KERJA (SPK)
              </div>
              <div className="text-xs text-slate-600 mt-1">
                No. SPK: <strong className="font-mono text-slate-900">{item.id}</strong>
              </div>
              <div className="text-xs text-slate-600">Tanggal: {item.date}</div>
            </div>
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
            <div>
              <span className="text-slate-500 block">Nama Driver / Supir:</span>
              <strong className="text-slate-900 text-sm">{item.driver}</strong>
            </div>

            <div>
              <span className="text-slate-500 block">Nomor Plat Armada:</span>
              <strong className="text-slate-900 text-sm font-mono">{item.plat}</strong>
            </div>

            <div>
              <span className="text-slate-500 block">Tipe Kendaraan:</span>
              <span className="text-slate-900 font-semibold">{item.truckType}</span>
            </div>

            <div>
              <span className="text-slate-500 block">Vendor Transportasi:</span>
              <span className="text-slate-900 font-semibold">{item.vendor}</span>
            </div>

            <div className="col-span-2">
              <span className="text-slate-500 block">Rute Pengiriman (Origin - Destination):</span>
              <strong className="text-slate-900 text-sm">{item.origin}</strong>
            </div>
          </div>

          {/* Rincian Uang Jalan */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="p-3">DESKRIPSI UANG JALAN</th>
                  <th className="p-3 text-center">PERSENTASE</th>
                  <th className="p-3 text-right">JUMLAH (IDR)</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-100">
                  <td className="p-3 font-semibold">Uang Jalan Awal Supir (BBM, Tol, Uang Saku)</td>
                  <td className="p-3 text-center font-mono font-bold">70%</td>
                  <td className="p-3 text-right font-mono font-bold text-slate-900">
                    {formatRupiah(item.buy70)}
                  </td>
                </tr>
                <tr>
                  <td className="p-3 text-slate-500">Sisa Pelunasan Vendor (Setelah POD/Surat Jalan Kembali)</td>
                  <td className="p-3 text-center font-mono text-slate-500">30%</td>
                  <td className="p-3 text-right font-mono text-slate-500">
                    {formatRupiah(item.buy30)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Syarat & Ketentuan */}
          <div className="text-[11px] text-slate-500 space-y-1">
            <p><strong>Ketentuan Supir:</strong></p>
            <p>1. Wajib memeriksa kelengkapan muatan dan segel sebelum meninggalkan lokasi muat.</p>
            <p>2. Surat jalan asli wajib ditandatangani dan dicap oleh pihak penerima gudang tujuan.</p>
            <p>3. Pelunasan sisa 30% dicairkan maksimal 3 hari kerja setelah dokumen POD fisik diserahkan ke tim operasional.</p>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-3 gap-4 pt-8 text-center text-xs">
            <div>
              <p className="text-slate-500 mb-14">Petugas Operasional,</p>
              <div className="border-t border-slate-400 pt-1 font-bold">( .................................. )</div>
            </div>

            <div>
              <p className="text-slate-500 mb-14">Driver / Supir,</p>
              <div className="border-t border-slate-400 pt-1 font-bold">( {item.driver} )</div>
            </div>

            <div>
              <p className="text-slate-500 mb-14">Penerima Barang,</p>
              <div className="border-t border-slate-400 pt-1 font-bold">( .................................. )</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
