import React from 'react';
import { X, Printer, CreditCard, FileCheck } from 'lucide-react';
import { PaymentItem } from '../../types/logistics';

interface PaymentVoucherModalProps {
  item: PaymentItem | null;
  onClose: () => void;
}

export const PaymentVoucherModal: React.FC<PaymentVoucherModalProps> = ({ item, onClose }) => {
  if (!item) return null;

  const handlePrint = () => {
    window.print();
  };

  const formatRupiah = (val: number) => {
    return 'Rp ' + Number(val || 0).toLocaleString('id-ID');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-white text-slate-900 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Top Controls Bar */}
        <div className="print:hidden p-4 bg-slate-900 text-white flex items-center justify-between rounded-t-2xl">
          <div className="flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-sm">Pratinjau Voucher Pengajuan Payment</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak / Simpan PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Voucher Body */}
        <div className="p-8 space-y-5 text-sm" id="printable-voucher">
          {/* Header */}
          <div className="border-b-2 border-slate-900 pb-3 flex items-start justify-between">
            <div>
              <h2 className="text-lg font-black uppercase tracking-tight text-slate-950">
                PT LOGISTICS PRIMA
              </h2>
              <p className="text-[11px] text-slate-500">Departemen Keuangan & Kasir Logistik</p>
            </div>

            <div className="text-right">
              <div className="inline-block px-2.5 py-0.5 bg-slate-100 border border-slate-300 font-mono font-bold text-xs">
                VOUCHER KAS KELUAR
              </div>
              <div className="text-xs text-slate-600 mt-1">
                No: <strong className="font-mono text-slate-900">{item.id}</strong>
              </div>
              <div className="text-[11px] text-slate-500">Tanggal: {item.date}</div>
            </div>
          </div>

          {/* Details Table */}
          <div className="border border-slate-300 rounded-xl overflow-hidden text-xs">
            <div className="bg-slate-50 p-3 border-b border-slate-200 flex justify-between items-center">
              <span className="text-slate-600">Peruntukan Dana:</span>
              <strong className="text-slate-900">UANG JALAN DRIVER ({item.paymentType || '70%'})</strong>
            </div>

            <div className="p-4 space-y-2">
              <div className="grid grid-cols-3 gap-2">
                <span className="text-slate-500">Nama Penerima / Driver:</span>
                <span className="col-span-2 font-bold text-slate-900">{item.driver}</span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <span className="text-slate-500">Nomor Plat Armada:</span>
                <span className="col-span-2 font-mono font-bold text-slate-900">{item.noPlat}</span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <span className="text-slate-500">Proyek / Client:</span>
                <span className="col-span-2 text-slate-900">{item.project}</span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <span className="text-slate-500">Rute Pengiriman:</span>
                <span className="col-span-2 text-slate-900">{item.rute}</span>
              </div>
            </div>

            <div className="bg-emerald-50 p-4 border-t border-slate-200 flex justify-between items-center">
              <div>
                <span className="text-xs text-emerald-800 font-semibold block">TOTAL DANA DICAIRKAN:</span>
                <span className="text-[11px] text-emerald-600 italic">Termin Pembayaran {item.paymentType || '70%'}</span>
              </div>
              <div className="text-xl font-black text-emerald-900 font-mono">
                {formatRupiah(item.buyRate || item.fixRate || 0)}
              </div>
            </div>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-3 gap-3 pt-8 text-center text-xs">
            <div>
              <p className="text-slate-500 mb-14">Diajukan Oleh,</p>
              <div className="border-t border-slate-400 pt-1 font-bold">( Operasional )</div>
            </div>

            <div>
              <p className="text-slate-500 mb-14">Disetujui Oleh,</p>
              <div className="border-t border-slate-400 pt-1 font-bold">( Kasir / Finance )</div>
            </div>

            <div>
              <p className="text-slate-500 mb-14">Penerima Dana,</p>
              <div className="border-t border-slate-400 pt-1 font-bold">( {item.driver} )</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
