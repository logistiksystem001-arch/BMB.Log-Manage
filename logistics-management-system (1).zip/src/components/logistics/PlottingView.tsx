import React, { useState } from 'react';
import { Plus, Search, MapPin, Truck, Trash2, Edit2, CreditCard, ArrowRight } from 'lucide-react';
import { PlottingItem, MasterOptions } from '../../types/logistics';

interface PlottingViewProps {
  plottingList: PlottingItem[];
  masterOptions: MasterOptions;
  onSavePlotting: (data: Partial<PlottingItem>) => void;
  onDeletePlotting: (id: string) => void;
  onUpdateStatus: (id: string, status: 'PLANNED' | 'ON THE ROAD' | 'DELIVERED') => void;
  onForwardToPayment: (item: PlottingItem) => void;
}

export const PlottingView: React.FC<PlottingViewProps> = ({
  plottingList,
  masterOptions,
  onSavePlotting,
  onDeletePlotting,
  onUpdateStatus,
  onForwardToPayment,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<PlottingItem | null>(null);

  const [formData, setFormData] = useState<{
    date: string;
    skoType: string;
    truckType: string;
    vendor: string;
    driver: string;
    plat: string;
    origin: string;
    rute: string;
    fixRate: number;
    buyRate: number;
    status: 'PLANNED' | 'ON THE ROAD' | 'DELIVERED';
    notes: string;
  }>({
    date: new Date().toISOString().split('T')[0],
    skoType: masterOptions.skoTypes[0] || 'SKO-REG (REGULER LOGISTIK)',
    truckType: masterOptions.truckTypes[0] || 'CDD (Double)',
    vendor: masterOptions.vendors[0] || 'PT FAST LOGISTIK NUSANTARA',
    driver: '',
    plat: '',
    origin: 'Jakarta',
    rute: 'Jakarta - Surabaya',
    fixRate: 4800000,
    buyRate: 4100000,
    status: 'PLANNED',
    notes: '',
  });

  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormData({
      date: new Date().toISOString().split('T')[0],
      skoType: masterOptions.skoTypes[0] || 'SKO-REG (REGULER LOGISTIK)',
      truckType: masterOptions.truckTypes[0] || 'CDD (Double)',
      vendor: masterOptions.vendors[0] || 'PT FAST LOGISTIK NUSANTARA',
      driver: '',
      plat: '',
      origin: 'Jakarta',
      rute: 'Jakarta - Surabaya',
      fixRate: 4800000,
      buyRate: 4100000,
      status: 'PLANNED',
      notes: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: PlottingItem) => {
    setEditingItem(item);
    setFormData({
      date: item.date,
      skoType: item.skoType,
      truckType: item.truckType,
      vendor: item.vendor,
      driver: item.driver,
      plat: item.plat,
      origin: item.origin,
      rute: item.rute,
      fixRate: item.fixRate || 4800000,
      buyRate: item.buyRate || 4100000,
      status: item.status,
      notes: item.notes,
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.driver || !formData.plat) {
      alert('Nama supir dan nomor plat armada wajib diisi!');
      return;
    }

    onSavePlotting({
      ...(editingItem ? { id: editingItem.id, rowIndex: editingItem.rowIndex } : {}),
      ...formData,
      fixRate: Number(formData.fixRate),
      buyRate: Number(formData.buyRate),
    });
    setIsModalOpen(false);
  };

  const filtered = plottingList.filter((item) => {
    const matchesSearch =
      item.driver.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.plat.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.rute.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter ? item.status === statusFilter : true;
    return matchesSearch && matchesStatus;
  });

  const formatRupiah = (val: number) => {
    return 'Rp ' + Number(val || 0).toLocaleString('id-ID');
  };

  return (
    <div className="space-y-5">
      {/* Action Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex flex-1 items-center gap-2">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari supir, plat nomor, atau rute perjalanan..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-300 text-slate-700 rounded-xl px-3 py-2 focus:outline-none focus:border-blue-600"
          >
            <option value="">Semua Status Armada</option>
            <option value="PLANNED">PLANNED</option>
            <option value="ON THE ROAD">ON THE ROAD</option>
            <option value="DELIVERED">DELIVERED</option>
          </select>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold shadow-xs transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Jadwal Plotting</span>
        </button>
      </div>

      {/* Main Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900">1. PLOTTING ARMADA OPERASIONAL</h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-mono font-bold">
              {filtered.length} Unit
            </span>
          </div>
          <span className="text-xs text-slate-500 hidden sm:block">
            Penjadwalan muatan yang otomatis terhubung ke modul Pengajuan Payment
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/70 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
              <tr>
                <th className="p-3">ID / TGL</th>
                <th className="p-3">ARMADA & VENDOR</th>
                <th className="p-3">DRIVER & PLAT</th>
                <th className="p-3">RUTE PENGIRIMAN</th>
                <th className="p-3 text-right">TAGIHAN KLIEN (FIX)</th>
                <th className="p-3 text-right">BIAYA VENDOR (BUY)</th>
                <th className="p-3 text-center">STATUS ARMADA</th>
                <th className="p-3 text-center">AKSI & ALUR KERJA</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400 text-xs">
                    Tidak ada jadwal plotting armada yang ditemukan.
                  </td>
                </tr>
              ) : (
                filtered.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50 transition">
                    <td className="p-3">
                      <div className="font-mono font-bold text-blue-700">{item.id}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{item.date}</div>
                    </td>
                    <td className="p-3">
                      <div className="font-semibold text-slate-900">{item.truckType}</div>
                      <div className="text-[10px] text-slate-500 truncate max-w-[150px]">
                        {item.vendor}
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="font-bold text-slate-900">{item.driver}</div>
                      <div className="text-[10px] font-mono text-slate-600 font-semibold">{item.plat}</div>
                    </td>
                    <td className="p-3 text-slate-700 font-medium">{item.rute}</td>
                    <td className="p-3 text-right font-mono font-semibold text-blue-700">
                      {formatRupiah(item.fixRate)}
                    </td>
                    <td className="p-3 text-right font-mono font-semibold text-slate-800">
                      {formatRupiah(item.buyRate)}
                    </td>
                    <td className="p-3 text-center">
                      <select
                        value={item.status}
                        onChange={(e) =>
                          onUpdateStatus(
                            item.id,
                            e.target.value as 'PLANNED' | 'ON THE ROAD' | 'DELIVERED'
                          )
                        }
                        className={`text-[10px] font-bold rounded-lg px-2 py-1 border focus:outline-none cursor-pointer uppercase ${
                          item.status === 'ON THE ROAD'
                            ? 'bg-blue-50 text-blue-700 border-blue-300'
                            : item.status === 'DELIVERED'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                            : 'bg-amber-50 text-amber-700 border-amber-300'
                        }`}
                      >
                        <option value="PLANNED">PLANNED</option>
                        <option value="ON THE ROAD">ON THE ROAD</option>
                        <option value="DELIVERED">DELIVERED</option>
                      </select>
                    </td>
                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        {/* Alirkan ke Pengajuan Payment */}
                        <button
                          onClick={() => onForwardToPayment(item)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 text-[11px] font-semibold border border-blue-200 transition cursor-pointer"
                          title="Lanjutkan ke Pengajuan Payment & Kas"
                        >
                          <CreditCard className="w-3 h-3" />
                          <span>Ke Payment</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>

                        <button
                          onClick={() => handleOpenEdit(item)}
                          className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition"
                          title="Edit Plotting"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Hapus jadwal plotting ${item.plat} (${item.driver})?`)) {
                              onDeletePlotting(item.id);
                            }
                          }}
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition"
                          title="Hapus Plotting"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit Plotting */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl text-slate-800">
            <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-base font-bold text-slate-900">
                {editingItem ? 'Edit Jadwal Plotting' : 'Tambah Plotting Armada Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-sm font-semibold"
              >
                Tutup
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tanggal</label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tipe Truk</label>
                  <select
                    value={formData.truckType}
                    onChange={(e) => setFormData({ ...formData, truckType: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  >
                    {masterOptions.truckTypes.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nama Driver</label>
                  <input
                    type="text"
                    value={formData.driver}
                    onChange={(e) => setFormData({ ...formData, driver: e.target.value })}
                    placeholder="Contoh: Hendra Gunawan"
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nomor Plat Armada</label>
                  <input
                    type="text"
                    value={formData.plat}
                    onChange={(e) => setFormData({ ...formData, plat: e.target.value })}
                    placeholder="Contoh: L 8412 UZ"
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Vendor Armada</label>
                  <select
                    value={formData.vendor}
                    onChange={(e) => setFormData({ ...formData, vendor: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  >
                    {masterOptions.vendors.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Status Perjalanan</label>
                  <select
                    value={formData.status}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        status: e.target.value as 'PLANNED' | 'ON THE ROAD' | 'DELIVERED',
                      })
                    }
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  >
                    <option value="PLANNED">PLANNED (Rencana / Standby)</option>
                    <option value="ON THE ROAD">ON THE ROAD (Dalam Perjalanan)</option>
                    <option value="DELIVERED">DELIVERED (Bongkar Selesai)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Tarif Tagihan Klien (Fix Rate Rp)
                  </label>
                  <input
                    type="number"
                    value={formData.fixRate}
                    onChange={(e) => setFormData({ ...formData, fixRate: Number(e.target.value) })}
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Tarif Biaya Vendor (Buy Rate Rp)
                  </label>
                  <input
                    type="number"
                    value={formData.buyRate}
                    onChange={(e) => setFormData({ ...formData, buyRate: Number(e.target.value) })}
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1">Rute Pengiriman</label>
                  <input
                    type="text"
                    value={formData.rute}
                    onChange={(e) => setFormData({ ...formData, rute: e.target.value })}
                    placeholder="Contoh: Surabaya - Jakarta"
                    required
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1">Catatan Tambahan</label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="Contoh: Standby muat pergudangan Rungkut Industri"
                    rows={2}
                    className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs cursor-pointer"
                >
                  Simpan Jadwal Plotting
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
