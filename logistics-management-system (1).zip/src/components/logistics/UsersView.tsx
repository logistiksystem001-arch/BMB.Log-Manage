import React, { useState } from 'react';
import {
  Plus,
  Shield,
  UserCheck,
  UserX,
  Edit2,
  Trash2,
  Mail,
  CheckCircle,
} from 'lucide-react';
import { User, UserRole } from '../../types/logistics';

interface UsersViewProps {
  usersList: User[];
  onSaveUser: (data: Partial<User>) => void;
  onDeleteUser: (id: string) => void;
  onToggleStatus: (id: string) => void;
}

export const UsersView: React.FC<UsersViewProps> = ({
  usersList,
  onSaveUser,
  onDeleteUser,
  onToggleStatus,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const availableModules = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'plotting', label: 'Plotting Armada' },
    { id: 'payment', label: 'Pengajuan Payment' },
    { id: 'keuangan', label: 'Buku Kas Keuangan' },
    { id: 'ritase', label: 'Master Data Ritase' },
    { id: 'users', label: 'Manajemen User' },
    { id: 'logs', label: 'Audit Trail / Log' },
    { id: 'settings', label: 'Pengaturan & Master' },
  ];

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: 'operasional' as UserRole,
    permissions: ['dashboard', 'plotting', 'payment'],
    active: true,
  });

  const handleOpenAdd = () => {
    setEditingUser(null);
    setFormData({
      name: '',
      email: '',
      password: '',
      role: 'operasional',
      permissions: ['dashboard', 'plotting', 'payment'],
      active: true,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (user: User) => {
    setEditingUser(user);
    setFormData({
      name: user.name,
      email: user.email,
      password: '',
      role: user.role,
      permissions: user.permissions,
      active: user.active,
    });
    setIsModalOpen(true);
  };

  const handleTogglePerm = (permId: string) => {
    setFormData((prev) => {
      const exists = prev.permissions.includes(permId);
      return {
        ...prev,
        permissions: exists
          ? prev.permissions.filter((p) => p !== permId)
          : [...prev.permissions, permId],
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) {
      alert('Nama dan email wajib diisi!');
      return;
    }

    onSaveUser({
      ...(editingUser ? { id: editingUser.id } : {}),
      name: formData.name,
      email: formData.email,
      password: formData.password || 'Admin@12345',
      role: formData.role,
      permissions: formData.permissions,
      active: formData.active,
    });

    setIsModalOpen(false);
  };

  return (
    <div className="space-y-5">
      {/* Top Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <span>Manajemen Pengguna Sistem (USERS)</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 font-semibold border border-blue-200">
              Hak Akses Role-Based
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelola staf, hak akses modul, dan status aktif akun pengguna.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold shadow-xs transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah User Baru</span>
        </button>
      </div>

      {/* Simplified Clean Table View */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/70 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
              <tr>
                <th className="p-3.5">PENGGUNA</th>
                <th className="p-3.5">EMAIL AKUN</th>
                <th className="p-3.5 text-center">ROLE</th>
                <th className="p-3.5">HAK AKSES MODUL</th>
                <th className="p-3.5 text-center">STATUS</th>
                <th className="p-3.5 text-center">AKSI</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {usersList.map((user) => (
                <tr key={user.id} className="hover:bg-slate-50 transition">
                  <td className="p-3.5">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center uppercase text-xs">
                        {user.name.substring(0, 2)}
                      </div>
                      <div>
                        <div className="font-bold text-slate-900">{user.name}</div>
                        <div className="text-[10px] text-slate-500">Terdaftar: {user.createdAt}</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-3.5 font-mono text-slate-700">{user.email}</td>
                  <td className="p-3.5 text-center">
                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase border ${
                        user.role === 'admin'
                          ? 'bg-purple-50 text-purple-700 border-purple-200'
                          : user.role === 'finance'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : user.role === 'operasional'
                          ? 'bg-blue-50 text-blue-700 border-blue-200'
                          : 'bg-slate-100 text-slate-700 border-slate-300'
                      }`}
                    >
                      {user.role}
                    </span>
                  </td>
                  <td className="p-3.5">
                    <div className="flex flex-wrap gap-1 max-w-md">
                      {user.permissions.map((p) => (
                        <span
                          key={p}
                          className="text-[10px] px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-slate-700"
                        >
                          {p}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="p-3.5 text-center">
                    <button
                      onClick={() => onToggleStatus(user.id)}
                      className={`text-[11px] font-semibold flex items-center justify-center gap-1 mx-auto cursor-pointer ${
                        user.active ? 'text-emerald-700 hover:text-emerald-800' : 'text-rose-600 hover:text-rose-700'
                      }`}
                    >
                      {user.active ? (
                        <>
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>Aktif</span>
                        </>
                      ) : (
                        <>
                          <UserX className="w-3.5 h-3.5" />
                          <span>Nonaktif</span>
                        </>
                      )}
                    </button>
                  </td>
                  <td className="p-3.5 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(user)}
                        className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition"
                        title="Edit User"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>

                      {usersList.length > 1 && (
                        <button
                          onClick={() => {
                            if (confirm(`Hapus pengguna ${user.name}?`)) {
                              onDeleteUser(user.id);
                            }
                          }}
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition"
                          title="Hapus User"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit User */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden text-slate-800">
            <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-base font-bold text-slate-900">
                {editingUser ? 'Edit Pengguna' : 'Tambah Pengguna Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-sm font-semibold"
              >
                Tutup
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Nama Lengkap</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Contoh: Budi Santoso"
                  required
                  className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Email Pengguna</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="Contoh: user@perusahaan.com"
                  required
                  className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Password {editingUser && '(Kosongkan jika tidak ingin mengubah)'}
                </label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="Minimal 6 karakter"
                  className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Peran / Role</label>
                <select
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value as UserRole })}
                  className="w-full p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600"
                >
                  <option value="admin">Super Admin (Akses Penuh)</option>
                  <option value="operasional">Admin Operasional (Plotting & Ritase)</option>
                  <option value="finance">Admin Finance (Payment & Keuangan)</option>
                  <option value="viewer">Staff Viewer (Read-only)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1.5">
                  Hak Akses Modul:
                </label>
                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
                  {availableModules.map((m) => (
                    <label key={m.id} className="flex items-center gap-2 cursor-pointer text-xs text-slate-700">
                      <input
                        type="checkbox"
                        checked={formData.permissions.includes(m.id)}
                        onChange={() => handleTogglePerm(m.id)}
                        className="rounded accent-blue-600"
                      />
                      <span>{m.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs cursor-pointer"
                >
                  Simpan Pengguna
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
