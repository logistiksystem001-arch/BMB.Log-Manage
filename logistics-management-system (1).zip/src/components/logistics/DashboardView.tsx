import React from 'react';
import {
  TrendingUp,
  DollarSign,
  Truck,
  MapPin,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  Plus,
} from 'lucide-react';
import { RitaseItem, PlottingItem, PaymentItem, KeuanganItem } from '../../types/logistics';
import { ActiveTab } from './Sidebar';

interface DashboardViewProps {
  ritaseList: RitaseItem[];
  plottingList: PlottingItem[];
  paymentList: PaymentItem[];
  keuanganList: KeuanganItem[];
  onNavigate: (tab: ActiveTab) => void;
  onOpenAddPlotting: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  ritaseList,
  plottingList,
  paymentList,
  keuanganList,
  onNavigate,
  onOpenAddPlotting,
}) => {
  const totalFixRate = ritaseList.reduce((acc, curr) => acc + (curr.fixRate || 0), 0);
  const totalBuyRate = ritaseList.reduce((acc, curr) => acc + (curr.buyRate || 0), 0);
  const totalMargin = totalFixRate - totalBuyRate;
  const marginPercentage = totalFixRate > 0 ? ((totalMargin / totalFixRate) * 100).toFixed(1) : '0';

  const currentSaldoKas = keuanganList.length > 0 ? keuanganList[keuanganList.length - 1].total : 0;

  const onTheRoadCount = plottingList.filter((p) => p.status === 'ON THE ROAD').length;
  const plannedCount = plottingList.filter((p) => p.status === 'PLANNED').length;
  const deliveredCount = plottingList.filter((p) => p.status === 'DELIVERED').length;

  const formatRupiah = (val: number) => {
    return 'Rp ' + Number(val || 0).toLocaleString('id-ID');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with Quick Actions */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>Ringkasan Eksekutif Operasional Logistik</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 font-semibold border border-blue-200">
              Live Terpadu
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Alur otomatis: Plotting Armada ➔ Pengajuan Payment ➔ Buku Kas Keuangan ➔ Master Ritase.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onOpenAddPlotting}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>1. Buat Plotting Armada</span>
          </button>

          <button
            onClick={() => onNavigate('payment')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold border border-slate-200 transition cursor-pointer"
          >
            <span>2. Buka Pengajuan Payment</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Omset (Fix Rate) */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Omset (Fix Rate)</span>
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-slate-900 mt-2 font-mono">
            {formatRupiah(totalFixRate)}
          </div>
          <div className="text-[11px] text-blue-600 mt-1 font-medium">
            {ritaseList.length} Transaksi Ritase Klien
          </div>
        </div>

        {/* Biaya Vendor (Buy Rate) */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Biaya Vendor (Buy Rate)</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <Truck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-slate-900 mt-2 font-mono">
            {formatRupiah(totalBuyRate)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Beban sewa armada & supir vendor</div>
        </div>

        {/* Margin Profit */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Gross Margin Profit</span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-emerald-600 mt-2 font-mono">
            +{formatRupiah(totalMargin)}
          </div>
          <div className="flex items-center gap-1 text-[11px] text-emerald-700 mt-1 font-semibold">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>Margin Bersih: {marginPercentage}%</span>
          </div>
        </div>

        {/* Saldo Kas Keuangan */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Saldo Kas Operasional</span>
            <div className="p-2 rounded-xl bg-purple-50 text-purple-600">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-blue-700 mt-2 font-mono">
            {formatRupiah(currentSaldoKas)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Likuiditas Kas Masuk - Keluar
          </div>
        </div>
      </div>

      {/* 2-Columns: Fleet Status & Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Fleet Plotting Status (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-blue-600" />
              <span>Status Plotting Armada</span>
            </h3>
            <button
              onClick={() => onNavigate('plotting')}
              className="text-xs text-blue-600 hover:text-blue-800 font-semibold"
            >
              Lihat Semua →
            </button>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-center">
              <div className="text-2xl font-black text-blue-700">{onTheRoadCount}</div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-blue-800 mt-1">
                On The Road
              </div>
            </div>
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-center">
              <div className="text-2xl font-black text-amber-700">{plannedCount}</div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-amber-800 mt-1">
                Planned
              </div>
            </div>
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-center">
              <div className="text-2xl font-black text-emerald-700">{deliveredCount}</div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 mt-1">
                Delivered
              </div>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <span className="text-xs font-semibold text-slate-500 block">
              Armada Bertugas Terkini:
            </span>
            {plottingList.slice(0, 4).map((p) => (
              <div
                key={p.id}
                className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-slate-900">
                    {p.plat} · <span className="text-slate-600 font-normal">{p.driver}</span>
                  </div>
                  <div className="text-[11px] text-slate-500">{p.rute}</div>
                </div>

                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase border ${
                    p.status === 'ON THE ROAD'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : p.status === 'DELIVERED'
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                      : 'bg-amber-100 text-amber-800 border-amber-300'
                  }`}
                >
                  {p.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Ritase & Billing (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Truck className="w-4 h-4 text-blue-600" />
              <span>Daftar Ritase Terkini</span>
            </h3>
            <button
              onClick={() => onNavigate('ritase')}
              className="text-xs text-blue-600 hover:text-blue-800 font-semibold"
            >
              Buka Master Ritase →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 text-[11px]">
                  <th className="pb-2 font-semibold">TANGGAL</th>
                  <th className="pb-2 font-semibold">DRIVER / PLAT</th>
                  <th className="pb-2 font-semibold">RUTE</th>
                  <th className="pb-2 font-semibold text-right">TAGIHAN (FIX)</th>
                  <th className="pb-2 font-semibold text-right">MARGIN</th>
                  <th className="pb-2 font-semibold text-center">STATUS KLIEN</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {ritaseList.slice(0, 5).map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50">
                    <td className="py-2.5 text-slate-500 font-mono">{r.date}</td>
                    <td className="py-2.5">
                      <div className="font-semibold text-slate-900">{r.driver}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{r.plat}</div>
                    </td>
                    <td className="py-2.5 text-slate-700 max-w-[140px] truncate">{r.origin}</td>
                    <td className="py-2.5 text-right font-mono text-slate-900">
                      {formatRupiah(r.fixRate)}
                    </td>
                    <td className="py-2.5 text-right font-mono font-semibold text-emerald-700">
                      +{formatRupiah(r.margin)}
                    </td>
                    <td className="py-2.5 text-center">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase border ${
                          r.statusFix === 'APPROVED'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                            : r.statusFix === 'PENGAJUAN'
                            ? 'bg-amber-50 text-amber-700 border-amber-300'
                            : 'bg-slate-100 text-slate-700 border-slate-300'
                        }`}
                      >
                        {r.statusFix}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
