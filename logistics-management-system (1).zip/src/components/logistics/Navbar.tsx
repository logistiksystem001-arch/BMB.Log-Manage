import React from 'react';
import { Truck, Shield, LogOut, Code, Link2, Sparkles, Building2 } from 'lucide-react';
import { User, CompanySettings } from '../../types/logistics';

interface NavbarProps {
  currentUser: User | null;
  companySettings: CompanySettings;
  onLogout: () => void;
  onOpenCodeModal: () => void;
  onOpenConnectModal: () => void;
  gasUrl: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  companySettings,
  onLogout,
  onOpenCodeModal,
  onOpenConnectModal,
  gasUrl,
}) => {
  return (
    <header className="bg-white border-b border-slate-200 text-slate-800 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand with Dynamic Company Name & Slogan */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold shadow-sm">
            <Truck className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-base sm:text-lg tracking-tight text-slate-900">
                {companySettings.companyName || 'PT LOGISTICS PRIMA'}
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                Sistem Terpadu
              </span>
            </div>
            <p className="text-[11px] text-slate-500 hidden sm:block truncate max-w-xl">
              {companySettings.companySlogan || 'Manajemen Armada, Ritase, Payment & Kas Keuangan'}
            </p>
          </div>
        </div>

        {/* Right Tools & User Info */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Enhanced Code.gs & Index.html Button */}
          <button
            onClick={onOpenCodeModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold border border-blue-700 shadow-xs transition cursor-pointer"
            title="Buka & Salin File Code.gs dan Index.html untuk Google Apps Script"
          >
            <Code className="w-3.5 h-3.5 text-white" />
            <span>Ambil Code.gs & Index.html</span>
          </button>

          {/* GAS Link status button */}
          <button
            onClick={onOpenConnectModal}
            className={`inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
              gasUrl
                ? 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100'
                : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
            }`}
            title="Koneksikan ke Web App Google Apps Script"
          >
            <Link2 className="w-3.5 h-3.5 text-blue-600" />
            <span className="hidden sm:inline">
              {gasUrl ? 'Terkoneksi Spreadsheet' : 'Koneksi Spreadsheet'}
            </span>
          </button>

          {/* Current User Badge */}
          {currentUser && (
            <div className="flex items-center gap-2.5 pl-2 sm:pl-3 border-l border-slate-200">
              <div className="w-8 h-8 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center text-xs font-bold text-blue-700 uppercase">
                {currentUser.name.substring(0, 2)}
              </div>
              <div className="hidden lg:block text-left text-xs">
                <div className="font-semibold text-slate-800">{currentUser.name}</div>
                <div className="text-[10px] text-slate-500 capitalize flex items-center gap-1">
                  <Shield className="w-2.5 h-2.5 text-blue-600" />
                  <span>{currentUser.role}</span>
                </div>
              </div>

              <button
                onClick={onLogout}
                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                title="Keluar"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
