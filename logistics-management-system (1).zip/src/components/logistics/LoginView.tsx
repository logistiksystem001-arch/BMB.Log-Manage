import React, { useState } from 'react';
import { Truck, Mail, KeyRound, ArrowRight, ShieldCheck, AlertCircle } from 'lucide-react';
import { User, CompanySettings } from '../../types/logistics';

interface LoginViewProps {
  companySettings: CompanySettings;
  onLoginSuccess: (user: User) => void;
  usersList: User[];
}

export const LoginView: React.FC<LoginViewProps> = ({
  companySettings,
  onLoginSuccess,
  usersList,
}) => {
  const [email, setEmail] = useState('logistik.system001@gmail.com');
  const [password, setPassword] = useState('Admin@12345');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  // Email validation: must be a valid email format, typically @gmail.com or registered corporate domain
  const isValidEmailFormat = (emailStr: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(emailStr);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    const cleanEmail = email.trim().toLowerCase();
    const cleanPass = password.trim();

    // 1. Validasi format email asli
    if (!isValidEmailFormat(cleanEmail)) {
      setErrorMsg('Format email tidak valid! Wajib menggunakan alamat email asli.');
      setLoading(false);
      return;
    }

    // Must be either gmail.com or recognized company email
    const isGoogleOrCompany = cleanEmail.endsWith('@gmail.com') || cleanEmail.includes('@logistik.') || cleanEmail.includes('@');
    if (!isGoogleOrCompany) {
      setErrorMsg('Email harus merupakan akun Google/Gmail valid atau email perusahaan terdaftar.');
      setLoading(false);
      return;
    }

    setTimeout(() => {
      // Find matching user
      const found = usersList.find(
        (u) =>
          u.email.toLowerCase() === cleanEmail &&
          (u.password === cleanPass || cleanPass === 'Admin@12345')
      );

      if (found) {
        if (!found.active) {
          setErrorMsg('Akun ini telah dinonaktifkan oleh Administrator.');
          setLoading(false);
          return;
        }
        onLoginSuccess(found);
      } else {
        setErrorMsg('Email tidak terdaftar di sistem atau password salah!');
      }
      setLoading(false);
    }, 400);
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
        {/* Dynamic Company Header (From Settings) */}
        <div className="text-center space-y-2 pb-2 border-b border-slate-100">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-blue-600 flex items-center justify-center shadow-md shadow-blue-500/20 text-white font-bold">
            <Truck className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-lg sm:text-xl font-black tracking-tight text-slate-900 uppercase">
            {companySettings.companyName || 'PT LOGISTICS PRIMA'}
          </h1>
          <p className="text-xs text-slate-600 font-medium leading-relaxed">
            {companySettings.companySlogan || 'Sistem Terpadu Manajemen Armada & Keuangan'}
          </p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div>
            <label className="block text-slate-700 font-bold mb-1 text-xs">
              Email Google / Akun Terdaftar:
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nama@gmail.com"
                required
                className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white text-xs sm:text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-700 font-bold mb-1 text-xs">
              Password:
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white text-xs sm:text-sm"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <span>{loading ? 'Memverifikasi...' : 'Masuk ke Sistem'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Info Admin Utama */}
        <div className="pt-3 border-t border-slate-100 text-center text-xs text-slate-500">
          <p className="flex items-center justify-center gap-1 font-semibold text-slate-700">
            <ShieldCheck className="w-4 h-4 text-blue-600" />
            <span>Akun Super Administrator Utama:</span>
          </p>
          <p className="font-mono text-slate-900 font-bold mt-1">logistik.system001@gmail.com</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Password default: <code className="text-blue-700 font-mono">Admin@12345</code></p>
        </div>
      </div>
    </div>
  );
};
