import React from 'react';
import {
  LayoutDashboard,
  Truck,
  MapPin,
  CreditCard,
  Wallet,
  Users,
  History,
  Settings,
} from 'lucide-react';
import { User } from '../../types/logistics';

export type ActiveTab =
  | 'dashboard'
  | 'plotting'
  | 'payment'
  | 'keuangan'
  | 'ritase'
  | 'users'
  | 'logs'
  | 'settings';

interface SidebarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  currentUser: User | null;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  currentUser,
}) => {
  const permissions = currentUser?.permissions || ['dashboard'];
  const isAdmin = currentUser?.role === 'admin';

  const hasAccess = (perm: string) => {
    if (isAdmin) return true;
    return permissions.includes(perm);
  };

  // Re-ordered to emphasize the workflow: Plotting -> Payment -> Keuangan -> Master Ritase
  const navItems = [
    {
      id: 'dashboard' as ActiveTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      perm: 'dashboard',
    },
    {
      id: 'plotting' as ActiveTab,
      label: '1. Plotting Armada',
      icon: MapPin,
      perm: 'plotting',
    },
    {
      id: 'payment' as ActiveTab,
      label: '2. Pengajuan Payment',
      icon: CreditCard,
      perm: 'payment',
    },
    {
      id: 'keuangan' as ActiveTab,
      label: '3. Buku Kas Keuangan',
      icon: Wallet,
      perm: 'keuangan',
    },
    {
      id: 'ritase' as ActiveTab,
      label: '4. Master Data Ritase',
      icon: Truck,
      perm: 'ritase',
    },
    {
      id: 'users' as ActiveTab,
      label: 'Manajemen User',
      icon: Users,
      perm: 'users',
    },
    {
      id: 'logs' as ActiveTab,
      label: 'Audit Trail / Log',
      icon: History,
      perm: 'logs',
    },
    {
      id: 'settings' as ActiveTab,
      label: 'Pengaturan & Master',
      icon: Settings,
      perm: 'settings',
    },
  ];

  return (
    <aside className="w-full lg:w-64 bg-white border-r border-slate-200 p-3 flex lg:flex-col gap-1 overflow-x-auto lg:overflow-x-visible scrollbar-none flex-shrink-0">
      <div className="hidden lg:block px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
        Alur Modul Operasional
      </div>

      {navItems.map((item) => {
        const Icon = item.icon;
        const permitted = hasAccess(item.perm);
        const isActive = activeTab === item.id;

        if (!permitted) return null;

        return (
          <button
            key={item.id}
            onClick={() => onSelectTab(item.id)}
            className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition whitespace-nowrap cursor-pointer ${
              isActive
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
            <span>{item.label}</span>
          </button>
        );
      })}
    </aside>
  );
};
