import React, { useState } from 'react';
import { History, Search, Filter } from 'lucide-react';
import { ActivityLog } from '../../types/logistics';

interface ActivityLogViewProps {
  logs: ActivityLog[];
}

export const ActivityLogView: React.FC<ActivityLogViewProps> = ({ logs }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [moduleFilter, setModuleFilter] = useState('');

  const filtered = logs.filter((log) => {
    const matchesSearch =
      log.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.userEmail.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesModule = moduleFilter ? log.module === moduleFilter : true;
    return matchesSearch && matchesModule;
  });

  return (
    <div className="space-y-5">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <History className="w-4 h-4 text-blue-600" />
            <span>Audit Trail & Riwayat Aktivitas Transaksi</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-semibold border border-emerald-200">
              Audit Keamanan
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Merekam setiap persetujuan transfer (approve), perubahan tarif, dan mutasi kas.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari log atau user..."
              className="pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
            />
          </div>

          <select
            value={moduleFilter}
            onChange={(e) => setModuleFilter(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-300 text-slate-700 rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-blue-600"
          >
            <option value="">Semua Modul</option>
            <option value="PLOTTING">PLOTTING</option>
            <option value="PAYMENT">PAYMENT</option>
            <option value="KEUANGAN">KEUANGAN</option>
            <option value="RITASE">RITASE</option>
            <option value="USERS">USERS</option>
            <option value="SETTINGS">SETTINGS</option>
          </select>
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/70 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
              <tr>
                <th className="p-3">WAKTU (TIMESTAMP)</th>
                <th className="p-3">OPERATOR / EMAIL</th>
                <th className="p-3 text-center">MODUL</th>
                <th className="p-3 text-center">AKSI</th>
                <th className="p-3">RINCIAN AKTIVITAS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-400 text-xs">
                    Belum ada riwayat aktivitas yang tercatat.
                  </td>
                </tr>
              ) : (
                filtered.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50 transition">
                    <td className="p-3 font-mono text-slate-500 whitespace-nowrap">
                      {log.timestamp}
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <div className="font-bold text-slate-900">{log.userName}</div>
                      <div className="text-[10px] text-slate-500">{log.userEmail}</div>
                    </td>
                    <td className="p-3 text-center whitespace-nowrap">
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 font-mono font-bold">
                        {log.module}
                      </span>
                    </td>
                    <td className="p-3 text-center whitespace-nowrap">
                      <span
                        className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase border ${
                          log.action === 'APPROVE'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                            : log.action === 'CREATE'
                            ? 'bg-blue-50 text-blue-700 border-blue-300'
                            : log.action === 'DELETE'
                            ? 'bg-rose-50 text-rose-700 border-rose-300'
                            : 'bg-amber-50 text-amber-700 border-amber-300'
                        }`}
                      >
                        {log.action}
                      </span>
                    </td>
                    <td className="p-3 text-slate-800 font-medium">{log.details}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
