import React from 'react';
import { X, Printer, FileText, CheckCircle2 } from 'lucide-react';
import { PaymentItem, CompanySettings } from '../../types/logistics';

interface PaymentRekapPdfModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedItems: PaymentItem[];
  companySettings: CompanySettings;
}

export const PaymentRekapPdfModal: React.FC<PaymentRekapPdfModalProps> = ({
  isOpen,
  onClose,
  selectedItems,
  companySettings,
}) => {
  if (!isOpen || selectedItems.length === 0) return null;

  const handlePrint = () => {
    window.print();
  };

  const formatRupiah = (val: number) => {
    return 'Rp ' + Number(val || 0).toLocaleString('id-ID');
  };

  const totalFixRate = selectedItems.reduce((acc, curr) => acc + (curr.fixRate || 0), 0);
  const totalBuyRate = selectedItems.reduce((acc, curr) => acc + (curr.buyRate || 0), 0);
  const totalMargin = totalFixRate - totalBuyRate;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs">
      <div className="bg-white text-slate-900 rounded-2xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col border border-slate-200">
        {/* Controls Bar (hidden during print) */}
        <div className="print:hidden p-4 bg-slate-900 text-white flex items-center justify-between rounded-t-2xl">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-400" />
            <span className="font-bold text-sm">
              Pratinjau Rekap Pembayaran Terpilih ({selectedItems.length} Item)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-sm cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak / Download PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Document Sheet */}
        <div className="p-8 space-y-6 text-sm" id="printable-rekap-payment">
          {/* Company Header */}
          <div className="border-b-2 border-slate-900 pb-4 flex items-start justify-between">
            <div>
              <h1 className="text-xl font-black tracking-tight text-slate-950 uppercase">
                {companySettings.companyName || 'PT LOGISTICS PRIMA'}
              </h1>
              <p className="text-xs text-slate-700 font-medium">
                {companySettings.companySlogan || 'Manajemen Armada & Operasional Logistik'}
              </p>
              <p className="text-xs text-slate-500 mt-1">{companySettings.address}</p>
              <p className="text-xs text-slate-500">
                Telp: {companySettings.phone} · Email: {companySettings.email}
              </p>
            </div>

            <div className="text-right">
              <div className="inline-block px-3 py-1 bg-slate-100 border border-slate-300 font-mono font-bold text-sm">
                REKAP PENGAJUAN PEMBAYARAN
              </div>
              <div className="text-xs text-slate-600 mt-1">
                No: <strong className="font-mono text-slate-900">REKAP-{Date.now().toString().slice(-6)}</strong>
              </div>
              <div className="text-xs text-slate-600">
                Tanggal Cetak: {new Date().toISOString().split('T')[0]}
              </div>
            </div>
          </div>

          {/* Table of selected payments */}
          <div className="border border-slate-300 rounded-xl overflow-hidden text-xs">
            <table className="w-full text-left">
              <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                <tr>
                  <th className="p-2.5">NO</th>
                  <th className="p-2.5">ID / TGL</th>
                  <th className="p-2.5">DRIVER & NO PLAT</th>
                  <th className="p-2.5">RUTE / PROYEK</th>
                  <th className="p-2.5 text-right">TAGIHAN KLIEN (FIX)</th>
                  <th className="p-2.5 text-right">BAYAR VENDOR (BUY)</th>
                  <th className="p-2.5 text-center">STATUS KLIEN</th>
                  <th className="p-2.5 text-center">STATUS VENDOR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {selectedItems.map((item, idx) => (
                  <tr key={item.id} className="hover:bg-slate-50">
                    <td className="p-2.5 text-slate-500 font-mono">{idx + 1}</td>
                    <td className="p-2.5">
                      <div className="font-mono font-bold text-slate-900">{item.id}</div>
                      <div className="text-[10px] text-slate-500">{item.date}</div>
                    </td>
                    <td className="p-2.5">
                      <div className="font-semibold text-slate-900">{item.driver}</div>
                      <div className="text-[10px] text-slate-600 font-mono">{item.noPlat}</div>
                    </td>
                    <td className="p-2.5 text-slate-700">
                      <div>{item.rute}</div>
                      <div className="text-[10px] text-slate-500">{item.project}</div>
                    </td>
                    <td className="p-2.5 text-right font-mono font-semibold text-slate-900">
                      {formatRupiah(item.fixRate)}
                      {item.refNoFixRate && (
                        <div className="text-[9px] text-emerald-700">Ref: {item.refNoFixRate}</div>
                      )}
                    </td>
                    <td className="p-2.5 text-right font-mono font-semibold text-slate-900">
                      {formatRupiah(item.buyRate)}
                      {item.refNoBuyRate && (
                        <div className="text-[9px] text-blue-700">Ref: {item.refNoBuyRate}</div>
                      )}
                    </td>
                    <td className="p-2.5 text-center font-bold">
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-100 border border-slate-300">
                        {item.statusFixRate}
                      </span>
                    </td>
                    <td className="p-2.5 text-center font-bold">
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-100 border border-slate-300">
                        {item.statusBuyRate}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-300 text-slate-900">
                <tr>
                  <td colSpan={4} className="p-3 text-right uppercase">
                    Total Rekapitulasi:
                  </td>
                  <td className="p-3 text-right font-mono text-sm text-blue-700">
                    {formatRupiah(totalFixRate)}
                  </td>
                  <td className="p-3 text-right font-mono text-sm text-slate-900">
                    {formatRupiah(totalBuyRate)}
                  </td>
                  <td colSpan={2} className="p-3 text-center text-emerald-700 font-mono text-xs">
                    Margin: +{formatRupiah(totalMargin)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Pengurus Signatures from Company Settings */}
          <div className="pt-8">
            <p className="text-xs text-slate-600 mb-6 font-semibold">
              Disetujui dan ditandatangani oleh pejabat yang berwenang:
            </p>
            <div className="grid grid-cols-3 gap-6 text-center text-xs">
              {companySettings.officers && companySettings.officers.length > 0 ? (
                companySettings.officers.map((officer) => (
                  <div key={officer.id} className="flex flex-col items-center">
                    <p className="text-slate-600 mb-16">{officer.position} ({officer.role})</p>
                    <div className="w-full border-t border-slate-900 pt-1 font-bold text-slate-950">
                      ( {officer.name} )
                    </div>
                  </div>
                ))
              ) : (
                <>
                  <div className="flex flex-col items-center">
                    <p className="text-slate-600 mb-16">Operasional & Armada</p>
                    <div className="w-full border-t border-slate-900 pt-1 font-bold">( .................................. )</div>
                  </div>
                  <div className="flex flex-col items-center">
                    <p className="text-slate-600 mb-16">Finance & Kasir</p>
                    <div className="w-full border-t border-slate-900 pt-1 font-bold">( .................................. )</div>
                  </div>
                  <div className="flex flex-col items-center">
                    <p className="text-slate-600 mb-16">Direktur Utama</p>
                    <div className="w-full border-t border-slate-900 pt-1 font-bold">( .................................. )</div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
