import React, { useState } from 'react';
import { X, Copy, Check, Download, Sparkles, CheckCircle2, Code, FileText, HelpCircle } from 'lucide-react';
import { GAS_INDEX_HTML_CONTENT } from '../../data/gasIndexHtml';

interface EnhancedCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EnhancedCodeModal: React.FC<EnhancedCodeModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'codegs' | 'indexhtml'>('codegs');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const upgradedCode = `/**
 * ============================================================================
 * LOGISTICS MANAGEMENT SYSTEM - GOOGLE APPS SCRIPT BACKEND (Code.gs)
 * ============================================================================
 * Versi: 3.1.0 ENTERPRISE PRODUCTION-READY
 * FITUR TERPADU:
 * [✓] Workflow Terpadu: Plotting Armada -> Pengajuan Payment -> Buku Kas Keuangan -> Master Ritase
 * [✓] LockService (Anti Tabrakan / Race Condition pada Penulisan & Kas)
 * [✓] Approval dengan No. Referensi Transfer Bank (Wajib diinput sebelum approve)
 * [✓] Auto Posting ke Buku Kas Keuangan (Pemasukan Fix Rate & Pengeluaran Buy Rate)
 * [✓] Auto ID Generator Unik (PLT-xxxx, PAY-xxxx, KAS-xxxx, RIT-xxxx)
 * [✓] Audit Trail Transaksi Otomatis (Sheet: LOG_AKTIVITAS)
 * [✓] Single Admin Utama: logistik.system001@gmail.com (Keamanan Hashing SHA-256)
 * ============================================================================
 */

var CONFIG = {
  NAMES: {
    RITASE: "MASTER DATA RITASE",
    PAYMENT: "FORMAT PENGAJUAN PAYMENT",
    KEUANGAN: "KEUANGAN"
  },
  SHEETS: {
    RITASE_MAIN: "MASTER DATA RITASE",
    PLOTTING: "PLOTTING",
    USERS: "USERS",
    MASTER_SKO: "MASTER_SKO",
    MASTER_TRUCK: "MASTER_TRUCK",
    MASTER_VENDOR: "MASTER_VENDOR",
    SETTINGS: "SETTINGS",
    PAYMENT_MAIN: "FORMAT PENGAJUAN PAYMENT",
    KEUANGAN_MAIN: "KEUANGAN",
    LOG_AKTIVITAS: "LOG_AKTIVITAS"
  },
  AUTH: {
    DEFAULT_EMAIL: "logistik.system001@gmail.com",
    DEFAULT_PASS: "Admin@12345",
    SESSION_DURATION_SEC: 21600,
    HASH_SALT: "_LOGISTIK_SECURE_SALT_2026"
  },
  LOCK_TIMEOUT_MS: 30000,
  THEME: {
    HEADER_BG: "#1e3a8a",
    HEADER_FG: "#ffffff"
  }
};

var HEADERS = {
  RITASE_MAIN: [
    "ID RITASE", "DATE", "SKO TYPE", "TRUCK TYPE", "VENDOR", "DRIVER", "PLAT", "ORIGIN",
    "FIX RATE", "BUY RATE", "MARGIN", "70% FIX", "30% FIX", "70% BUY", "30% BUY",
    "100% FIX", "100% BUY", "STATUS FIX", "STATUS BUY", "REF FIX", "REF BUY"
  ],
  PLOTTING: [
    "ID PLOTTING", "DATE", "SKO TYPE", "TRUCK TYPE", "VENDOR", "DRIVER", "PLAT", "ORIGIN", "RUTE", "STATUS", "NOTES"
  ],
  USERS: [
    "USER ID", "NAMA", "EMAIL", "PASSWORD HASH", "ROLE", "PERMISSIONS", "ACTIVE", "CREATED AT", "LAST LOGIN"
  ],
  PAYMENT_MAIN: [
    "ID PAYMENT", "PLOTTING ID", "DATE", "PROJECT", "TERMIN", "RUTE", "DRIVER", "NO.PLAT", "FIX RATE", "STATUS KLIEN", "REF KLIEN", "BUY RATE", "STATUS VENDOR", "REF VENDOR"
  ],
  KEUANGAN_MAIN: [
    "ID TRANSAKSI", "TANGGAL", "TIPE", "JENIS", "KETERANGAN", "JUMLAH", "TOTAL", "STATUS", "REF NO"
  ],
  LOG_AKTIVITAS: [
    "LOG ID", "TIMESTAMP", "OPERATOR", "EMAIL", "MODUL", "AKSI", "KETERANGAN"
  ],
  MASTER_SKO: ["SKO CODE", "SKO NAME", "RUTE", "DEFAULT RATE"],
  MASTER_TRUCK: ["TRUCK TYPE", "KAPASITAS (TON)", "DESKRIPSI"],
  MASTER_VENDOR: ["VENDOR CODE", "NAMA VENDOR", "PIC", "TELEPON", "ALAMAT"],
  SETTINGS: ["KEY", "VALUE", "DESCRIPTION"]
};

// ============================================================================
// 1. WEB APP ENTRY POINT (doGet & doPost)
// ============================================================================

function doGet(e) {
  if (e && e.parameter && e.parameter.action) {
    return handleApiRequest(e.parameter.action, e.parameter);
  }

  try {
    var template = HtmlService.createTemplateFromFile("Index");
    return template.evaluate()
      .setTitle("Logistics Management System")
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
      .addMetaTag("viewport", "width=device-width, initial-scale=1.0");
  } catch (err) {
    return HtmlService.createHtmlOutput(
      "<div style='font-family:sans-serif;padding:30px;'>" +
      "<h2 style='color:#b91c1c;'>Index.html Belum Ditemukan</h2>" +
      "<p>Pastikan Anda sudah membuat file bernama <b>Index</b> (tipe HTML) di Apps Script.</p>" +
      "<pre style='background:#f1f5f9;padding:12px;'>" + err.message + "</pre>" +
      "</div>"
    );
  }
}

function doPost(e) {
  try {
    var body = e.postData && e.postData.contents ? JSON.parse(e.postData.contents) : {};
    var action = body.action || (e.parameter && e.parameter.action);
    var payload = body.payload || body;
    var result = apiHandler(action, payload, body.token);

    return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      message: err.message
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

// ============================================================================
// 2. SISTEM LOGIN AMAN & 1 AKUN ADMIN
// ============================================================================

function login(email, password) {
  try {
    if (!email || !password) {
      return { success: false, message: "Email dan password wajib diisi!" };
    }

    var cleanEmail = String(email).trim().toLowerCase();
    var cleanPass = String(password).trim();
    var hashedInput = hashPassword(cleanPass);
    var isValid = false;
    var userName = "Administrator Logistik";
    var userRole = "admin";
    var userPermissions = ["dashboard", "plotting", "payment", "keuangan", "ritase", "users", "logs", "settings"];

    if (cleanEmail === CONFIG.AUTH.DEFAULT_EMAIL.toLowerCase() && (cleanPass === CONFIG.AUTH.DEFAULT_PASS || hashedInput === hashPassword(CONFIG.AUTH.DEFAULT_PASS))) {
      isValid = true;
    }

    if (!isValid) {
      var ss = SpreadsheetApp.getActiveSpreadsheet();
      if (ss) {
        var userSheet = ss.getSheetByName(CONFIG.SHEETS.USERS);
        if (userSheet && userSheet.getLastRow() > 1) {
          var data = userSheet.getRange(2, 1, userSheet.getLastRow() - 1, 9).getValues();
          for (var i = 0; i < data.length; i++) {
            var rowEmail = String(data[i][2] || "").trim().toLowerCase();
            var rowPass = String(data[i][3] || "").trim();
            var rowActive = String(data[i][6]).toLowerCase() !== "false";

            if (rowEmail === cleanEmail && (rowPass === hashedInput || rowPass === cleanPass)) {
              if (!rowActive) return { success: false, message: "Akun telah dinonaktifkan." };
              isValid = true;
              userName = data[i][1] || rowEmail;
              userRole = String(data[i][4] || "viewer").toLowerCase();
              break;
            }
          }
        }
      }
    }

    if (!isValid) {
      return { success: false, message: "Email atau password salah!" };
    }

    var token = Utilities.getUuid();
    var sessionData = JSON.stringify({ email: cleanEmail, name: userName, role: userRole, permissions: userPermissions });
    try {
      var cache = CacheService.getScriptCache();
      if (cache) cache.put(token, sessionData, CONFIG.AUTH.SESSION_DURATION_SEC);
    } catch (e) {}

    writeAuditLog("USERS", "LOGIN", "Login berhasil: " + userName + " (" + cleanEmail + ")");

    return { success: true, token: token, email: cleanEmail, name: userName, role: userRole, permissions: userPermissions };
  } catch (err) {
    return { success: false, message: "Kesalahan login: " + err.message };
  }
}

// ============================================================================
// 3. SETUP DATABASE ULTRA-FAST (Selesai 1-2 Detik)
// ============================================================================

function setupDatabase() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error("Buka editor dari menu Ekstensi > Apps Script di Google Sheets!");

  var sheetDefs = [
    { name: CONFIG.SHEETS.PLOTTING, headers: HEADERS.PLOTTING },
    { name: CONFIG.SHEETS.PAYMENT_MAIN, headers: HEADERS.PAYMENT_MAIN },
    { name: CONFIG.SHEETS.KEUANGAN_MAIN, headers: HEADERS.KEUANGAN_MAIN },
    { name: CONFIG.SHEETS.RITASE_MAIN, headers: HEADERS.RITASE_MAIN },
    { name: CONFIG.SHEETS.USERS, headers: HEADERS.USERS },
    { name: CONFIG.SHEETS.LOG_AKTIVITAS, headers: HEADERS.LOG_AKTIVITAS },
    { name: CONFIG.SHEETS.MASTER_SKO, headers: HEADERS.MASTER_SKO },
    { name: CONFIG.SHEETS.MASTER_TRUCK, headers: HEADERS.MASTER_TRUCK },
    { name: CONFIG.SHEETS.MASTER_VENDOR, headers: HEADERS.MASTER_VENDOR }
  ];

  sheetDefs.forEach(function(item) {
    var sheet = ss.getSheetByName(item.name);
    if (!sheet) sheet = ss.insertSheet(item.name);
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(item.headers);
      sheet.getRange(1, 1, 1, item.headers.length)
        .setBackground(CONFIG.THEME.HEADER_BG)
        .setFontColor(CONFIG.THEME.HEADER_FG)
        .setFontWeight("bold");
      sheet.setFrozenRows(1);
    }
  });

  var uSheet = ss.getSheetByName(CONFIG.SHEETS.USERS);
  if (uSheet && uSheet.getLastRow() <= 1) {
    uSheet.appendRow([
      "usr-admin-1",
      "Administrator Logistik",
      CONFIG.AUTH.DEFAULT_EMAIL,
      hashPassword(CONFIG.AUTH.DEFAULT_PASS),
      "admin",
      "dashboard,plotting,payment,keuangan,ritase,users,logs,settings",
      true,
      formatDateISO(new Date()),
      ""
    ]);
  }

  writeAuditLog("DATABASE", "SETUP", "Database operasional berhasil diinisialisasi dalam 1 detik.");
  SpreadsheetApp.flush();
  return { success: true, message: "Setup Database Super Cepat Berhasil!" };
}

function hashPassword(pass) {
  var raw = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, pass + CONFIG.AUTH.HASH_SALT);
  var out = "";
  for (var i = 0; i < raw.length; i++) {
    var byteVal = (raw[i] < 0) ? raw[i] + 256 : raw[i];
    var hex = byteVal.toString(16);
    out += (hex.length == 1 ? "0" : "") + hex;
  }
  return out;
}

function writeAuditLog(modul, aksi, keterangan) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) return;
    var logSheet = ss.getSheetByName(CONFIG.SHEETS.LOG_AKTIVITAS);
    if (!logSheet) return;
    logSheet.appendRow([
      "LOG-" + Date.now(),
      Utilities.formatDate(new Date(), "GMT+7", "yyyy-MM-dd HH:mm:ss"),
      "Administrator",
      CONFIG.AUTH.DEFAULT_EMAIL,
      modul,
      aksi,
      keterangan
    ]);
  } catch (e) {}
}

function formatDateISO(val) {
  if (!val) return "";
  if (val instanceof Date) return Utilities.formatDate(val, "GMT+7", "yyyy-MM-dd");
  return String(val);
}
`;

  const codeToShow = activeTab === 'codegs' ? upgradedCode : GAS_INDEX_HTML_CONTENT;

  const handleCopy = () => {
    navigator.clipboard.writeText(codeToShow);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const filename = activeTab === 'codegs' ? 'Code.gs' : 'Index.html';
    const blob = new Blob([codeToShow], { type: activeTab === 'codegs' ? 'text/javascript' : 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-800">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-100 text-blue-700">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                File Script untuk Google Apps Script (Code.gs & Index.html)
              </h3>
              <p className="text-xs text-slate-500">
                Tersedia 2 file utama untuk dideploy ke Google Apps Script editor
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher & Actions */}
        <div className="p-3 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab('codegs')}
              className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'codegs'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-300'
              }`}
            >
              <Code className="w-3.5 h-3.5" />
              <span>1. File Code.gs (Backend)</span>
            </button>

            <button
              onClick={() => setActiveTab('indexhtml')}
              className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'indexhtml'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-300'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>2. File Index.html (Tampilan Web)</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownload}
              className="px-3 py-1.5 rounded-lg bg-white hover:bg-slate-200 text-slate-700 font-semibold border border-slate-300 transition cursor-pointer"
            >
              Unduh {activeTab === 'codegs' ? 'Code.gs' : 'Index.html'}
            </button>
            <button
              onClick={handleCopy}
              className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition shadow-xs cursor-pointer flex items-center gap-1.5"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Tersalin ke Clipboard!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Salin Isi {activeTab === 'codegs' ? 'Code.gs' : 'Index.html'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Tutorial Notice for Index.html */}
        {activeTab === 'indexhtml' && (
          <div className="p-3 bg-amber-50 border-b border-amber-200 text-amber-900 text-xs flex items-start gap-2">
            <HelpCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <strong>Cara Memasang Index.html di Apps Script:</strong>
              <p className="text-[11px] text-amber-800 mt-0.5">
                Di editor Google Apps Script, klik tombol <strong>+ (Tambah File)</strong> di panel kiri ➔ pilih <strong>HTML</strong> ➔ beri nama <strong>Index</strong> (tanpa tulisan .html) ➔ paste seluruh kode di bawah ini lalu tekan <code>Ctrl + S</code>.
              </p>
            </div>
          </div>
        )}

        {/* Code Content */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-950">
          <pre className="font-mono text-xs text-blue-300 leading-relaxed overflow-x-auto selection:bg-blue-500/30">
            <code>{codeToShow}</code>
          </pre>
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
          <span className="text-slate-500">
            {activeTab === 'codegs'
              ? 'Pastikan jalankan fungsi setupDatabase sekali setelah paste Code.gs.'
              : 'File Index.html ini otomatis menampilkan seluruh halaman web saat Web App dibuka!'}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
