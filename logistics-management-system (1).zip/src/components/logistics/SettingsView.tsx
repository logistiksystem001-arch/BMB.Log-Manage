import React, { useState } from 'react';
import {
  Building2,
  Users,
  Layers,
  Truck,
  Plus,
  Trash2,
  Edit2,
  CheckCircle,
  Database,
  Link2,
  FileSignature,
  Save,
} from 'lucide-react';
import {
  CompanySettings,
  Officer,
  MasterVendor,
  MasterTruck,
  MasterSKO,
} from '../../types/logistics';

interface SettingsViewProps {
  companySettings: CompanySettings;
  onSaveCompanySettings: (settings: CompanySettings) => void;
  masterVendors: MasterVendor[];
  onSaveVendor: (v: MasterVendor) => void;
  onDeleteVendor: (id: string) => void;
  masterTrucks: MasterTruck[];
  onSaveTruck: (t: MasterTruck) => void;
  onDeleteTruck: (id: string) => void;
  masterSKOs: MasterSKO[];
  onSaveSKO: (s: MasterSKO) => void;
  onDeleteSKO: (id: string) => void;
  gasUrl: string;
  onSaveGasUrl: (url: string) => void;
  onRunSetupDatabase: (withSample: boolean) => void;
  onClearOperationalData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  companySettings,
  onSaveCompanySettings,
  masterVendors,
  onSaveVendor,
  onDeleteVendor,
  masterTrucks,
  onSaveTruck,
  onDeleteTruck,
  masterSKOs,
  onSaveSKO,
  onDeleteSKO,
  gasUrl,
  onSaveGasUrl,
  onRunSetupDatabase,
  onClearOperationalData,
}) => {
  // Company info state
  const [companyName, setCompanyName] = useState(companySettings.companyName);
  const [companySlogan, setCompanySlogan] = useState(companySettings.companySlogan);
  const [address, setAddress] = useState(companySettings.address);
  const [phone, setPhone] = useState(companySettings.phone);
  const [email, setEmail] = useState(companySettings.email);
  const [officers, setOfficers] = useState<Officer[]>(companySettings.officers || []);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // New Officer form
  const [newOfficerName, setNewOfficerName] = useState('');
  const [newOfficerPos, setNewOfficerPos] = useState('');
  const [newOfficerRole, setNewOfficerRole] = useState('Menyetujui');

  // Vendor form
  const [newVendorName, setNewVendorName] = useState('');
  const [newVendorPic, setNewVendorPic] = useState('');
  const [newVendorPhone, setNewVendorPhone] = useState('');

  // Truck form
  const [newTruckType, setNewTruckType] = useState('');
  const [newTruckCapacity, setNewTruckCapacity] = useState(5.0);

  // SKO form
  const [newSKOCode, setNewSKOCode] = useState('');
  const [newSKOName, setNewSKOName] = useState('');
  const [newSKORoute, setNewSKORoute] = useState('');

  // GAS url
  const [gasUrlInput, setGasUrlInput] = useState(gasUrl);

  const handleSaveAllCompany = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveCompanySettings({
      companyName: companyName.trim(),
      companySlogan: companySlogan.trim(),
      address: address.trim(),
      phone: phone.trim(),
      email: email.trim(),
      officers,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleAddOfficer = () => {
    if (!newOfficerName || !newOfficerPos) {
      alert('Nama pengurus dan jabatan wajib diisi!');
      return;
    }
    const newOfficer: Officer = {
      id: 'off-' + Date.now(),
      name: newOfficerName.trim(),
      position: newOfficerPos.trim(),
      role: newOfficerRole.trim(),
    };
    const updated = [...officers, newOfficer];
    setOfficers(updated);
    setNewOfficerName('');
    setNewOfficerPos('');
    onSaveCompanySettings({
      companyName,
      companySlogan,
      address,
      phone,
      email,
      officers: updated,
    });
  };

  const handleDeleteOfficer = (id: string) => {
    const updated = officers.filter((o) => o.id !== id);
    setOfficers(updated);
    onSaveCompanySettings({
      companyName,
      companySlogan,
      address,
      phone,
      email,
      officers: updated,
    });
  };

  const handleAddVendor = () => {
    if (!newVendorName) return;
    onSaveVendor({
      id: 'vnd-' + Date.now(),
      code: 'VND-' + String(masterVendors.length + 1).padStart(3, '0'),
      name: newVendorName.trim(),
      pic: newVendorPic.trim() || 'PIC Vendor',
      phone: newVendorPhone.trim() || '-',
      address: 'Kantor Vendor',
    });
    setNewVendorName('');
    setNewVendorPic('');
    setNewVendorPhone('');
  };

  const handleAddTruck = () => {
    if (!newTruckType) return;
    onSaveTruck({
      id: 'trk-' + Date.now(),
      type: newTruckType.trim(),
      capacityTon: Number(newTruckCapacity),
      description: `Kapasitas ${newTruckCapacity} Ton`,
    });
    setNewTruckType('');
  };

  const handleAddSKO = () => {
    if (!newSKOCode || !newSKOName) return;
    onSaveSKO({
      id: 'sko-' + Date.now(),
      code: newSKOCode.trim(),
      name: newSKOName.trim(),
      rute: newSKORoute.trim() || 'Rute Reguler',
      defaultRate: 4500000,
    });
    setNewSKOCode('');
    setNewSKOName('');
    setNewSKORoute('');
  };

  return (
    <div className="space-y-6">
      {/* 1. Pengaturan Identitas Perusahaan & Slogan */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-50 text-blue-700">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Identitas Perusahaan & Slogan Web
              </h3>
              <p className="text-xs text-slate-500">
                Nama dan slogan ini otomatis menggantikan teks kiri atas web dan halaman login
              </p>
            </div>
          </div>

          {savedSuccess && (
            <span className="text-xs text-emerald-700 font-bold flex items-center gap-1 animate-in fade-in">
              <CheckCircle className="w-4 h-4" />
              <span>Tersimpan!</span>
            </span>
          )}
        </div>

        <form onSubmit={handleSaveAllCompany} className="space-y-4 text-xs sm:text-sm">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Nama Perusahaan (Tampil di Kiri Atas Web & Login):
              </label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="Contoh: PT LOGISTICS PRIMA NUSANTARA"
                required
                className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-bold focus:outline-none focus:border-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Slogan Perusahaan (Tampil di Subtitle Kiri Atas):
              </label>
              <input
                type="text"
                value={companySlogan}
                onChange={(e) => setCompanySlogan(e.target.value)}
                placeholder="Contoh: Solusi Cepat, Aman & Terpercaya Manajemen Armada Logistik"
                required
                className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Alamat Kantor (Untuk Dokumen Cetak / PDF):
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Alamat kantor pusat perusahaan..."
                className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Nomor Telepon & Kontak:
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="(021) 8899-7700"
                className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Identitas Perusahaan</span>
            </button>
          </div>
        </form>
      </div>

      {/* 2. Pengaturan Nama Pengurus & Jabatan (Tanda Tangan Dokumen PDF) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
          <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
            <FileSignature className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Pengurus Perusahaan & Penanda Tangan Dokumen PDF
            </h3>
            <p className="text-xs text-slate-500">
              Nama dan jabatan di bawah ini otomatis dicetak pada kolom tanda tangan SPK & Rekap Payment
            </p>
          </div>
        </div>

        {/* Existing Officers List */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {officers.map((officer) => (
            <div
              key={officer.id}
              className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-start justify-between text-xs"
            >
              <div>
                <div className="font-bold text-slate-900 text-sm">{officer.name}</div>
                <div className="text-slate-600 font-semibold">{officer.position}</div>
                <div className="text-[10px] text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 inline-block mt-1 font-medium">
                  {officer.role}
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleDeleteOfficer(officer.id)}
                className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded"
                title="Hapus Pengurus"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        {/* Form Tambah Pengurus */}
        <div className="p-3.5 rounded-xl bg-blue-50/50 border border-blue-200 space-y-2">
          <span className="text-xs font-bold text-blue-900 block">
            + Tambah Pejabat / Pengurus Penanda Tangan:
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input
              type="text"
              value={newOfficerName}
              onChange={(e) => setNewOfficerName(e.target.value)}
              placeholder="Nama Lengkap (Contoh: Hafid Dimas Febryan)"
              className="p-2 rounded-lg bg-white border border-slate-300 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
            />
            <input
              type="text"
              value={newOfficerPos}
              onChange={(e) => setNewOfficerPos(e.target.value)}
              placeholder="Jabatan (Contoh: Direktur Operasional)"
              className="p-2 rounded-lg bg-white border border-slate-300 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
            />
            <div className="flex gap-2">
              <input
                type="text"
                value={newOfficerRole}
                onChange={(e) => setNewOfficerRole(e.target.value)}
                placeholder="Peran (Mengetahui / Finance / Operasional)"
                className="flex-1 p-2 rounded-lg bg-white border border-slate-300 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
              />
              <button
                type="button"
                onClick={handleAddOfficer}
                className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold cursor-pointer whitespace-nowrap"
              >
                Tambah
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Master Data: Vendor, Kategori SKO, Tipe Truk */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Master Vendor */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h4 className="text-xs font-bold text-slate-900 uppercase">Master Vendor Armada</h4>
            <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-600 font-bold">
              {masterVendors.length}
            </span>
          </div>

          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
            {masterVendors.map((v) => (
              <div
                key={v.id}
                className="p-2 rounded-lg bg-slate-50 border border-slate-200 text-xs flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-slate-800">{v.name}</div>
                  <div className="text-[10px] text-slate-500">PIC: {v.pic} ({v.phone})</div>
                </div>
                <button
                  onClick={() => onDeleteVendor(v.id)}
                  className="p-1 text-rose-500 hover:text-rose-700"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-1.5">
            <input
              type="text"
              value={newVendorName}
              onChange={(e) => setNewVendorName(e.target.value)}
              placeholder="Nama Vendor Baru..."
              className="w-full p-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
            />
            <div className="flex gap-1.5">
              <input
                type="text"
                value={newVendorPic}
                onChange={(e) => setNewVendorPic(e.target.value)}
                placeholder="Nama PIC..."
                className="w-1/2 p-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
              />
              <button
                type="button"
                onClick={handleAddVendor}
                className="w-1/2 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold"
              >
                + Vendor
              </button>
            </div>
          </div>
        </div>

        {/* Master Tipe Truk */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h4 className="text-xs font-bold text-slate-900 uppercase">Master Tipe Truk</h4>
            <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-600 font-bold">
              {masterTrucks.length}
            </span>
          </div>

          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
            {masterTrucks.map((t) => (
              <div
                key={t.id}
                className="p-2 rounded-lg bg-slate-50 border border-slate-200 text-xs flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-slate-800">{t.type}</div>
                  <div className="text-[10px] text-slate-500">{t.capacityTon} Ton</div>
                </div>
                <button
                  onClick={() => onDeleteTruck(t.id)}
                  className="p-1 text-rose-500 hover:text-rose-700"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-100 flex gap-1.5">
            <input
              type="text"
              value={newTruckType}
              onChange={(e) => setNewTruckType(e.target.value)}
              placeholder="Tipe Truk Baru..."
              className="flex-1 p-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
            />
            <button
              type="button"
              onClick={handleAddTruck}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold"
            >
              + Truk
            </button>
          </div>
        </div>

        {/* Master SKO */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h4 className="text-xs font-bold text-slate-900 uppercase">Master Kategori SKO</h4>
            <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-600 font-bold">
              {masterSKOs.length}
            </span>
          </div>

          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
            {masterSKOs.map((s) => (
              <div
                key={s.id}
                className="p-2 rounded-lg bg-slate-50 border border-slate-200 text-xs flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-slate-800">{s.code} - {s.name}</div>
                  <div className="text-[10px] text-slate-500">{s.rute}</div>
                </div>
                <button
                  onClick={() => onDeleteSKO(s.id)}
                  className="p-1 text-rose-500 hover:text-rose-700"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-1.5">
            <div className="flex gap-1.5">
              <input
                type="text"
                value={newSKOCode}
                onChange={(e) => setNewSKOCode(e.target.value)}
                placeholder="Kode SKO..."
                className="w-1/3 p-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
              />
              <input
                type="text"
                value={newSKOName}
                onChange={(e) => setNewSKOName(e.target.value)}
                placeholder="Nama Layanan SKO..."
                className="w-2/3 p-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
              />
            </div>
            <button
              type="button"
              onClick={handleAddSKO}
              className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold"
            >
              + Kategori SKO
            </button>
          </div>
        </div>
      </div>

      {/* 4. Koneksi Web App GAS & Reset Database Operasional */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Database className="w-4 h-4 text-blue-600" />
          <span>Pengaturan Integrasi Spreadsheet & Pembersihan Data</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
            <span className="font-bold text-slate-800 block">Koneksi Google Apps Script Web App:</span>
            <input
              type="url"
              value={gasUrlInput}
              onChange={(e) => setGasUrlInput(e.target.value)}
              placeholder="https://script.google.com/macros/s/.../exec"
              className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-900 font-mono text-xs"
            />
            <button
              onClick={() => onSaveGasUrl(gasUrlInput.trim())}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold"
            >
              Simpan URL
            </button>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
            <span className="font-bold text-slate-800 block">Inisialisasi & Reset Data Operasional:</span>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => onRunSetupDatabase(true)}
                className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg font-semibold"
              >
                Muat Ulang Data Contoh
              </button>
              <button
                onClick={() => {
                  if (confirm('Bersihkan semua data transaksi Ritase, Plotting, Payment, dan Keuangan?')) {
                    onClearOperationalData();
                  }
                }}
                className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 rounded-lg font-semibold"
              >
                Kosongkan Transaksi Operasional
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
