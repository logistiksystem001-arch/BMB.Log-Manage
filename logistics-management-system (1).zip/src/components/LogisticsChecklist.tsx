import React from 'react';
import { PackageCheck, Truck, Barcode, FileSpreadsheet, Check, ShieldCheck, Mail, ArrowRight } from 'lucide-react';

interface LogisticsChecklistProps {
  onInsertFeatureSnippet: (featureTitle: string, snippet: string) => void;
}

export const LogisticsChecklist: React.FC<LogisticsChecklistProps> = ({ onInsertFeatureSnippet }) => {
  const roadmapItems = [
    {
      title: 'Proteksi Mutasi Stok (In/Out & Opname)',
      icon: PackageCheck,
      status: 'Penting',
      desc: 'Validasi stok keluar tidak boleh melebihi sisa fisik, plus pencatatan tipe transaksi (Barang Masuk, Barang Keluar, Penyesuaian Opname).',
      snippet: `// Contoh fungsi Mutasi Stok Terpadu
function mutasiStok(sku, tipeMutasi, qty, catatan) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Stok_Barang");
    // Eksekusi mutasi dengan atomic update...
    SpreadsheetApp.flush();
  } finally {
    lock.releaseLock();
  }
}`
    },
    {
      title: 'Integrasi Barcode / QR Scanner Input',
      icon: Barcode,
      status: 'Efisiensi',
      desc: 'Endpoint API cepat yang dapat dipanggil langsung dari kamera HP atau scanner wireless genggam untuk scan SKU instan.',
      snippet: `// Lookup Cepat SKU untuk Barcode Scanner
function scanBarcode(barcodeValue) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Stok_Barang");
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).trim() === String(barcodeValue).trim()) {
      return { found: true, sku: data[i][0], nama: data[i][1], stok: data[i][3] };
    }
  }
  return { found: false, message: "Barcode tidak terdaftar" };
}`
    },
    {
      title: 'Pembuatan Surat Jalan / Delivery Order Otomatis (PDF)',
      icon: Truck,
      status: 'Logistik',
      desc: 'Generate otomatis dokumen PDF Surat Jalan atau Invoice langsung ke folder Google Drive dan kirim link via email.',
      snippet: `// Buat Dokumen PDF Surat Jalan dari Template Google Docs
function cetakSuratJalanPdf(noSuratJalan, dataBarang, penerima) {
  const docTemplateId = PropertiesService.getScriptProperties().getProperty("TEMPLATE_DOC_ID");
  const folderId = PropertiesService.getScriptProperties().getProperty("FOLDER_PDF_ID");
  
  const copyFile = DriveApp.getFileById(docTemplateId).makeCopy("Surat_Jalan_" + noSuratJalan);
  const doc = DocumentApp.openById(copyFile.getId());
  const body = doc.getBody();
  body.replaceText("{{NO_SJ}}", noSuratJalan);
  body.replaceText("{{PENERIMA}}", penerima);
  doc.saveAndClose();
  
  const pdfBlob = copyFile.getAs(MimeType.PDF);
  const finalPdf = DriveApp.getFolderById(folderId).createFile(pdfBlob);
  copyFile.setTrashed(true); // Bersihkan draft docs
  return finalPdf.getUrl();
}`
    },
    {
      title: 'Notifikasi Otomatis Stok Minimum (Restock Alert)',
      icon: Mail,
      status: 'Manajemen',
      desc: 'Trigger harian (Time-driven trigger) setiap pagi pukul 07.00 WIB untuk memeriksa barang yang mendekati batas habis.',
      snippet: `// Trigger Harian Pemeriksaan Stok Kritis
function dailyLowStockDigest() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Stok_Barang");
  const rows = sheet.getDataRange().getValues();
  const lowItems = [];
  
  for (let i = 1; i < rows.length; i++) {
    const stok = Number(rows[i][3]) || 0;
    const minStok = Number(rows[i][4]) || 5;
    if (stok <= minStok) {
      lowItems.push(\`• \${rows[i][1]} (\${rows[i][0]}): Sisa \${stok}\`);
    }
  }
  
  if (lowItems.length > 0) {
    MailApp.sendEmail({
      to: Session.getActiveUser().getEmail(),
      subject: "[DIGEST GUDANG] " + lowItems.length + " Barang Membutuhkan Restock",
      body: "Daftar barang di bawah stok minimum:\\n\\n" + lowItems.join("\\n")
    });
  }
}`
    }
  ];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-teal-500/10 text-teal-400">
            <FileSpreadsheet className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100">
              Modul Tambahan Standar Sistem Gudang & Logistik
            </h3>
            <p className="text-xs text-slate-400">
              Kembangkan sistem Code.gs Anda ke tingkat enterprise dengan modul-modul ini
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {roadmapItems.map((item, idx) => {
          const Icon = item.icon;
          return (
            <div
              key={idx}
              className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between space-y-2.5 hover:border-slate-700 transition"
            >
              <div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-slate-800 text-teal-400">
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-semibold text-slate-200">{item.title}</span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded font-bold uppercase bg-teal-500/10 text-teal-400 border border-teal-500/20">
                    {item.status}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">{item.desc}</p>
              </div>

              <button
                onClick={() => onInsertFeatureSnippet(item.title, item.snippet)}
                className="inline-flex items-center justify-center gap-1.5 w-full py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-teal-400 text-xs font-semibold border border-slate-700 transition cursor-pointer"
              >
                <span>Lihat & Salin Kode Modul</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
