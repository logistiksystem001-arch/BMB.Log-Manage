import React, { useState } from 'react';
import { MissingFeature, Severity } from '../types';
import {
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Copy,
  Check,
  Code2,
  HelpCircle,
  AlertCircle,
  Zap,
  CheckCircle,
} from 'lucide-react';

interface MissingFeaturesListProps {
  features: MissingFeature[];
  onOpenUpgradeModal: () => void;
}

export const MissingFeaturesList: React.FC<MissingFeaturesListProps> = ({
  features,
  onOpenUpgradeModal,
}) => {
  const [expandedId, setExpandedId] = useState<string | null>(features[0]?.id || null);
  const [copiedSnippetId, setCopiedSnippetId] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('ALL');

  const missingOnly = features.filter((f) => f.detectedStatus !== 'IMPLEMENTED');
  const implementedOnly = features.filter((f) => f.detectedStatus === 'IMPLEMENTED');

  const categories = ['ALL', 'Keandalan & Transaksi', 'Performa & Kuota', 'Fitur Bisnis/Logistik', 'Keamanan & Autentikasi', 'Integrasi & Notifikasi'];

  const filtered = missingOnly.filter(
    (f) => filterCategory === 'ALL' || f.category === filterCategory
  );

  const handleCopySnippet = (id: string, snippet: string) => {
    navigator.clipboard.writeText(snippet);
    setCopiedSnippetId(id);
    setTimeout(() => setCopiedSnippetId(null), 2000);
  };

  const getSeverityBadge = (sev: Severity) => {
    switch (sev) {
      case 'CRITICAL':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-red-500/15 text-red-400 border border-red-500/30">
            Kritis
          </span>
        );
      case 'HIGH':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-amber-500/15 text-amber-400 border border-amber-500/30">
            Tinggi
          </span>
        );
      case 'MEDIUM':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-sky-500/15 text-sky-400 border border-sky-500/30">
            Sedang
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-700 text-slate-300">
            Rendah
          </span>
        );
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-slate-100">
              Daftar Fitur yang Masih Kurang ({missingOnly.length})
            </h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 font-semibold border border-rose-500/20">
              Perlu Ditambahkan
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Fitur-fitur esensial agar Google Apps Script handal digunakan di lingkungan operasional & logistik.
          </p>
        </div>

        <button
          onClick={onOpenUpgradeModal}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs shadow-md shadow-teal-500/20 transition cursor-pointer"
        >
          <Zap className="w-3.5 h-3.5 text-slate-950" />
          <span>Lihat Versi Lengkap Sekaligus</span>
        </button>
      </div>

      {/* Category Pills Filter */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs scrollbar-thin">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCategory(cat)}
            className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition cursor-pointer ${
              filterCategory === cat
                ? 'bg-slate-750 text-teal-400 border border-teal-500/40 bg-teal-500/10'
                : 'text-slate-400 hover:text-slate-200 bg-slate-950 border border-slate-800'
            }`}
          >
            {cat === 'ALL' ? 'Semua Kategori' : cat}
          </button>
        ))}
      </div>

      {/* Feature Cards List */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="p-6 text-center rounded-xl bg-slate-950 border border-slate-800 text-slate-400 text-xs">
            Tidak ada fitur kurang dalam kategori ini. Kode Anda sudah memenuhi syarat ini!
          </div>
        ) : (
          filtered.map((item) => {
            const isExpanded = expandedId === item.id;
            return (
              <div
                key={item.id}
                className="rounded-xl border border-slate-800 bg-slate-950/70 overflow-hidden transition hover:border-slate-700"
              >
                {/* Collapsible Header */}
                <button
                  onClick={() => setExpandedId(isExpanded ? null : item.id)}
                  className="w-full p-4 text-left flex items-start sm:items-center justify-between gap-3 cursor-pointer"
                >
                  <div className="flex items-start sm:items-center gap-3">
                    <div className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400 mt-0.5 sm:mt-0">
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-semibold text-slate-200">
                          {item.title}
                        </span>
                        {getSeverityBadge(item.severity)}
                        <span className="text-[11px] text-slate-400 px-2 py-0.5 rounded bg-slate-800/80">
                          {item.category}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-1">
                        {item.impactIfMissing}
                      </p>
                    </div>
                  </div>

                  <div className="p-1 text-slate-400 hover:text-slate-200">
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </button>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="px-4 pb-4 pt-1 border-t border-slate-800/80 space-y-3 bg-slate-900/40">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                      <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                        <span className="font-semibold text-slate-300 block mb-1">
                          ❓ Mengapa Fitur Ini Harus Ada?
                        </span>
                        <p className="text-slate-400 leading-relaxed">
                          {item.whyImportant}
                        </p>
                      </div>

                      <div className="p-3 rounded-lg bg-rose-950/20 border border-rose-900/30">
                        <span className="font-semibold text-rose-300 block mb-1">
                          ⚠️ Resiko / Dampak Jika Tidak Dipasang:
                        </span>
                        <p className="text-rose-200/80 leading-relaxed">
                          {item.impactIfMissing}
                        </p>
                      </div>
                    </div>

                    {/* Code Snippet Solution */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-teal-400 flex items-center gap-1.5">
                          <Code2 className="w-3.5 h-3.5" />
                          Potongan Kode Solusi (Siap Sisip ke Apps Script):
                        </span>
                        <button
                          onClick={() => handleCopySnippet(item.id, item.solutionSnippet)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition"
                        >
                          {copiedSnippetId === item.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span className="text-emerald-400 font-medium">Tersalin!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Salin Snippet</span>
                            </>
                          )}
                        </button>
                      </div>

                      <pre className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-teal-300/90 overflow-x-auto leading-relaxed">
                        <code>{item.solutionSnippet}</code>
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Already Implemented section if any */}
      {implementedOnly.length > 0 && (
        <div className="pt-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 mb-2">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>Fitur yang Sudah Terpasang dengan Baik ({implementedOnly.length}):</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {implementedOnly.map((f) => (
              <span
                key={f.id}
                className="text-xs px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/20"
              >
                ✓ {f.title}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
