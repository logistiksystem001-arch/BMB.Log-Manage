import {
  RitaseItem,
  PlottingItem,
  PaymentItem,
  KeuanganItem,
  User,
  ActivityLog,
  MasterOptions,
  CompanySettings,
  MasterVendor,
  MasterTruck,
  MasterSKO,
} from '../types/logistics';

// Hanya 1 akun Admin utama saja sesuai permintaan
export const INITIAL_USERS: User[] = [
  {
    id: 'usr-admin-1',
    name: 'Administrator Logistik',
    email: 'logistik.system001@gmail.com',
    password: 'Admin@12345',
    role: 'admin',
    permissions: ['dashboard', 'ritase', 'plotting', 'payment', 'keuangan', 'users', 'logs', 'settings'],
    active: true,
    createdAt: '2026-10-06'
  }
];

export const INITIAL_COMPANY_SETTINGS: CompanySettings = {
  companyName: 'PT LOGISTICS PRIMA NUSANTARA',
  companySlogan: 'Solusi Cepat, Aman & Terpercaya Manajemen Armada Logistik',
  address: 'Kawasan Pergudangan Logistik Terpadu Blok B8 No. 12, Jakarta',
  phone: '(021) 8899-7700 / 0812-3456-7890',
  email: 'logistik.system001@gmail.com',
  officers: [
    {
      id: 'off-1',
      name: 'Hafid Dimas Febryan',
      position: 'Direktur Operasional',
      role: 'Mengetahui (Direktur)'
    },
    {
      id: 'off-2',
      name: 'Siti Rahmawati, S.E.',
      position: 'Manajer Keuangan & Kasir',
      role: 'Menyetujui (Finance)'
    },
    {
      id: 'off-3',
      name: 'Bambang Supriyanto',
      position: 'Koordinator Lapangan & Armada',
      role: 'Dibuat Oleh (Operasional)'
    }
  ]
};

export const INITIAL_MASTER_VENDORS: MasterVendor[] = [
  {
    id: 'vnd-1',
    code: 'VND-001',
    name: 'PT FAST LOGISTIK NUSANTARA',
    pic: 'Budi Santoso',
    phone: '081234567890',
    address: 'Jl. Raya Marunda No. 45, Jakarta Utara'
  },
  {
    id: 'vnd-2',
    code: 'VND-002',
    name: 'CV TRANS JAYA ABADI',
    pic: 'Hendra Gunawan',
    phone: '081398765432',
    address: 'Kawasan Industri Rungkut Blok C-3, Surabaya'
  },
  {
    id: 'vnd-3',
    code: 'VND-003',
    name: 'PT SINAR LOGISTIK MANDIRI',
    pic: 'Agus Setiawan',
    phone: '081122334455',
    address: 'Jl. Arteri Soekarno Hatta No. 88, Semarang'
  }
];

export const INITIAL_MASTER_TRUCKS: MasterTruck[] = [
  { id: 'trk-1', type: 'CDE (Engkel)', capacityTon: 2.5, description: 'Colt Diesel Engkel 4 Roda (Box/Bak)' },
  { id: 'trk-2', type: 'CDD (Double)', capacityTon: 5.0, description: 'Colt Diesel Double 6 Roda (Box/Bak)' },
  { id: 'trk-3', type: 'FUSO', capacityTon: 10.0, description: 'Fuso 6 Roda Muatan Berat' },
  { id: 'trk-4', type: 'TRONTON', capacityTon: 20.0, description: 'Tronton Wingbox 10 Roda' },
  { id: 'trk-5', type: 'TRAILER', capacityTon: 32.0, description: 'Trailer Container 20/40 Feet' }
];

export const INITIAL_MASTER_SKO: MasterSKO[] = [
  { id: 'sko-1', code: 'SKO-REG', name: 'REGULER LOGISTIK', rute: 'JAKARTA - SURABAYA', defaultRate: 4800000 },
  { id: 'sko-2', code: 'SKO-EXP', name: 'EXPRESS CARGO', rute: 'SURABAYA - JAKARTA', defaultRate: 8500000 },
  { id: 'sko-3', code: 'SKO-DED', name: 'DEDICATED FLEET', rute: 'JAKARTA - BANDUNG', defaultRate: 3200000 },
  { id: 'sko-4', code: 'SKO-RET', name: 'RETURN ROUTE', rute: 'SURABAYA - JAKARTA', defaultRate: 4000000 }
];

export const INITIAL_PLOTTING: PlottingItem[] = [
  {
    id: 'PLT-202610-001',
    rowIndex: 2,
    date: '2026-10-06',
    skoType: 'SKO-REG (REGULER LOGISTIK)',
    truckType: 'CDD (Double)',
    vendor: 'PT FAST LOGISTIK NUSANTARA',
    driver: 'Budi Santoso',
    plat: 'B 9283 JKL',
    origin: 'Jakarta',
    rute: 'Jakarta - Surabaya',
    fixRate: 4800000,
    buyRate: 4100000,
    status: 'ON THE ROAD',
    notes: 'Muat barang FMCG pergudangan Marunda'
  },
  {
    id: 'PLT-202610-002',
    rowIndex: 3,
    date: '2026-10-06',
    skoType: 'SKO-EXP (EXPRESS CARGO)',
    truckType: 'TRONTON',
    vendor: 'CV TRANS JAYA ABADI',
    driver: 'Hendra Gunawan',
    plat: 'L 8412 UZ',
    origin: 'Surabaya',
    rute: 'Surabaya - Jakarta',
    fixRate: 8500000,
    buyRate: 7200000,
    status: 'PLANNED',
    notes: 'Standby pergudangan Rungkut Industri'
  },
  {
    id: 'PLT-202610-003',
    rowIndex: 4,
    date: '2026-10-05',
    skoType: 'SKO-DED (DEDICATED FLEET)',
    truckType: 'FUSO',
    vendor: 'PT SINAR LOGISTIK MANDIRI',
    driver: 'Agus Setiawan',
    plat: 'B 3011 PKQ',
    origin: 'Jakarta',
    rute: 'Jakarta - Bandung',
    fixRate: 3200000,
    buyRate: 2600000,
    status: 'DELIVERED',
    notes: 'Bongkar selesai tepat waktu di Cimahi'
  }
];

export const INITIAL_PAYMENT: PaymentItem[] = [
  {
    id: 'PAY-202610-001',
    plottingId: 'PLT-202610-001',
    rowIndex: 2,
    date: '2026-10-06',
    project: 'PROJECT FMCG JAKARTA',
    paymentType: '70%',
    rute: 'Jakarta - Surabaya',
    driver: 'Budi Santoso',
    noPlat: 'B 9283 JKL',
    truckType: 'CDD (Double)',
    vendor: 'PT FAST LOGISTIK NUSANTARA',
    fixRate: 4800000,
    buyRate: 4100000,
    margin: 700000,
    statusFixRate: 'APPROVED',
    refNoFixRate: 'TRF-BCA-889102',
    statusBuyRate: 'APPROVE',
    refNoBuyRate: 'TRF-MANDIRI-442119',
    notes: 'DP Uang Jalan 70% dan pelunasan invoice klien'
  },
  {
    id: 'PAY-202610-002',
    plottingId: 'PLT-202610-002',
    rowIndex: 3,
    date: '2026-10-06',
    project: 'PROJECT EXP SURABAYA',
    paymentType: '30%',
    rute: 'Surabaya - Jakarta',
    driver: 'Hendra Gunawan',
    noPlat: 'L 8412 UZ',
    truckType: 'TRONTON',
    vendor: 'CV TRANS JAYA ABADI',
    fixRate: 8500000,
    buyRate: 7200000,
    margin: 1300000,
    statusFixRate: 'PENGAJUAN',
    refNoFixRate: '',
    statusBuyRate: 'PROSES',
    refNoBuyRate: '',
    notes: 'Menunggu konfirmasi transfer DP Klien'
  },
  {
    id: 'PAY-202610-003',
    plottingId: 'PLT-202610-003',
    rowIndex: 4,
    date: '2026-10-05',
    project: 'PROJECT DED BANDUNG',
    paymentType: '100%',
    rute: 'Jakarta - Bandung',
    driver: 'Agus Setiawan',
    noPlat: 'B 3011 PKQ',
    truckType: 'FUSO',
    vendor: 'PT SINAR LOGISTIK MANDIRI',
    fixRate: 3200000,
    buyRate: 2600000,
    margin: 600000,
    statusFixRate: 'APPROVED',
    refNoFixRate: 'TRF-BRI-993021',
    statusBuyRate: 'APPROVE',
    refNoBuyRate: 'TRF-BNI-110298',
    notes: 'Pelunasan 100% setelah POD kembali'
  }
];

export const INITIAL_RITASE: RitaseItem[] = [
  {
    id: 'RIT-202610-001',
    rowIndex: 2,
    date: '2026-10-06',
    skoType: 'SKO-REG (REGULER LOGISTIK)',
    truckType: 'CDD (Double)',
    vendor: 'PT FAST LOGISTIK NUSANTARA',
    driver: 'Budi Santoso',
    plat: 'B 9283 JKL',
    origin: 'Jakarta - Surabaya',
    fixRate: 4800000,
    buyRate: 4100000,
    margin: 700000,
    fix70: 3360000,
    fix30: 1440000,
    buy70: 2870000,
    buy30: 1230000,
    fix100: 4800000,
    buy100: 4100000,
    statusFix: 'APPROVED',
    statusBuy: 'APPROVE',
    refNoFix: 'TRF-BCA-889102',
    refNoBuy: 'TRF-MANDIRI-442119'
  },
  {
    id: 'RIT-202610-002',
    rowIndex: 3,
    date: '2026-10-06',
    skoType: 'SKO-EXP (EXPRESS CARGO)',
    truckType: 'TRONTON',
    vendor: 'CV TRANS JAYA ABADI',
    driver: 'Hendra Gunawan',
    plat: 'L 8412 UZ',
    origin: 'Surabaya - Jakarta',
    fixRate: 8500000,
    buyRate: 7200000,
    margin: 1300000,
    fix70: 5950000,
    fix30: 2550000,
    buy70: 5040000,
    buy30: 2160000,
    fix100: 8500000,
    buy100: 7200000,
    statusFix: 'PENGAJUAN',
    statusBuy: 'PROSES',
    refNoFix: '',
    refNoBuy: ''
  },
  {
    id: 'RIT-202610-003',
    rowIndex: 4,
    date: '2026-10-05',
    skoType: 'SKO-DED (DEDICATED FLEET)',
    truckType: 'FUSO',
    vendor: 'PT SINAR LOGISTIK MANDIRI',
    driver: 'Agus Setiawan',
    plat: 'B 3011 PKQ',
    origin: 'Jakarta - Bandung',
    fixRate: 3200000,
    buyRate: 2600000,
    margin: 600000,
    fix70: 2240000,
    fix30: 960000,
    buy70: 1820000,
    buy30: 780000,
    fix100: 3200000,
    buy100: 2600000,
    statusFix: 'APPROVED',
    statusBuy: 'APPROVE',
    refNoFix: 'TRF-BRI-993021',
    refNoBuy: 'TRF-BNI-110298'
  }
];

export const INITIAL_KEUANGAN: KeuanganItem[] = [
  {
    id: 'KAS-202610-001',
    rowIndex: 2,
    tanggal: '2026-10-06',
    tipe: 'PEMASUKAN',
    jenis: 'Pelunasan Tagihan Klien (Fix Rate)',
    keterangan: 'Pemasukan Fix Rate Ritase B 9283 JKL (Budi Santoso) - Ref: TRF-BCA-889102',
    jumlah: 4800000,
    total: 4800000,
    status: 'LUNAS',
    refNo: 'TRF-BCA-889102',
    sourceModule: 'PAYMENT_FIX',
    sourceId: 'PAY-202610-001'
  },
  {
    id: 'KAS-202610-002',
    rowIndex: 3,
    tanggal: '2026-10-06',
    tipe: 'PENGELUARAN',
    jenis: 'Pembayaran Vendor / Uang Jalan (Buy Rate)',
    keterangan: 'Pengeluaran Buy Rate Vendor PT FAST LOGISTIK NUSANTARA (Budi Santoso - B 9283 JKL) - Ref: TRF-MANDIRI-442119',
    jumlah: 4100000,
    total: 700000,
    status: 'LUNAS',
    refNo: 'TRF-MANDIRI-442119',
    sourceModule: 'PAYMENT_BUY',
    sourceId: 'PAY-202610-001'
  },
  {
    id: 'KAS-202610-003',
    rowIndex: 4,
    tanggal: '2026-10-05',
    tipe: 'PEMASUKAN',
    jenis: 'Pelunasan Tagihan Klien (Fix Rate)',
    keterangan: 'Pemasukan Fix Rate Ritase B 3011 PKQ (Agus Setiawan) - Ref: TRF-BRI-993021',
    jumlah: 3200000,
    total: 3900000,
    status: 'LUNAS',
    refNo: 'TRF-BRI-993021',
    sourceModule: 'PAYMENT_FIX',
    sourceId: 'PAY-202610-003'
  },
  {
    id: 'KAS-202610-004',
    rowIndex: 5,
    tanggal: '2026-10-05',
    tipe: 'PENGELUARAN',
    jenis: 'Pembayaran Vendor / Uang Jalan (Buy Rate)',
    keterangan: 'Pengeluaran Buy Rate Vendor PT SINAR LOGISTIK MANDIRI (Agus Setiawan - B 3011 PKQ) - Ref: TRF-BNI-110298',
    jumlah: 2600000,
    total: 1300000,
    status: 'LUNAS',
    refNo: 'TRF-BNI-110298',
    sourceModule: 'PAYMENT_BUY',
    sourceId: 'PAY-202610-003'
  }
];

export const INITIAL_LOGS: ActivityLog[] = [
  {
    id: 'LOG-001',
    timestamp: '2026-10-06 10:15:20',
    userEmail: 'logistik.system001@gmail.com',
    userName: 'Administrator Logistik',
    module: 'PLOTTING',
    action: 'CREATE',
    details: 'Input Plotting Armada B 9283 JKL (Budi Santoso) - Jakarta ke Surabaya'
  },
  {
    id: 'LOG-002',
    timestamp: '2026-10-06 10:20:00',
    userEmail: 'logistik.system001@gmail.com',
    userName: 'Administrator Logistik',
    module: 'PAYMENT',
    action: 'APPROVE',
    details: 'Approve Fix Rate Rp 4.800.000 (Ref: TRF-BCA-889102) & Masuk Otomatis ke Kas'
  },
  {
    id: 'LOG-003',
    timestamp: '2026-10-06 10:25:10',
    userEmail: 'logistik.system001@gmail.com',
    userName: 'Administrator Logistik',
    module: 'PAYMENT',
    action: 'APPROVE',
    details: 'Approve Buy Rate Vendor Rp 4.100.000 (Ref: TRF-MANDIRI-442119) & Masuk Otomatis ke Kas'
  }
];

export const DEFAULT_MASTER_OPTIONS: MasterOptions = {
  skoTypes: [
    'SKO-REG (REGULER LOGISTIK)',
    'SKO-EXP (EXPRESS CARGO)',
    'SKO-DED (DEDICATED FLEET)',
    'SKO-RET (RETURN ROUTE)'
  ],
  truckTypes: [
    'CDE (Engkel)',
    'CDD (Double)',
    'FUSO',
    'TRONTON',
    'TRAILER'
  ],
  vendors: [
    'PT FAST LOGISTIK NUSANTARA',
    'CV TRANS JAYA ABADI',
    'PT SINAR LOGISTIK MANDIRI'
  ],
  drivers: [
    'Budi Santoso',
    'Hendra Gunawan',
    'Agus Setiawan',
    'Rudi Hartono',
    'Joko Widodo'
  ],
  origins: [
    'Jakarta',
    'Surabaya',
    'Semarang',
    'Bandung',
    'Medan',
    'Makassar'
  ],
  projects: [
    'PROJECT FMCG JAKARTA',
    'PROJECT EXP SURABAYA',
    'PROJECT DED BANDUNG',
    'PROJECT HEAVY INDUSTRIAL'
  ],
  paymentTypes: ['30%', '70%', '100%'],
  keuanganTipe: ['PEMASUKAN', 'PENGELUARAN'],
  keuanganStatus: ['HUTANG', 'PIUTANG', 'LUNAS']
};
