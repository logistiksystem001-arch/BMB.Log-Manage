export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';

export interface MissingFeature {
  id: string;
  category: 'Keandalan & Transaksi' | 'Keamanan & Autentikasi' | 'Performa & Kuota' | 'Fitur Bisnis/Logistik' | 'Integrasi & Notifikasi';
  title: string;
  severity: Severity;
  whyImportant: string;
  impactIfMissing: string;
  solutionSnippet: string;
  detectedStatus: 'MISSING' | 'PARTIAL' | 'IMPLEMENTED';
}

export interface SecurityVulnerability {
  id: string;
  title: string;
  severity: Severity;
  description: string;
  remedy: string;
  lineHint?: string;
}

export interface GasMetrics {
  totalLines: number;
  totalFunctions: number;
  hasLockService: boolean;
  hasTryCatch: boolean;
  hasBatchOperations: boolean;
  hasPropertiesService: boolean;
  hasCacheService: boolean;
  hasInputValidation: boolean;
  hasAuditLog: boolean;
  hasNegativeStockGuard: boolean;
  hasRateLimitOrTimeoutGuard: boolean;
  loopsWithSingleCellCalls: number;
  hardcodedTokensDetected: boolean;
  healthScore: number;
}

export interface AnalysisReport {
  summary: string;
  healthScore: number;
  metrics: GasMetrics;
  missingFeatures: MissingFeature[];
  vulnerabilities: SecurityVulnerability[];
  performanceAdvice: string[];
  logisticsAdvice: string[];
  upgradedCode?: string;
}
