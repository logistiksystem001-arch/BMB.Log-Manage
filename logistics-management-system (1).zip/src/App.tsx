/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/logistics/Navbar';
import { Sidebar, ActiveTab } from './components/logistics/Sidebar';
import { DashboardView } from './components/logistics/DashboardView';
import { PlottingView } from './components/logistics/PlottingView';
import { PaymentView } from './components/logistics/PaymentView';
import { KeuanganView } from './components/logistics/KeuanganView';
import { RitaseView } from './components/logistics/RitaseView';
import { UsersView } from './components/logistics/UsersView';
import { ActivityLogView } from './components/logistics/ActivityLogView';
import { SettingsView } from './components/logistics/SettingsView';
import { LoginView } from './components/logistics/LoginView';
import { SpkModal } from './components/logistics/SpkModal';
import { PaymentVoucherModal } from './components/logistics/PaymentVoucherModal';
import { PaymentRekapPdfModal } from './components/logistics/PaymentRekapPdfModal';
import { ReferenceNumberModal } from './components/logistics/ReferenceNumberModal';
import { EnhancedCodeModal } from './components/logistics/EnhancedCodeModal';
import { GasConnectModal } from './components/logistics/GasConnectModal';

import {
  RitaseItem,
  PlottingItem,
  PaymentItem,
  KeuanganItem,
  User,
  ActivityLog,
  MasterOptions,
  CompanySettings,
  MasterVendor,
  MasterTruck,
  MasterSKO,
} from './types/logistics';
import {
  INITIAL_USERS,
  INITIAL_COMPANY_SETTINGS,
  INITIAL_MASTER_VENDORS,
  INITIAL_MASTER_TRUCKS,
  INITIAL_MASTER_SKO,
  INITIAL_PLOTTING,
  INITIAL_PAYMENT,
  INITIAL_RITASE,
  INITIAL_KEUANGAN,
  INITIAL_LOGS,
  DEFAULT_MASTER_OPTIONS,
} from './data/initialData';

export default function App() {
  // Company Settings & Branding
  const [companySettings, setCompanySettings] = useState<CompanySettings>(() => {
    const saved = localStorage.getItem('lms_company_settings');
    return saved ? JSON.parse(saved) : INITIAL_COMPANY_SETTINGS;
  });

  // User & Authentication
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('lms_current_user');
    return saved ? JSON.parse(saved) : INITIAL_USERS[0];
  });

  // Active Tab
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');

  // Backend GAS URL
  const [gasUrl, setGasUrl] = useState<string>(() => {
    return localStorage.getItem('lms_gas_url') || '';
  });

  // Master Data CRUD States
  const [masterVendors, setMasterVendors] = useState<MasterVendor[]>(() => {
    const saved = localStorage.getItem('lms_master_vendors');
    return saved ? JSON.parse(saved) : INITIAL_MASTER_VENDORS;
  });

  const [masterTrucks, setMasterTrucks] = useState<MasterTruck[]>(() => {
    const saved = localStorage.getItem('lms_master_trucks');
    return saved ? JSON.parse(saved) : INITIAL_MASTER_TRUCKS;
  });

  const [masterSKOs, setMasterSKOs] = useState<MasterSKO[]>(() => {
    const saved = localStorage.getItem('lms_master_skos');
    return saved ? JSON.parse(saved) : INITIAL_MASTER_SKO;
  });

  // Operational Data States
  const [plottingList, setPlottingList] = useState<PlottingItem[]>(() => {
    const saved = localStorage.getItem('lms_plotting');
    return saved ? JSON.parse(saved) : INITIAL_PLOTTING;
  });

  const [paymentList, setPaymentList] = useState<PaymentItem[]>(() => {
    const saved = localStorage.getItem('lms_payment');
    return saved ? JSON.parse(saved) : INITIAL_PAYMENT;
  });

  const [keuanganList, setKeuanganList] = useState<KeuanganItem[]>(() => {
    const saved = localStorage.getItem('lms_keuangan');
    return saved ? JSON.parse(saved) : INITIAL_KEUANGAN;
  });

  const [ritaseList, setRitaseList] = useState<RitaseItem[]>(() => {
    const saved = localStorage.getItem('lms_ritase');
    return saved ? JSON.parse(saved) : INITIAL_RITASE;
  });

  const [usersList, setUsersList] = useState<User[]>(() => {
    const saved = localStorage.getItem('lms_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [logs, setLogs] = useState<ActivityLog[]>(() => {
    const saved = localStorage.getItem('lms_logs');
    return saved ? JSON.parse(saved) : INITIAL_LOGS;
  });

  const [masterOptions, setMasterOptions] = useState<MasterOptions>(DEFAULT_MASTER_OPTIONS);

  // Sync masterOptions with dynamic vendors, trucks, and SKOs
  useEffect(() => {
    setMasterOptions((prev) => ({
      ...prev,
      vendors: masterVendors.map((v) => v.name),
      truckTypes: masterTrucks.map((t) => t.type),
      skoTypes: masterSKOs.map((s) => `${s.code} (${s.name})`),
    }));
  }, [masterVendors, masterTrucks, masterSKOs]);

  // Modals States
  const [isEnhancedCodeModalOpen, setIsEnhancedCodeModalOpen] = useState(false);
  const [isGasConnectModalOpen, setIsGasConnectModalOpen] = useState(false);
  const [selectedSpkItem, setSelectedSpkItem] = useState<RitaseItem | null>(null);
  const [selectedPaymentVoucher, setSelectedPaymentVoucher] = useState<PaymentItem | null>(null);
  const [rekapPdfModal, setRekapPdfModal] = useState<{
    isOpen: boolean;
    selectedItems: PaymentItem[];
  }>({ isOpen: false, selectedItems: [] });

  // Approval Reference Modal State
  const [refModal, setRefModal] = useState<{
    isOpen: boolean;
    paymentItem: PaymentItem | null;
    rateType: 'FIX_RATE' | 'BUY_RATE';
  }>({
    isOpen: false,
    paymentItem: null,
    rateType: 'FIX_RATE',
  });

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Synchronize localStorage
  useEffect(() => {
    localStorage.setItem('lms_company_settings', JSON.stringify(companySettings));
  }, [companySettings]);

  useEffect(() => {
    localStorage.setItem('lms_master_vendors', JSON.stringify(masterVendors));
  }, [masterVendors]);

  useEffect(() => {
    localStorage.setItem('lms_master_trucks', JSON.stringify(masterTrucks));
  }, [masterTrucks]);

  useEffect(() => {
    localStorage.setItem('lms_master_skos', JSON.stringify(masterSKOs));
  }, [masterSKOs]);

  useEffect(() => {
    localStorage.setItem('lms_plotting', JSON.stringify(plottingList));
  }, [plottingList]);

  useEffect(() => {
    localStorage.setItem('lms_payment', JSON.stringify(paymentList));
  }, [paymentList]);

  useEffect(() => {
    localStorage.setItem('lms_keuangan', JSON.stringify(keuanganList));
  }, [keuanganList]);

  useEffect(() => {
    localStorage.setItem('lms_ritase', JSON.stringify(ritaseList));
  }, [ritaseList]);

  useEffect(() => {
    localStorage.setItem('lms_users', JSON.stringify(usersList));
  }, [usersList]);

  useEffect(() => {
    localStorage.setItem('lms_logs', JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('lms_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('lms_current_user');
    }
  }, [currentUser]);

  // Activity Log Helper
  const addLog = (
    module: ActivityLog['module'],
    action: ActivityLog['action'],
    details: string
  ) => {
    const newLog: ActivityLog = {
      id: 'LOG-' + Date.now(),
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      userEmail: currentUser?.email || 'admin@logistik.local',
      userName: currentUser?.name || 'Administrator',
      module,
      action,
      details,
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  // Recalculate Keuangan Running Total
  const recalculateRunningTotals = (items: KeuanganItem[]): KeuanganItem[] => {
    let running = 0;
    return items.map((item) => {
      if (item.tipe === 'PEMASUKAN') {
        running += Number(item.jumlah || 0);
      } else {
        running -= Number(item.jumlah || 0);
      }
      return { ...item, total: running };
    });
  };

  // ================= 1. PLOTTING HANDLERS =================
  const handleSavePlotting = (data: Partial<PlottingItem>) => {
    const fixRate = Number(data.fixRate || 4800000);
    const buyRate = Number(data.buyRate || 4100000);
    const margin = fixRate - buyRate;

    if (data.id) {
      // Update
      setPlottingList((prev) =>
        prev.map((item) => (item.id === data.id ? ({ ...item, ...data } as PlottingItem) : item))
      );
      // Update corresponding Payment item
      setPaymentList((prev) =>
        prev.map((p) =>
          p.plottingId === data.id
            ? {
                ...p,
                driver: data.driver || p.driver,
                noPlat: data.plat || p.noPlat,
                rute: data.rute || p.rute,
                fixRate,
                buyRate,
                margin,
              }
            : p
        )
      );
      // Update corresponding Ritase item
      setRitaseList((prev) =>
        prev.map((r) =>
          r.id === data.id
            ? {
                ...r,
                driver: data.driver || r.driver,
                plat: data.plat || r.plat,
                origin: data.rute || r.origin,
                fixRate,
                buyRate,
                margin,
              }
            : r
        )
      );
      addLog('PLOTTING', 'UPDATE', `Update plotting armada #${data.id} (${data.plat})`);
      showToast('Plotting armada berhasil diperbarui!');
    } else {
      // Create new Plotting
      const newId = `PLT-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 900) + 100)}`;
      const newPlotting: PlottingItem = {
        id: newId,
        rowIndex: plottingList.length + 2,
        date: data.date || new Date().toISOString().split('T')[0],
        skoType: data.skoType || masterOptions.skoTypes[0],
        truckType: data.truckType || masterOptions.truckTypes[0],
        vendor: data.vendor || masterOptions.vendors[0],
        driver: data.driver || '',
        plat: data.plat || '',
        origin: data.origin || 'Jakarta',
        rute: data.rute || '',
        fixRate,
        buyRate,
        status: data.status || 'PLANNED',
        notes: data.notes || '',
      };
      setPlottingList((prev) => [newPlotting, ...prev]);

      // ALUR KERJA: Otomatis muncul ke Pengajuan Payment!
      const newPayment: PaymentItem = {
        id: `PAY-${newId.replace('PLT-', '')}`,
        plottingId: newId,
        rowIndex: paymentList.length + 2,
        date: newPlotting.date,
        project: `RITASE ${newPlotting.skoType}`,
        paymentType: '70%',
        rute: newPlotting.rute,
        driver: newPlotting.driver,
        noPlat: newPlotting.plat,
        truckType: newPlotting.truckType,
        vendor: newPlotting.vendor,
        fixRate,
        buyRate,
        margin,
        statusFixRate: 'DRAFT',
        statusBuyRate: 'DRAFT',
        notes: newPlotting.notes,
      };
      setPaymentList((prev) => [newPayment, ...prev]);

      // Sinkronkan ke Master Data Ritase
      const newRitase: RitaseItem = {
        id: newId.replace('PLT-', 'RIT-'),
        rowIndex: ritaseList.length + 2,
        date: newPlotting.date,
        skoType: newPlotting.skoType,
        truckType: newPlotting.truckType,
        vendor: newPlotting.vendor,
        driver: newPlotting.driver,
        plat: newPlotting.plat,
        origin: newPlotting.rute,
        fixRate,
        buyRate,
        margin,
        fix70: Math.round(fixRate * 0.7),
        fix30: Math.round(fixRate * 0.3),
        buy70: Math.round(buyRate * 0.7),
        buy30: Math.round(buyRate * 0.3),
        fix100: fixRate,
        buy100: buyRate,
        statusFix: 'DRAFT',
        statusBuy: 'DRAFT',
      };
      setRitaseList((prev) => [newRitase, ...prev]);

      addLog('PLOTTING', 'CREATE', `Plotting baru #${newId} dibuat & otomatis masuk ke Pengajuan Payment`);
      showToast(`Plotting ${newPlotting.driver} dibuat & otomatis mengalir ke Pengajuan Payment!`);
    }
  };

  const handleDeletePlotting = (id: string) => {
    setPlottingList((prev) => prev.filter((p) => p.id !== id));
    addLog('PLOTTING', 'DELETE', `Hapus plotting #${id}`);
    showToast('Plotting armada dihapus.');
  };

  const handleUpdatePlottingStatus = (
    id: string,
    status: 'PLANNED' | 'ON THE ROAD' | 'DELIVERED'
  ) => {
    setPlottingList((prev) =>
      prev.map((p) => (p.id === id ? { ...p, status } : p))
    );
    addLog('PLOTTING', 'STATUS_CHANGE', `Update status armada #${id} menjadi ${status}`);
    showToast(`Status armada diubah: ${status}`);
  };

  const handleForwardPlottingToPayment = (item: PlottingItem) => {
    setActiveTab('payment');
    showToast(`Membuka Pengajuan Payment untuk ${item.driver} (${item.plat})`);
  };

  // ================= 2. PENGAJUAN PAYMENT & DUAL APPROVAL WORKFLOW =================
  const handleSavePayment = (data: Partial<PaymentItem>) => {
    if (data.id) {
      setPaymentList((prev) =>
        prev.map((item) => (item.id === data.id ? ({ ...item, ...data } as PaymentItem) : item))
      );
      addLog('PAYMENT', 'UPDATE', `Update payment #${data.id}`);
      showToast('Data pengajuan payment diperbarui!');
    } else {
      const newId = `PAY-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 900) + 100)}`;
      const fixRate = Number(data.fixRate || 0);
      const buyRate = Number(data.buyRate || 0);
      const newItem: PaymentItem = {
        id: newId,
        rowIndex: paymentList.length + 2,
        date: data.date || new Date().toISOString().split('T')[0],
        project: data.project || 'PROJECT UMUM',
        paymentType: data.paymentType || '70%',
        rute: data.rute || '',
        driver: data.driver || '',
        noPlat: data.noPlat || '',
        fixRate,
        buyRate,
        margin: fixRate - buyRate,
        statusFixRate: data.statusFixRate || 'DRAFT',
        statusBuyRate: data.statusBuyRate || 'DRAFT',
        notes: data.notes || '',
      };
      setPaymentList((prev) => [newItem, ...prev]);
      addLog('PAYMENT', 'CREATE', `Input payment baru #${newId}`);
      showToast('Pengajuan payment berhasil disimpan!');
    }
  };

  const handleDeletePayment = (id: string) => {
    setPaymentList((prev) => prev.filter((p) => p.id !== id));
    addLog('PAYMENT', 'DELETE', `Hapus payment #${id}`);
    showToast('Pengajuan payment dihapus.');
  };

  const handleUpdateStatusManual = (id: string, type: 'fix' | 'buy', status: string) => {
    setPaymentList((prev) =>
      prev.map((p) =>
        p.id === id
          ? type === 'fix'
            ? { ...p, statusFixRate: status as any }
            : { ...p, statusBuyRate: status as any }
          : p
      )
    );
    // Sync to ritase
    setRitaseList((prev) =>
      prev.map((r) =>
        r.id.includes(id.replace('PAY-', ''))
          ? type === 'fix'
            ? { ...r, statusFix: status as any }
            : { ...r, statusBuy: status as any }
          : r
      )
    );
    addLog('PAYMENT', 'STATUS_CHANGE', `Update status ${type.toUpperCase()} payment #${id} ke ${status}`);
    showToast(`Status diperbarui menjadi ${status}`);
  };

  // Trigger Approve Fix Rate (Penerimaan Pembayaran Klien)
  const handleTriggerApproveFixRate = (item: PaymentItem) => {
    setRefModal({
      isOpen: true,
      paymentItem: item,
      rateType: 'FIX_RATE',
    });
  };

  // Trigger Approve Buy Rate (Pembayaran ke Vendor / Driver)
  const handleTriggerApproveBuyRate = (item: PaymentItem) => {
    setRefModal({
      isOpen: true,
      paymentItem: item,
      rateType: 'BUY_RATE',
    });
  };

  // Callback once Reference Number is confirmed in modal
  const handleConfirmApproval = (refNo: string, notes: string) => {
    const item = refModal.paymentItem;
    if (!item) return;

    if (refModal.rateType === 'FIX_RATE') {
      // 1. Update Payment Status to APPROVED
      setPaymentList((prev) =>
        prev.map((p) =>
          p.id === item.id ? { ...p, statusFixRate: 'APPROVED', refNoFixRate: refNo } : p
        )
      );

      // 2. OTOMATIS MASUK KE BUKU KAS KEUANGAN: PEMASUKAN
      const newKasId = `KAS-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 900) + 100)}`;
      const newKasEntry: KeuanganItem = {
        id: newKasId,
        rowIndex: keuanganList.length + 2,
        tanggal: item.date,
        tipe: 'PEMASUKAN',
        jenis: 'Pelunasan Tagihan Klien (Fix Rate)',
        keterangan: `Pemasukan Fix Rate Ritase ${item.noPlat} (${item.driver}) - Ref: ${refNo}${notes ? ` (${notes})` : ''}`,
        jumlah: item.fixRate,
        total: 0,
        status: 'LUNAS',
        refNo,
        sourceModule: 'PAYMENT_FIX',
        sourceId: item.id,
      };
      setKeuanganList(recalculateRunningTotals([...keuanganList, newKasEntry]));

      // 3. SINKRONISASI KE MASTER DATA RITASE
      setRitaseList((prev) =>
        prev.map((r) =>
          r.id.includes(item.id.replace('PAY-', ''))
            ? { ...r, statusFix: 'APPROVED', refNoFix: refNo }
            : r
        )
      );

      addLog(
        'PAYMENT',
        'APPROVE',
        `Approve Fix Rate Tagihan Klien #${item.id} (Ref: ${refNo}) - Pemasukan Kas Rp ${item.fixRate.toLocaleString('id-ID')} dicatat otomatis`
      );
      showToast(`Tagihan Klien Disetujui (Ref: ${refNo}) & Otomatis Masuk ke Buku Kas Pemasukan!`);
    } else {
      // 1. Update Payment Status to APPROVE
      setPaymentList((prev) =>
        prev.map((p) =>
          p.id === item.id ? { ...p, statusBuyRate: 'APPROVE', refNoBuyRate: refNo } : p
        )
      );

      // 2. OTOMATIS MASUK KE BUKU KAS KEUANGAN: PENGELUARAN
      const newKasId = `KAS-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 900) + 100)}`;
      const newKasEntry: KeuanganItem = {
        id: newKasId,
        rowIndex: keuanganList.length + 2,
        tanggal: item.date,
        tipe: 'PENGELUARAN',
        jenis: 'Pembayaran Biaya Vendor / Driver (Buy Rate)',
        keterangan: `Pengeluaran Buy Rate Vendor ${item.vendor || 'Vendor'} (${item.driver} - ${item.noPlat}) - Ref: ${refNo}${notes ? ` (${notes})` : ''}`,
        jumlah: item.buyRate,
        total: 0,
        status: 'LUNAS',
        refNo,
        sourceModule: 'PAYMENT_BUY',
        sourceId: item.id,
      };
      setKeuanganList(recalculateRunningTotals([...keuanganList, newKasEntry]));

      // 3. SINKRONISASI KE MASTER DATA RITASE
      setRitaseList((prev) =>
        prev.map((r) =>
          r.id.includes(item.id.replace('PAY-', ''))
            ? { ...r, statusBuy: 'APPROVE', refNoBuy: refNo }
            : r
        )
      );

      addLog(
        'PAYMENT',
        'APPROVE',
        `Approve Buy Rate Vendor #${item.id} (Ref: ${refNo}) - Pengeluaran Kas Rp ${item.buyRate.toLocaleString('id-ID')} dicatat otomatis`
      );
      showToast(`Pembayaran Vendor Disetujui (Ref: ${refNo}) & Otomatis Masuk ke Buku Kas Pengeluaran!`);
    }
  };

  // ================= 3. KEUANGAN HANDLERS =================
  const handleSaveKeuangan = (data: Partial<KeuanganItem>) => {
    if (data.id) {
      const updated = keuanganList.map((item) =>
        item.id === data.id ? ({ ...item, ...data } as KeuanganItem) : item
      );
      setKeuanganList(recalculateRunningTotals(updated));
      addLog('KEUANGAN', 'UPDATE', `Update kas #${data.id}`);
      showToast('Transaksi kas diperbarui!');
    } else {
      const newId = `KAS-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 900) + 100)}`;
      const newItem: KeuanganItem = {
        id: newId,
        rowIndex: keuanganList.length + 2,
        tanggal: data.tanggal || new Date().toISOString().split('T')[0],
        tipe: data.tipe || 'PEMASUKAN',
        jenis: data.jenis || 'Umum',
        keterangan: data.keterangan || '',
        jumlah: Number(data.jumlah || 0),
        total: 0,
        status: data.status || 'LUNAS',
        refNo: data.refNo || '',
      };
      setKeuanganList(recalculateRunningTotals([...keuanganList, newItem]));
      addLog('KEUANGAN', 'CREATE', `Catat kas manual #${newId} (${newItem.tipe})`);
      showToast('Transaksi kas berhasil dicatat!');
    }
  };

  const handleDeleteKeuangan = (id: string) => {
    const updated = keuanganList.filter((k) => k.id !== id);
    setKeuanganList(recalculateRunningTotals(updated));
    addLog('KEUANGAN', 'DELETE', `Hapus kas #${id}`);
    showToast('Transaksi kas dihapus & saldo dihitung ulang.');
  };

  // ================= 4. RITASE HANDLERS =================
  const handleSaveRitase = (data: Partial<RitaseItem>) => {
    if (data.id) {
      setRitaseList((prev) =>
        prev.map((item) => (item.id === data.id ? ({ ...item, ...data } as RitaseItem) : item))
      );
      addLog('RITASE', 'UPDATE', `Update ritase #${data.id}`);
      showToast('Data Ritase diperbarui!');
    } else {
      const newId = `RIT-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 900) + 100)}`;
      const fixRate = Number(data.fixRate || 0);
      const buyRate = Number(data.buyRate || 0);
      const newItem: RitaseItem = {
        id: newId,
        rowIndex: ritaseList.length + 2,
        date: data.date || new Date().toISOString().split('T')[0],
        skoType: data.skoType || masterOptions.skoTypes[0],
        truckType: data.truckType || masterOptions.truckTypes[0],
        vendor: data.vendor || masterOptions.vendors[0],
        driver: data.driver || '',
        plat: data.plat || '',
        origin: data.origin || '',
        fixRate,
        buyRate,
        margin: fixRate - buyRate,
        fix70: Math.round(fixRate * 0.7),
        fix30: Math.round(fixRate * 0.3),
        buy70: Math.round(buyRate * 0.7),
        buy30: Math.round(buyRate * 0.3),
        fix100: fixRate,
        buy100: buyRate,
        statusFix: data.statusFix || 'DRAFT',
        statusBuy: data.statusBuy || 'DRAFT',
      };
      setRitaseList((prev) => [newItem, ...prev]);
      addLog('RITASE', 'CREATE', `Ritase baru #${newId}`);
      showToast('Ritase baru berhasil disimpan!');
    }
  };

  const handleDeleteRitase = (id: string) => {
    setRitaseList((prev) => prev.filter((r) => r.id !== id));
    addLog('RITASE', 'DELETE', `Hapus ritase #${id}`);
    showToast('Data Ritase dihapus.');
  };

  const handleUpdateRitaseStatus = (id: string, field: 'fix' | 'buy', newStatus: any) => {
    setRitaseList((prev) =>
      prev.map((r) =>
        r.id === id
          ? field === 'fix'
            ? { ...r, statusFix: newStatus }
            : { ...r, statusBuy: newStatus }
          : r
      )
    );
    showToast(`Status ritase diperbarui: ${newStatus}`);
  };

  const handleGeneratePayment70FromRitase = (ritase: RitaseItem) => {
    const newPayId = `PAY-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 900) + 100)}`;
    const newPayment: PaymentItem = {
      id: newPayId,
      rowIndex: paymentList.length + 2,
      date: ritase.date,
      project: `RITASE ${ritase.skoType}`,
      paymentType: '70%',
      rute: ritase.origin,
      driver: ritase.driver,
      noPlat: ritase.plat,
      truckType: ritase.truckType,
      vendor: ritase.vendor,
      fixRate: ritase.fixRate,
      buyRate: ritase.buyRate,
      margin: ritase.margin,
      statusFixRate: 'DRAFT',
      statusBuyRate: 'DRAFT',
      notes: `Pengajuan Uang Jalan 70% dari Ritase #${ritase.id}`,
    };
    setPaymentList((prev) => [newPayment, ...prev]);
    showToast(`Pengajuan Payment 70% berhasil dibuat untuk ${ritase.driver}!`);
    setActiveTab('payment');
  };

  // ================= USERS HANDLERS =================
  const handleSaveUser = (data: Partial<User>) => {
    if (data.id) {
      setUsersList((prev) =>
        prev.map((u) => (u.id === data.id ? ({ ...u, ...data } as User) : u))
      );
      showToast('Data user diperbarui!');
    } else {
      const newUser: User = {
        id: 'usr-' + Date.now(),
        name: data.name || '',
        email: data.email || '',
        password: data.password || 'Admin@12345',
        role: data.role || 'operasional',
        permissions: data.permissions || ['dashboard', 'plotting', 'payment'],
        active: data.active !== false,
        createdAt: new Date().toISOString().split('T')[0],
      };
      setUsersList((prev) => [...prev, newUser]);
      showToast('User baru berhasil ditambahkan!');
    }
  };

  const handleDeleteUser = (id: string) => {
    setUsersList((prev) => prev.filter((u) => u.id !== id));
    showToast('User dihapus.');
  };

  const handleToggleUserStatus = (id: string) => {
    setUsersList((prev) =>
      prev.map((u) => (u.id === id ? { ...u, active: !u.active } : u))
    );
    showToast('Status user diubah.');
  };

  // ================= MASTER CRUD HANDLERS =================
  const handleSaveVendor = (v: MasterVendor) => {
    setMasterVendors((prev) => {
      const exists = prev.some((item) => item.id === v.id);
      return exists ? prev.map((item) => (item.id === v.id ? v : item)) : [...prev, v];
    });
    showToast('Master Vendor berhasil disimpan!');
  };

  const handleDeleteVendor = (id: string) => {
    setMasterVendors((prev) => prev.filter((item) => item.id !== id));
    showToast('Master Vendor dihapus.');
  };

  const handleSaveTruck = (t: MasterTruck) => {
    setMasterTrucks((prev) => {
      const exists = prev.some((item) => item.id === t.id);
      return exists ? prev.map((item) => (item.id === t.id ? t : item)) : [...prev, t];
    });
    showToast('Master Tipe Truk berhasil disimpan!');
  };

  const handleDeleteTruck = (id: string) => {
    setMasterTrucks((prev) => prev.filter((item) => item.id !== id));
    showToast('Master Tipe Truk dihapus.');
  };

  const handleSaveSKO = (s: MasterSKO) => {
    setMasterSKOs((prev) => {
      const exists = prev.some((item) => item.id === s.id);
      return exists ? prev.map((item) => (item.id === s.id ? s : item)) : [...prev, s];
    });
    showToast('Master SKO berhasil disimpan!');
  };

  const handleDeleteSKO = (id: string) => {
    setMasterSKOs((prev) => prev.filter((item) => item.id !== id));
    showToast('Master SKO dihapus.');
  };

  // ================= DATABASE RESET =================
  const handleRunSetupDatabase = (withSample: boolean) => {
    if (withSample) {
      setPlottingList(INITIAL_PLOTTING);
      setPaymentList(INITIAL_PAYMENT);
      setRitaseList(INITIAL_RITASE);
      setKeuanganList(INITIAL_KEUANGAN);
    }
    showToast('Setup database berhasil dijalankan!');
  };

  const handleClearOperationalData = () => {
    setPlottingList([]);
    setPaymentList([]);
    setRitaseList([]);
    setKeuanganList([]);
    showToast('Seluruh data transaksi telah dikosongkan.');
  };

  const handleSaveGasUrl = (url: string) => {
    setGasUrl(url);
    localStorage.setItem('lms_gas_url', url);
    showToast(url ? 'URL Web App tersimpan!' : 'Mode lokal aktif.');
  };

  // Authentication Guard
  if (!currentUser) {
    return (
      <LoginView
        companySettings={companySettings}
        onLoginSuccess={setCurrentUser}
        usersList={usersList}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans selection:bg-blue-100">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 animate-in fade-in slide-in-from-bottom duration-300">
          <div className="bg-slate-900 border border-slate-800 text-white px-4 py-2.5 rounded-xl shadow-2xl text-xs font-semibold flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping" />
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Top Navigation Bar with Dynamic Company Branding */}
      <Navbar
        currentUser={currentUser}
        companySettings={companySettings}
        onLogout={() => setCurrentUser(null)}
        onOpenCodeModal={() => setIsEnhancedCodeModalOpen(true)}
        onOpenConnectModal={() => setIsGasConnectModalOpen(true)}
        gasUrl={gasUrl}
      />

      {/* Main Layout */}
      <div className="flex-1 flex flex-col lg:flex-row max-w-7xl w-full mx-auto">
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          currentUser={currentUser}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              ritaseList={ritaseList}
              plottingList={plottingList}
              paymentList={paymentList}
              keuanganList={keuanganList}
              onNavigate={setActiveTab}
              onOpenAddPlotting={() => setActiveTab('plotting')}
            />
          )}

          {activeTab === 'plotting' && (
            <PlottingView
              plottingList={plottingList}
              masterOptions={masterOptions}
              onSavePlotting={handleSavePlotting}
              onDeletePlotting={handleDeletePlotting}
              onUpdateStatus={handleUpdatePlottingStatus}
              onForwardToPayment={handleForwardPlottingToPayment}
            />
          )}

          {activeTab === 'payment' && (
            <PaymentView
              paymentList={paymentList}
              masterOptions={masterOptions}
              onSavePayment={handleSavePayment}
              onDeletePayment={handleDeletePayment}
              onTriggerApproveFixRate={handleTriggerApproveFixRate}
              onTriggerApproveBuyRate={handleTriggerApproveBuyRate}
              onUpdateStatusManual={handleUpdateStatusManual}
              onPrintVoucher={(item) => setSelectedPaymentVoucher(item)}
              onOpenRekapPdf={(selected) => setRekapPdfModal({ isOpen: true, selectedItems: selected })}
            />
          )}

          {activeTab === 'keuangan' && (
            <KeuanganView
              keuanganList={keuanganList}
              masterOptions={masterOptions}
              onSaveKeuangan={handleSaveKeuangan}
              onDeleteKeuangan={handleDeleteKeuangan}
            />
          )}

          {activeTab === 'ritase' && (
            <RitaseView
              ritaseList={ritaseList}
              masterOptions={masterOptions}
              onSaveRitase={handleSaveRitase}
              onDeleteRitase={handleDeleteRitase}
              onUpdateStatus={handleUpdateRitaseStatus}
              onPrintSpk={(item) => setSelectedSpkItem(item)}
              onGeneratePayment70={handleGeneratePayment70FromRitase}
            />
          )}

          {activeTab === 'users' && (
            <UsersView
              usersList={usersList}
              onSaveUser={handleSaveUser}
              onDeleteUser={handleDeleteUser}
              onToggleStatus={handleToggleUserStatus}
            />
          )}

          {activeTab === 'logs' && <ActivityLogView logs={logs} />}

          {activeTab === 'settings' && (
            <SettingsView
              companySettings={companySettings}
              onSaveCompanySettings={setCompanySettings}
              masterVendors={masterVendors}
              onSaveVendor={handleSaveVendor}
              onDeleteVendor={handleDeleteVendor}
              masterTrucks={masterTrucks}
              onSaveTruck={handleSaveTruck}
              onDeleteTruck={handleDeleteTruck}
              masterSKOs={masterSKOs}
              onSaveSKO={handleSaveSKO}
              onDeleteSKO={handleDeleteSKO}
              gasUrl={gasUrl}
              onSaveGasUrl={handleSaveGasUrl}
              onRunSetupDatabase={handleRunSetupDatabase}
              onClearOperationalData={handleClearOperationalData}
            />
          )}
        </main>
      </div>

      {/* Modals */}
      <SpkModal item={selectedSpkItem} onClose={() => setSelectedSpkItem(null)} />
      <PaymentVoucherModal
        item={selectedPaymentVoucher}
        onClose={() => setSelectedPaymentVoucher(null)}
      />
      <PaymentRekapPdfModal
        isOpen={rekapPdfModal.isOpen}
        onClose={() => setRekapPdfModal({ isOpen: false, selectedItems: [] })}
        selectedItems={rekapPdfModal.selectedItems}
        companySettings={companySettings}
      />
      <ReferenceNumberModal
        isOpen={refModal.isOpen}
        onClose={() => setRefModal({ isOpen: false, paymentItem: null, rateType: 'FIX_RATE' })}
        title={
          refModal.rateType === 'FIX_RATE'
            ? 'Input No. Referensi Transfer Tagihan Klien'
            : 'Input No. Referensi Transfer Pelunasan Vendor'
        }
        subtitle={
          refModal.rateType === 'FIX_RATE'
            ? 'Nomor bukti bank penerimaan pembayaran sebelum status APPROVED'
            : 'Nomor bukti transfer pelunasan biaya vendor sebelum status APPROVE'
        }
        partyName={
          refModal.paymentItem
            ? `${refModal.paymentItem.driver} (${refModal.paymentItem.noPlat})`
            : ''
        }
        amount={
          refModal.paymentItem
            ? refModal.rateType === 'FIX_RATE'
              ? refModal.paymentItem.fixRate
              : refModal.paymentItem.buyRate
            : 0
        }
        rateType={refModal.rateType}
        onConfirm={handleConfirmApproval}
      />
      <EnhancedCodeModal
        isOpen={isEnhancedCodeModalOpen}
        onClose={() => setIsEnhancedCodeModalOpen(false)}
      />
      <GasConnectModal
        isOpen={isGasConnectModalOpen}
        onClose={() => setIsGasConnectModalOpen(false)}
        gasUrl={gasUrl}
        onSaveGasUrl={handleSaveGasUrl}
      />
    </div>
  );
}
