export type UserRole = 'admin' | 'operasional' | 'finance' | 'viewer';

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  role: UserRole;
  permissions: string[];
  active: boolean;
  createdAt: string;
  lastLogin?: string;
  rowIndex?: number;
}

export interface Officer {
  id: string;
  name: string;
  position: string; // e.g. "Direktur Utama", "Manajer Keuangan", "Koordinator Operasional"
  role: string; // "Mengetahui", "Menyetujui", "Dibuat Oleh"
}

export interface MasterSKO {
  id: string;
  code: string;
  name: string;
  rute: string;
  defaultRate: number;
}

export interface MasterTruck {
  id: string;
  type: string;
  capacityTon: number;
  description: string;
}

export interface MasterVendor {
  id: string;
  code: string;
  name: string;
  pic: string;
  phone: string;
  address: string;
}

export interface CompanySettings {
  companyName: string;
  companySlogan: string;
  address: string;
  phone: string;
  email: string;
  officers: Officer[];
}

export interface RitaseItem {
  id: string;
  rowIndex?: number;
  date: string;
  skoType: string;
  truckType: string;
  vendor: string;
  driver: string;
  plat: string;
  origin: string;
  fixRate: number;
  buyRate: number;
  margin: number;
  fix70: number;
  fix30: number;
  buy70: number;
  buy30: number;
  fix100: number;
  buy100: number;
  statusFix: 'DRAFT' | 'PENGAJUAN' | 'APPROVED';
  statusBuy: 'DRAFT' | 'PROSES' | 'APPROVE';
  refNoFix?: string;
  refNoBuy?: string;
}

export interface PlottingItem {
  id: string;
  rowIndex?: number;
  date: string;
  skoType: string;
  truckType: string;
  vendor: string;
  driver: string;
  plat: string;
  origin: string;
  rute: string;
  fixRate: number;
  buyRate: number;
  status: 'PLANNED' | 'ON THE ROAD' | 'DELIVERED';
  notes: string;
}

export interface PaymentItem {
  id: string;
  plottingId?: string;
  rowIndex?: number;
  date: string;
  project: string;
  paymentType: '30%' | '70%' | '100%';
  rute: string;
  driver: string;
  noPlat: string;
  truckType?: string;
  vendor?: string;
  fixRate: number;
  buyRate: number;
  margin: number;
  // Status Terima Pembayaran (Klien / Fix Rate): DRAFT, PENGAJUAN, APPROVED
  statusFixRate: 'DRAFT' | 'PENGAJUAN' | 'APPROVED';
  refNoFixRate?: string;
  // Status Pembayaran ke Vendor (Buy Rate): DRAFT, PROSES, APPROVE
  statusBuyRate: 'DRAFT' | 'PROSES' | 'APPROVE';
  refNoBuyRate?: string;
  notes?: string;
}

export interface KeuanganItem {
  id: string;
  rowIndex?: number;
  tanggal: string;
  tipe: 'PEMASUKAN' | 'PENGELUARAN';
  jenis: string;
  keterangan: string;
  jumlah: number;
  total: number;
  status: 'HUTANG' | 'PIUTANG' | 'LUNAS';
  refNo?: string;
  sourceModule?: 'PAYMENT_FIX' | 'PAYMENT_BUY' | 'MANUAL';
  sourceId?: string;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  userEmail: string;
  userName: string;
  module: 'RITASE' | 'PLOTTING' | 'PAYMENT' | 'KEUANGAN' | 'USERS' | 'DATABASE' | 'SETTINGS';
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'STATUS_CHANGE' | 'APPROVE' | 'SETUP';
  details: string;
}

export interface MasterOptions {
  skoTypes: string[];
  truckTypes: string[];
  vendors: string[];
  drivers: string[];
  origins: string[];
  projects: string[];
  paymentTypes: string[];
  keuanganTipe: string[];
  keuanganStatus: string[];
}
