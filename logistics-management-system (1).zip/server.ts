import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Google GenAI if key available
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  } catch (err) {
    console.error('Failed to initialize GoogleGenAI client:', err);
  }
}

// API: AI Deep Analysis for Google Apps Script Code.gs
app.post('/api/analyze', async (req, res) => {
  try {
    const { code, systemType, specificQuestions } = req.body;

    if (!code || typeof code !== 'string') {
      return res.status(400).json({ error: 'Code is required' });
    }

    if (!aiClient) {
      return res.status(200).json({
        fallback: true,
        message: 'No GEMINI_API_KEY configured. Running rule-based static analyzer.',
      });
    }

    const prompt = `Anda adalah seorang Senior Google Apps Script (GAS) Architect & Google Workspace Solution Expert.
Tugas Anda adalah menganalisis kode Google Apps Script (Code.gs) berikut secara mendalam, mengecek fitur apa saja yang masih KURANG (missing features), celah keamanan, bottleneck performa kuota Apps Script, serta memberikan rekomendasi fitur logistik / sistem bisnis dan kode perbaikan.

Konteks Sistem: ${systemType || 'Umum / Sistem Manajemen / Logistik'}
Catatan/Pertanyaan Khusus: ${specificQuestions || 'Fitur apa yang masih kurang, rawan error, atau belum aman?'}

KODE SCRIPT:
\`\`\`javascript
${code}
\`\`\`

Berikan respon dalam format JSON murni dengan struktur berikut:
{
  "summary": "Ringkasan arsitektur script saat ini dan kesimpulan kesehatan kode",
  "score": 85, // Skor keseluruhan (0-100)
  "missingFeatures": [
    {
      "category": "Keandalan & Transaksi" | "Keamanan & Autentikasi" | "Performa & Kuota" | "Fitur Bisnis/Logistik" | "Integrasi & Notifikasi",
      "feature": "Nama fitur yang kurang",
      "severity": "CRITICAL" | "HIGH" | "MEDIUM" | "LOW",
      "whyImportant": "Mengapa fitur ini sangat penting bagi Google Apps Script",
      "implementationSnippet": "Contoh potongan kode GAS yang siap disisipkan"
    }
  ],
  "vulnerabilities": [
    {
      "issue": "Nama kelemahan/bug/celah",
      "impact": "Dampak terhadap sistem / spreadsheet / user",
      "recommendation": "Solusi perbaikan konkret"
    }
  ],
  "performanceAudit": {
    "quotaRisk": "Rendah / Sedang / Tinggi",
    "lockServiceUsed": true | false,
    "batchOperationsUsed": true | false,
    "cacheServiceUsed": true | false,
    "advice": "Saran performa seputar kuota Google Apps Script (6 menit execution limit, read/write quotas)"
  },
  "upgradedCode": "// Seluruh atau bagian kode yang telah dilengkapi dengan fitur-fitur penting yang sebelumnya kurang",
  "actionableSteps": [
    "Langkah praktis 1 untuk menerapkan di Google Apps Script editor",
    "Langkah praktis 2..."
  ]
}

Pastikan output adalah valid JSON tanpa formatting markdown di luar blok JSON.`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    let parsedData;
    try {
      parsedData = JSON.parse(responseText);
    } catch {
      // Clean up markdown block if present
      const cleaned = responseText.replace(/^```json\s*/, '').replace(/\s*```$/, '');
      parsedData = JSON.parse(cleaned);
    }

    return res.json({ success: true, analysis: parsedData });
  } catch (err: any) {
    console.error('Analysis error:', err);
    return res.status(500).json({
      error: err.message || 'Gagal menganalisis kode dengan AI',
      fallback: true,
    });
  }
});

// API: Generate complete upgraded Code.gs based on selected feature enhancements
app.post('/api/enhance', async (req, res) => {
  try {
    const { code, requestedFeatures } = req.body;
    if (!aiClient) {
      return res.status(400).json({ error: 'Gemini API not available' });
    }

    const prompt = `Anda adalah Senior Google Apps Script Developer.
Refactor dan lengkapi kode Google Apps Script (Code.gs) berikut dengan fitur-fitur yang diminta:
Fitur yang harus ditambahkan/disempurnakan:
${(requestedFeatures || []).map((f: string, i: number) => `${i + 1}. ${f}`).join('\n')}

KODE ASLI:
\`\`\`javascript
${code}
\`\`\`

Instruksi:
1. Pertahankan logika bisnis utama yang sudah ada.
2. Tambahkan implementasi lengkap (bukan komentar TODO kosong).
3. Tulis komentar bahasa Indonesia yang jelas pada fungsi baru.
4. Pastikan menggunakan LockService jika menangani transaksi spreadsheet untuk mencegah race condition.
5. Gunakan try-catch dengan format return JSON standar { success: true/false, message: '...', data: ... }.
6. Berikan HANYA kode JavaScript Google Apps Script yang lengkap dan siap pakai, tanpa teks markdown pembuka/penutup tambahan jika memungkinkan atau dalam blok \`\`\`javascript.`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: prompt,
    });

    return res.json({ success: true, enhancedCode: response.text });
  } catch (err: any) {
    console.error('Enhance error:', err);
    return res.status(500).json({ error: err.message });
  }
});

// Setup Vite or static serving
async function setupServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`Server running on port ${port} in ${isProduction ? 'production' : 'development'} mode`);
  });
}

setupServer();
